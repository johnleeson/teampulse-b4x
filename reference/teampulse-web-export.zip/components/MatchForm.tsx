
import React, { useState, useEffect } from 'react';
import { Club, Match } from '../types';
import { X, Calendar, Clock, MapPin, Trophy, Shield, Users, Check } from 'lucide-react';

interface MatchFormProps {
  club: Club;
  onSave: (match: Match) => void;
  onCancel: () => void;
  currentUserId?: string;
  initialMatch?: Match;
}

const MatchForm: React.FC<MatchFormProps> = ({ club, onSave, onCancel, currentUserId, initialMatch }) => {
  const isTeam = club.type === 'TEAM';
  const isEditing = !!initialMatch;

  const [title, setTitle] = useState(initialMatch?.title || (isTeam ? '' : 'Weekly 5-a-side'));
  const [opponentName, setOpponentName] = useState(initialMatch?.opponentName || '');
  const [isHome, setIsHome] = useState(initialMatch?.isHome !== undefined ? initialMatch.isHome : true);
  const [date, setDate] = useState(initialMatch ? new Date(initialMatch.date).toISOString().split('T')[0] : new Date().toISOString().split('T')[0]);
  const [kickOffTime, setKickOffTime] = useState(initialMatch?.kickOffTime || '19:00');
  const [meetTime, setMeetTime] = useState(initialMatch?.meetTime || '18:30');
  const [location, setLocation] = useState(initialMatch?.location || '');
  const [status, setStatus] = useState<'UPCOMING' | 'LIVE' | 'COMPLETED' | 'CANCELLED'>(initialMatch?.status || 'UPCOMING');
  const [scoreA, setScoreA] = useState<number>(initialMatch?.scoreA || 0);
  const [scoreB, setScoreB] = useState<number>(initialMatch?.scoreB || 0);

  // Auto-detect past date on change
  const handleDateChange = (newDateVal: string) => {
    setDate(newDateVal);
    try {
      const selectedDate = new Date(newDateVal);
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      
      if (selectedDate < today && status === 'UPCOMING') {
        setStatus('COMPLETED');
      } else if (selectedDate >= today && status === 'COMPLETED' && !isEditing) {
        setStatus('UPCOMING');
      }
    } catch (e) {
      // ignore
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const signedUpPlayerIds = isEditing 
      ? initialMatch!.signedUpPlayerIds 
      : (currentUserId ? [currentUserId] : []);

    const matchData: Match = {
      ...(initialMatch || {}),
      id: initialMatch?.id || crypto.randomUUID(), // Use valid UUID
      clubId: club.id,
      title: isTeam ? (isHome ? `${club.name} vs ${opponentName}` : `${opponentName} vs ${club.name}`) : title,
      date: new Date(date).toISOString(),
      kickOffTime,
      meetTime: isTeam ? meetTime : undefined,
      location,
      status,
      teamA: initialMatch?.teamA || [],
      teamB: initialMatch?.teamB || [],
      scoreA: status === 'COMPLETED' ? scoreA : (initialMatch?.scoreA || 0),
      scoreB: status === 'COMPLETED' ? scoreB : (initialMatch?.scoreB || 0),
      signedUpPlayerIds,
      opponentName: isTeam ? opponentName : undefined,
      isHome: isTeam ? isHome : undefined,
    };

    onSave(matchData);
  };

  return (
    <div className="max-w-xl mx-auto animate-in fade-in slide-in-from-bottom-8 duration-500 pb-20 px-2 sm:px-4 overflow-x-hidden">
      <div className="bg-white rounded-[2rem] shadow-2xl border border-slate-200 overflow-hidden w-full box-border">
        <div className="px-4 py-5 md:px-8 md:py-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/30">
          <div className="min-w-0 pr-2">
            <h2 className="text-lg md:text-2xl font-black text-slate-900 tracking-tight truncate">
              {isEditing ? 'Edit Match' : (isTeam ? 'Schedule Match' : 'Plan Game')}
            </h2>
            <p className="text-slate-500 text-[10px] md:text-xs font-medium mt-0.5 truncate">
              {isEditing ? `Updating ${initialMatch!.title}` : (isTeam ? `Fixture for ${club.name}` : `Social kickabout for group`)}
            </p>
          </div>
          <button type="button" onClick={onCancel} className="shrink-0 p-2 text-slate-400 hover:text-slate-600 hover:bg-white rounded-full transition-all border border-transparent hover:border-slate-100"><X className="w-5 h-5 md:w-6 md:h-6" /></button>
        </div>

        <form onSubmit={handleSubmit} className="px-4 py-5 md:px-8 md:py-8 space-y-5 md:space-y-6 w-full box-border">
          {isTeam && (
            <div className="space-y-4">
              <div className="flex gap-2 p-1 bg-slate-100 rounded-xl">
                <button type="button" onClick={() => setIsHome(true)} className={`flex-1 py-2 rounded-lg font-black text-[10px] uppercase tracking-widest transition-all ${isHome ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-500'}`}>Home</button>
                <button type="button" onClick={() => setIsHome(false)} className={`flex-1 py-2 rounded-lg font-black text-[10px] uppercase tracking-widest transition-all ${!isHome ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-500'}`}>Away</button>
              </div>
              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2 ml-1"><Shield className="w-3 h-3 text-blue-600" />Opponent</label>
                <input type="text" required value={opponentName} onChange={(e) => setOpponentName(e.target.value)} placeholder="Opponent team..." className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-slate-900 focus:outline-none focus:ring-4 focus:ring-blue-500/10 transition-all font-bold text-sm box-border" />
              </div>
            </div>
          )}

          {!isTeam && (
            <div className="space-y-1.5">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2 ml-1"><Users className="w-3 h-3 text-indigo-600" />Game Title</label>
              <input type="text" required value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Weekly match..." className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-slate-900 focus:outline-none focus:ring-4 focus:ring-blue-500/10 transition-all font-bold text-sm box-border" />
            </div>
          )}

          <div className="flex flex-col sm:flex-row gap-4 w-full">
            <div className="flex-1 space-y-1.5 min-w-0">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2 ml-1"><Calendar className="w-3 h-3 text-blue-600" />Date</label>
              <input type="date" required value={date} onChange={(e) => handleDateChange(e.target.value)} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-slate-900 focus:outline-none focus:ring-4 focus:ring-blue-500/10 transition-all font-bold text-sm appearance-none box-border" />
            </div>
            <div className="flex-1 space-y-1.5 min-w-0">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2 ml-1"><Clock className="w-3 h-3 text-blue-600" />Kick Off</label>
              <input type="time" required value={kickOffTime} onChange={(e) => setKickOffTime(e.target.value)} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-slate-900 focus:outline-none focus:ring-4 focus:ring-blue-500/10 transition-all font-bold text-sm appearance-none box-border" />
            </div>
          </div>

          {isTeam && (
            <div className="space-y-1.5 min-w-0">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2 ml-1"><Clock className="w-3 h-3 text-orange-500" />Meet Time</label>
              <input type="time" value={meetTime} onChange={(e) => setMeetTime(e.target.value)} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-slate-900 focus:outline-none focus:ring-4 focus:ring-blue-500/10 transition-all font-bold text-sm appearance-none box-border" />
            </div>
          )}

          <div className="space-y-1.5">
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2 ml-1"><MapPin className="w-3 h-3 text-red-500" />Location</label>
            <input type="text" required value={location} onChange={(e) => setLocation(e.target.value)} placeholder="Venue name..." className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-slate-900 focus:outline-none focus:ring-4 focus:ring-blue-500/10 transition-all font-bold text-sm box-border" />
          </div>

          <div className="border-t border-slate-100 pt-5 space-y-4">
            <div className="space-y-1.5">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2 ml-1">
                <Trophy className="w-3 h-3 text-emerald-500" /> Match Status
              </label>
              <div className="grid grid-cols-3 gap-2 p-1 bg-slate-100 rounded-xl">
                <button 
                  type="button" 
                  onClick={() => setStatus('UPCOMING')} 
                  className={`py-2 rounded-lg font-black text-[10px] uppercase tracking-widest transition-all ${status === 'UPCOMING' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
                >
                  Upcoming
                </button>
                <button 
                  type="button" 
                  onClick={() => setStatus('LIVE')} 
                  className={`py-2 rounded-lg font-black text-[10px] uppercase tracking-widest transition-all ${status === 'LIVE' ? 'bg-emerald-500 text-white shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
                >
                  Live Feed
                </button>
                <button 
                  type="button" 
                  onClick={() => setStatus('COMPLETED')} 
                  className={`py-2 rounded-lg font-black text-[10px] uppercase tracking-widest transition-all ${status === 'COMPLETED' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
                >
                  Completed
                </button>
              </div>
            </div>

            {status === 'COMPLETED' && (
              <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200 space-y-3 animate-in slide-in-from-top-4 duration-300">
                <p className="text-slate-500 text-xs font-medium">
                  Since this match is marked as completed, you can enter the final score directly below.
                </p>
                <div className="flex items-center justify-center gap-4">
                  <div className="flex-1 text-center space-y-1">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block truncate">
                      {isTeam ? (isHome ? club.name : opponentName || 'Home') : 'Team A (Home)'}
                    </label>
                    <input 
                      type="number" 
                      min="0" 
                      value={scoreA} 
                      onChange={(e) => setScoreA(Math.max(0, parseInt(e.target.value) || 0))} 
                      className="w-20 mx-auto bg-white border border-slate-200 rounded-xl px-3 py-2 text-center text-slate-900 font-black text-xl focus:outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500"
                    />
                  </div>
                  <div className="text-slate-400 font-bold text-xl self-end mb-2">:</div>
                  <div className="flex-1 text-center space-y-1">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block truncate">
                      {isTeam ? (isHome ? opponentName || 'Away' : club.name) : 'Team B (Away)'}
                    </label>
                    <input 
                      type="number" 
                      min="0" 
                      value={scoreB} 
                      onChange={(e) => setScoreB(Math.max(0, parseInt(e.target.value) || 0))} 
                      className="w-20 mx-auto bg-white border border-slate-200 rounded-xl px-3 py-2 text-center text-slate-900 font-black text-xl focus:outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500"
                    />
                  </div>
                </div>
              </div>
            )}
          </div>

          <div className="flex flex-col-reverse sm:flex-row gap-3 pt-4">
            <button type="button" onClick={onCancel} className="w-full sm:flex-1 px-4 py-3.5 rounded-xl font-black text-slate-500 bg-slate-100 hover:bg-slate-200 transition-all uppercase tracking-widest text-[10px]">Cancel</button>
            <button type="submit" className="w-full sm:flex-[2] px-4 py-3.5 rounded-xl font-black text-white bg-blue-600 shadow-xl shadow-blue-100 hover:bg-blue-700 transition-all flex items-center justify-center gap-2 uppercase tracking-widest text-[10px]"><Check className="w-4 h-4" />{isEditing ? 'Save Changes' : 'Confirm Fixture'}</button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default MatchForm;

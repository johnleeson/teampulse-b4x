
import React, { useState, useMemo, useEffect } from 'react';
import { Match, FeedEvent, EventType, Club, User, UserRole, PlayerStats } from '../types';
import { 
  Goal, 
  ArrowRightLeft, 
  Send, 
  Trophy, 
  Play, 
  Info, 
  Clock, 
  MapPin, 
  X, 
  Check, 
  Users, 
  Sparkles, 
  MessageSquare, 
  Flag, 
  AlertTriangle, 
  CloudSun, 
  ExternalLink, 
  RefreshCw,
  AlertCircle,
  AlertOctagon,
  Award,
  FileText as ReportIcon,
  LayoutGrid,
  History,
  Shield,
  Plus,
  Coffee,
  ChevronUp,
  ChevronRight,
  Edit2,
  Trash2,
  Wind,
  Star,
  UserX,
  UserCheck,
  Image as ImageIcon,
  Camera,
  BookOpen
} from 'lucide-react';
import { getMatchIntel, MatchIntel } from '../services/geminiService';

interface MatchFeedProps {
  match: Match;
  club?: Club | null;
  events: FeedEvent[];
  allMatches?: Match[];
  onAddEvent: (eventData: Partial<FeedEvent>) => void;
  onDeleteEvent: (eventId: string) => void;
  onUpdateEvent: (eventId: string, content: string) => void;
  onUpdateStatus: (status: Match['status']) => void;
  onUpdateLineup: (playerIds: string[]) => void;
  onUpdateMatchData: (matchId: string, data: Partial<Match>) => void;
  onJoinMatch: (matchId: string, userId?: string) => void;
  onEditMatch: (match: Match) => void;
  onVoteForPotm: (playerId: string) => void;
  onSaveAiSummary: (matchId: string, summary: string) => void;
  currentUser: User | null;
  onApiKeyTrouble: () => void;
  onUpdateClubMemberRating?: (clubId: string, userId: string, rating: number) => void;
  onBack?: () => void;
  onDeleteMatch?: (matchId: string) => void;
}

export interface TacticalPosition {
  id: string;
  label: string;
  x: number;
  y: number;
}

export const FORMATIONS: Record<string, TacticalPosition[]> = {
  '4-4-2': [
    { id: 'gk', label: 'GK', x: 50, y: 88 },
    { id: 'lb', label: 'LB', x: 15, y: 70 },
    { id: 'lcb', label: 'CB', x: 38, y: 72 },
    { id: 'rcb', label: 'CB', x: 62, y: 72 },
    { id: 'rb', label: 'RB', x: 85, y: 70 },
    { id: 'lm', label: 'LM', x: 15, y: 45 },
    { id: 'lcm', label: 'CM', x: 38, y: 47 },
    { id: 'rcm', label: 'CM', x: 62, y: 47 },
    { id: 'rm', label: 'RM', x: 85, y: 45 },
    { id: 'lst', label: 'ST', x: 35, y: 20 },
    { id: 'rst', label: 'ST', x: 65, y: 20 },
  ],
  '4-3-3': [
    { id: 'gk', label: 'GK', x: 50, y: 88 },
    { id: 'lb', label: 'LB', x: 15, y: 70 },
    { id: 'lcb', label: 'CB', x: 38, y: 72 },
    { id: 'rcb', label: 'CB', x: 62, y: 72 },
    { id: 'rb', label: 'RB', x: 85, y: 70 },
    { id: 'lcm', label: 'CM', x: 25, y: 48 },
    { id: 'cdm', label: 'DM', x: 50, y: 54 },
    { id: 'rcm', label: 'CM', x: 75, y: 48 },
    { id: 'lw', label: 'LW', x: 20, y: 22 },
    { id: 'st', label: 'ST', x: 50, y: 18 },
    { id: 'rw', label: 'RW', x: 80, y: 22 },
  ],
  '3-5-2': [
    { id: 'gk', label: 'GK', x: 50, y: 88 },
    { id: 'lcb', label: 'CB', x: 25, y: 72 },
    { id: 'cb', label: 'CB', x: 50, y: 74 },
    { id: 'rcb', label: 'CB', x: 75, y: 72 },
    { id: 'lwb', label: 'LM', x: 15, y: 48 },
    { id: 'rwb', label: 'RM', x: 85, y: 48 },
    { id: 'lcm', label: 'CM', x: 35, y: 50 },
    { id: 'cdm', label: 'DM', x: 50, y: 56 },
    { id: 'rcm', label: 'CM', x: 65, y: 50 },
    { id: 'lst', label: 'ST', x: 35, y: 20 },
    { id: 'rst', label: 'ST', x: 65, y: 20 },
  ],
  '4-2-3-1': [
    { id: 'gk', label: 'GK', x: 50, y: 88 },
    { id: 'lb', label: 'LB', x: 15, y: 70 },
    { id: 'lcb', label: 'CB', x: 38, y: 72 },
    { id: 'rcb', label: 'CB', x: 62, y: 72 },
    { id: 'rb', label: 'RB', x: 85, y: 70 },
    { id: 'ldm', label: 'DM', x: 35, y: 54 },
    { id: 'rdm', label: 'DM', x: 65, y: 54 },
    { id: 'lam', label: 'LM', x: 20, y: 34 },
    { id: 'cam', label: 'AM', x: 50, y: 34 },
    { id: 'ram', label: 'RM', x: 80, y: 34 },
    { id: 'st', label: 'ST', x: 50, y: 16 },
  ],
  '7-a-side (2-3-1)': [
    { id: 'gk', label: 'GK', x: 50, y: 88 },
    { id: 'lcb', label: 'CB', x: 30, y: 70 },
    { id: 'rcb', label: 'CB', x: 70, y: 70 },
    { id: 'lm', label: 'LM', x: 20, y: 45 },
    { id: 'cm', label: 'CM', x: 50, y: 45 },
    { id: 'rm', label: 'RM', x: 80, y: 45 },
    { id: 'st', label: 'ST', x: 50, y: 20 },
  ],
  '9-a-side (3-2-3)': [
    { id: 'gk', label: 'GK', x: 50, y: 88 },
    { id: 'lb', label: 'LB', x: 20, y: 72 },
    { id: 'cb', label: 'CB', x: 50, y: 74 },
    { id: 'rb', label: 'RB', x: 80, y: 72 },
    { id: 'lcm', label: 'CM', x: 35, y: 48 },
    { id: 'rcm', label: 'CM', x: 65, y: 48 },
    { id: 'lw', label: 'LW', x: 20, y: 24 },
    { id: 'st', label: 'ST', x: 50, y: 20 },
    { id: 'rw', label: 'RW', x: 80, y: 24 },
  ],
  '9-a-side (3-3-2)': [
    { id: 'gk', label: 'GK', x: 50, y: 88 },
    { id: 'lb', label: 'LB', x: 20, y: 72 },
    { id: 'cb', label: 'CB', x: 50, y: 74 },
    { id: 'rb', label: 'RB', x: 80, y: 72 },
    { id: 'lm', label: 'LM', x: 20, y: 48 },
    { id: 'cm', label: 'CM', x: 50, y: 50 },
    { id: 'rm', label: 'RM', x: 80, y: 48 },
    { id: 'lst', label: 'ST', x: 35, y: 22 },
    { id: 'rst', label: 'ST', x: 65, y: 22 },
  ],
  '9-a-side (4-3-1)': [
    { id: 'gk', label: 'GK', x: 50, y: 88 },
    { id: 'lb', label: 'LB', x: 15, y: 70 },
    { id: 'lcb', label: 'CB', x: 38, y: 72 },
    { id: 'rcb', label: 'CB', x: 62, y: 72 },
    { id: 'rb', label: 'RB', x: 85, y: 70 },
    { id: 'lcm', label: 'CM', x: 25, y: 48 },
    { id: 'cdm', label: 'DM', x: 50, y: 54 },
    { id: 'rcm', label: 'CM', x: 75, y: 48 },
    { id: 'st', label: 'ST', x: 50, y: 20 },
  ],
  '9-a-side (3-4-1)': [
    { id: 'gk', label: 'GK', x: 50, y: 88 },
    { id: 'lb', label: 'LB', x: 20, y: 72 },
    { id: 'cb', label: 'CB', x: 50, y: 74 },
    { id: 'rb', label: 'RB', x: 80, y: 72 },
    { id: 'lm', label: 'LM', x: 15, y: 48 },
    { id: 'lcm', label: 'CM', x: 38, y: 50 },
    { id: 'rcm', label: 'CM', x: 62, y: 50 },
    { id: 'rm', label: 'RM', x: 85, y: 48 },
    { id: 'st', label: 'ST', x: 50, y: 22 },
  ],
  '5-a-side (1-2-1)': [
    { id: 'gk', label: 'GK', x: 50, y: 88 },
    { id: 'cb', label: 'CB', x: 50, y: 70 },
    { id: 'lm', label: 'LM', x: 25, y: 45 },
    { id: 'rm', label: 'RM', x: 75, y: 45 },
    { id: 'st', label: 'ST', x: 50, y: 20 },
  ],
};

type ViewMode = 'FEED' | 'SQUAD' | 'STATS' | 'TACTICS';

export const MatchFeed: React.FC<MatchFeedProps> = ({
  match,
  club,
  events: initialEvents,
  allMatches,
  onAddEvent,
  onDeleteEvent,
  onUpdateEvent,
  onUpdateStatus,
  onUpdateMatchData,
  onJoinMatch,
  onVoteForPotm,
  onSaveAiSummary,
  currentUser,
  onApiKeyTrouble,
  onUpdateClubMemberRating,
  onBack,
  onDeleteMatch
}) => {
  const [activeView, setActiveView] = useState<ViewMode>(club?.type === 'SOCIAL' ? 'SQUAD' : 'FEED');
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [newEventContent, setNewEventContent] = useState('');
  const [selectedPlayerId, setSelectedPlayerId] = useState<string>('');
  const [selectedPlayerId2, setSelectedPlayerId2] = useState<string>('');
  const [selectedTeam, setSelectedTeam] = useState<'A' | 'B'>('A');
  const [activeActionType, setActiveActionType] = useState<EventType | null>(null);
  const [isFetchingIntel, setIsFetchingIntel] = useState(false);
  const [intel, setIntel] = useState<MatchIntel | null>(null);
  const [isIntelExpanded, setIsIntelExpanded] = useState(false);
  
  const [editingEventId, setEditingEventId] = useState<string | null>(null);
  const [editContent, setEditContent] = useState('');
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [isEditingSummary, setIsEditingSummary] = useState(false);
  const [summaryDraft, setSummaryDraft] = useState(match.managerSummary || '');
  const [editingStats, setEditingStats] = useState<Record<string, PlayerStats>>(match.playerStats || {});
  const [teamADraft, setTeamADraft] = useState<string[]>(match.teamA || []);
  const [teamBDraft, setTeamBDraft] = useState<string[]>(match.teamB || []);

  const [scoreADraft, setScoreADraft] = useState<number>(match.scoreA || 0);
  const [scoreBDraft, setScoreBDraft] = useState<number>(match.scoreB || 0);
  const [retrospectiveAvailability, setRetrospectiveAvailability] = useState<Record<string, 'CONFIRMED' | 'UNAVAILABLE'>>(match.availability || {});
  const [retrospectiveStatus, setRetrospectiveStatus] = useState<Match['status']>(match.status);

  const [retroGoalTeam, setRetroGoalTeam] = useState<'A' | 'B'>('A');
  const [retroGoalScorer, setRetroGoalScorer] = useState<string>('');
  const [retroGoalAssist, setRetroGoalAssist] = useState<string>('');
  const [retroGoalMinute, setRetroGoalMinute] = useState<string>('');
  const [retroGoalComment, setRetroGoalComment] = useState<string>('');

  useEffect(() => {
    setScoreADraft(match.scoreA || 0);
    setScoreBDraft(match.scoreB || 0);
    setEditingStats(match.playerStats || {});
    setRetrospectiveAvailability(match.availability || {});
    setRetrospectiveStatus(match.status);
    setTeamADraft(match.teamA || []);
    setTeamBDraft(match.teamB || []);
  }, [match.id, match.scoreA, match.scoreB, match.playerStats, match.availability, match.status, match.teamA, match.teamB]);

  const [selectedFormation, setSelectedFormation] = useState<string>(match.formation || (club?.type === 'SOCIAL' ? '5-a-side (1-2-1)' : '4-4-2'));
  const [tacticalLineup, setTacticalLineup] = useState<Record<string, string>>(match.tacticalLineup || {});
  const [isAssigningPos, setIsAssigningPos] = useState<string | null>(null);
  const [isSavingTactics, setIsSavingTactics] = useState(false);
  const [draggedOverPosId, setDraggedOverPosId] = useState<string | null>(null);
  const [showBalanceHelper, setShowBalanceHelper] = useState<boolean>(true);
  const [showSubPlanner, setShowSubPlanner] = useState<boolean>(false);
  const [matchDuration, setMatchDuration] = useState<number>(90);
  const [subInterval, setSubInterval] = useState<number>(15);
  const [maxSubsPerWindow, setMaxSubsPerWindow] = useState<number>(2);

  const starPlayerIds = useMemo(() => match.starPlayerIds || [], [match.starPlayerIds]);
  const weakerPlayerIds = useMemo(() => match.weakerPlayerIds || [], [match.weakerPlayerIds]);

  const togglePlayerTier = (playerId: string, tier: 'STAR' | 'WEAKER' | 'STANDARD') => {
    let nextStars = [...starPlayerIds];
    let nextWeakers = [...weakerPlayerIds];

    if (tier === 'STAR') {
      if (nextStars.includes(playerId)) {
        nextStars = nextStars.filter(id => id !== playerId);
      } else {
        nextStars.push(playerId);
        nextWeakers = nextWeakers.filter(id => id !== playerId);
      }
    } else if (tier === 'WEAKER') {
      if (nextWeakers.includes(playerId)) {
        nextWeakers = nextWeakers.filter(id => id !== playerId);
      } else {
        nextWeakers.push(playerId);
        nextStars = nextStars.filter(id => id !== playerId);
      }
    } else {
      nextStars = nextStars.filter(id => id !== playerId);
      nextWeakers = nextWeakers.filter(id => id !== playerId);
    }

    onUpdateMatchData(match.id, {
      starPlayerIds: nextStars,
      weakerPlayerIds: nextWeakers
    });
  };

  const events = useMemo(() => {
    return [...initialEvents].sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
  }, [initialEvents]);

  const teamAName = club?.name || 'Home';
  const teamBName = match.opponentName || 'Away';

  const isMatchOwner = currentUser?.id === club?.ownerId;
  const canModerate = isMatchOwner || club?.members.some(m => m.id === currentUser?.id && m.roles.includes('ADMIN'));
  const isMember = club?.members.some(m => m.id === currentUser?.id);
  
  const availability = match.availability || {};

  const handleSetAvailability = (userId: string, status: 'CONFIRMED' | 'UNAVAILABLE' | null) => {
    const newAvailability = { ...availability };
    if (status === null) {
      delete newAvailability[userId];
    } else {
      newAvailability[userId] = status;
    }
    
    let newSignedUp = [...match.signedUpPlayerIds];
    if (status === 'CONFIRMED') {
      if (!newSignedUp.includes(userId)) newSignedUp.push(userId);
    } else {
      newSignedUp = newSignedUp.filter(id => id !== userId);
    }

    onUpdateMatchData(match.id, { 
      availability: newAvailability,
      signedUpPlayerIds: newSignedUp
    });
  };

  const squadPlayers = useMemo(() => {
    return (club?.members || [])
      .filter(m => m.roles.includes('PLAYER'))
      .map(member => ({
        ...member,
        status: (availability[member.id] || 'PENDING') as 'CONFIRMED' | 'UNAVAILABLE' | 'PENDING'
      }))
      .sort((a, b) => a.name.localeCompare(b.name));
  }, [club?.members, availability]);

  const squadPlayersRetrospective = useMemo(() => {
    return (club?.members || [])
      .filter(m => m.roles.includes('PLAYER'))
      .map(member => ({
        ...member,
        status: (retrospectiveAvailability[member.id] || 'PENDING') as 'CONFIRMED' | 'UNAVAILABLE' | 'PENDING'
      }))
      .sort((a, b) => a.name.localeCompare(b.name));
  }, [club?.members, retrospectiveAvailability]);

  const confirmedSquad = useMemo(() => squadPlayers.filter(p => p.status === 'CONFIRMED'), [squadPlayers]);
  
  const subPlanResult = useMemo(() => {
    if (!club) return null;
    const positions = FORMATIONS[selectedFormation] || FORMATIONS['4-4-2'];
    
    // Find players assigned on pitch
    const pitchPlayerIds = Object.values(tacticalLineup).filter(Boolean);
    const benchPlayerIds = confirmedSquad
      .map(p => p.id)
      .filter(id => !pitchPlayerIds.includes(id));

    if (pitchPlayerIds.length === 0) {
      return { error: 'Please assign players to the pitch first.' };
    }

    // Determine Goalkeeper (usually doesn't rotate)
    const gkPos = positions.find(p => p.label === 'GK');
    const gkPlayerId = gkPos ? tacticalLineup[gkPos.id] : null;

    // Fixed players (GK + Stars who are starting on the pitch)
    const fixedPlayerIds = new Set<string>();
    if (gkPlayerId) fixedPlayerIds.add(gkPlayerId);
    
    // Star players who are starting on the pitch stay on the pitch
    const pitchStarIds = pitchPlayerIds.filter(id => starPlayerIds.includes(id));
    pitchStarIds.forEach(id => fixedPlayerIds.add(id));

    // Rotation pool: all confirmed players who are not in the fixed set
    const rotationPoolIds = confirmedSquad
      .map(p => p.id)
      .filter(id => !fixedPlayerIds.has(id));

    // Pitch slots available for rotation: pitch players who are not in the fixed set
    const rotationPitchIds = pitchPlayerIds.filter(id => !fixedPlayerIds.has(id));

    // Bench slots available for rotation: bench players who are not in the fixed set
    const rotationBenchIds = benchPlayerIds.filter(id => !fixedPlayerIds.has(id));

    if (rotationPoolIds.length === 0) {
      return { 
        error: 'No outfield players available for rotation (everyone assigned is a Star Player or Goalkeeper).',
        fixedPlayers: Array.from(fixedPlayerIds).map(id => confirmedSquad.find(p => p.id === id)?.name).filter(Boolean)
      };
    }

    // Simulation parameters
    const duration = matchDuration;
    const interval = subInterval;
    const stepsCount = Math.floor(duration / interval);

    if (stepsCount <= 1) {
      return { error: 'Match duration and interval must allow at least 2 sub windows.' };
    }

    // Initialize play time stats
    const playTimes: Record<string, number> = {};
    confirmedSquad.forEach(p => {
      playTimes[p.id] = 0;
    });

    // Goalkeepers and Stars in lineup play full duration
    Array.from(fixedPlayerIds).forEach(id => {
      playTimes[id] = duration;
    });

    // Current state of outfield players
    let currentPitch = [...rotationPitchIds];
    let currentBench = [...rotationBenchIds];

    const planEvents: {
      minute: number;
      subs: { playerOut: string; playerIn: string; outName: string; inName: string }[];
      pitchState: string[];
    }[] = [];

    // Simulate interval by interval
    for (let step = 1; step <= stepsCount; step++) {
      const currentMin = (step - 1) * interval;
      
      // Add playtime for players on pitch during this interval
      currentPitch.forEach(id => {
        playTimes[id] = (playTimes[id] || 0) + interval;
      });

      // No subs at the final full-time mark
      if (step === stepsCount) break;

      // Calculate subs at the end of this interval
      const nextMin = step * interval;

      if (currentBench.length > 0 && currentPitch.length > 0) {
        // Sort bench players by playtime ascending (least played first)
        const sortedBench = [...currentBench].sort((a, b) => {
          const diff = (playTimes[a] || 0) - (playTimes[b] || 0);
          if (diff !== 0) return diff;
          // Tie break: prefer weaker players to get game time
          const aWeaker = weakerPlayerIds.includes(a);
          const bWeaker = weakerPlayerIds.includes(b);
          if (aWeaker && !bWeaker) return -1;
          if (!aWeaker && bWeaker) return 1;
          return a.localeCompare(b);
        });

        // Sort pitch players by playtime descending (most played first)
        const sortedPitch = [...currentPitch].sort((a, b) => {
          const diff = (playTimes[b] || 0) - (playTimes[a] || 0);
          if (diff !== 0) return diff;
          // Tie break: sub off stronger players first to rest them
          const aStar = starPlayerIds.includes(a);
          const bStar = starPlayerIds.includes(b);
          if (aStar && !bStar) return 1;
          if (!aStar && bStar) return -1;
          return a.localeCompare(b);
        });

        // Determine how many players to swap
        const swapCount = Math.min(sortedBench.length, sortedPitch.length, maxSubsPerWindow);

        const intervalSubs: { playerOut: string; playerIn: string; outName: string; inName: string }[] = [];
        const nextPitch = [...currentPitch];
        const nextBench = [...currentBench];

        for (let i = 0; i < swapCount; i++) {
          const pOut = sortedPitch[i];
          const pIn = sortedBench[i];

          const outName = confirmedSquad.find(p => p.id === pOut)?.name || 'Unknown';
          const inName = confirmedSquad.find(p => p.id === pIn)?.name || 'Unknown';

          intervalSubs.push({ playerOut: pOut, playerIn: pIn, outName, inName });

          // Update lists
          const outIdx = nextPitch.indexOf(pOut);
          if (outIdx !== -1) nextPitch[outIdx] = pIn;

          const inIdx = nextBench.indexOf(pIn);
          if (inIdx !== -1) nextBench[inIdx] = pOut;
        }

        currentPitch = nextPitch;
        currentBench = nextBench;

        planEvents.push({
          minute: nextMin,
          subs: intervalSubs,
          pitchState: [...currentPitch]
        });
      }
    }

    return {
      events: planEvents,
      playTimes,
      fixedPlayerIds: Array.from(fixedPlayerIds)
    };
  }, [club, tacticalLineup, confirmedSquad, starPlayerIds, weakerPlayerIds, matchDuration, subInterval, maxSubsPerWindow, selectedFormation]);
  
  const startingLineup = useMemo(() => 
    confirmedSquad.filter(p => match.startingLineupIds?.includes(p.id)), 
  [confirmedSquad, match.startingLineupIds]);

  const bench = useMemo(() => 
    confirmedSquad.filter(p => match.benchIds?.includes(p.id)), 
  [confirmedSquad, match.benchIds]);

  const unassigned = useMemo(() => 
    confirmedSquad.filter(p => !match.startingLineupIds?.includes(p.id) && !match.benchIds?.includes(p.id)), 
  [confirmedSquad, match.startingLineupIds, match.benchIds]);

  const balanceFeedback = useMemo(() => {
    if (!club) return [];
    const activePositions = FORMATIONS[selectedFormation] || FORMATIONS['4-4-2'];
    
    // Find all players currently in the lineup
    const lineupPlayers = activePositions.map(pos => {
      const pId = tacticalLineup[pos.id];
      const player = club.members.find(m => m.id === pId);
      return {
        posId: pos.id,
        posLabel: pos.label,
        x: pos.x,
        y: pos.y,
        player,
        rating: player?.abilityRating || 0
      };
    });

    const results: {
      type: 'success' | 'warning' | 'info';
      message: string;
      player1Id?: string;
      pos1Id?: string;
    }[] = [];

    // Filter assigned players with rating between 1 and 2 (Developing / Weak)
    const developingPlayers = lineupPlayers.filter(lp => lp.player && lp.rating > 0 && lp.rating <= 2);

    developingPlayers.forEach(dp => {
      // Find neighbors: sort other positions by distance
      const otherPositions = lineupPlayers.filter(lp => lp.posId !== dp.posId);
      const withDistance = otherPositions.map(op => {
        const dist = Math.sqrt(Math.pow(dp.x - op.x, 2) + Math.pow(dp.y - op.y, 2));
        return { ...op, dist };
      });
      withDistance.sort((a, b) => a.dist - b.dist);
      
      const neighbors = withDistance.slice(0, 2);
      const strongSupports = neighbors.filter(n => n.player && n.rating >= 3);
      
      if (strongSupports.length > 0) {
        results.push({
          type: 'success',
          message: `Good Coverage: ${dp.player!.name} (${dp.posLabel}) is supported by strong players nearby: ${strongSupports.map(s => `${s.player!.name} (${s.posLabel})`).join(', ')}.`,
          player1Id: dp.player!.id,
          pos1Id: dp.posId
        });
      } else {
        const neighborLabels = neighbors.map(n => n.posLabel).join(' or ');
        results.push({
          type: 'warning',
          message: `Vulnerable Spot: ${dp.player!.name} (${dp.posLabel}) is developing. Try placing a stronger player (⭐⭐⭐+) nearby at ${neighborLabels} to support them.`,
          player1Id: dp.player!.id,
          pos1Id: dp.posId
        });
      }
    });

    // Also list unrated players in the lineup
    const unratedLineupPlayers = lineupPlayers.filter(lp => lp.player && !lp.rating);
    if (unratedLineupPlayers.length > 0) {
      results.push({
        type: 'info',
        message: `Help: You have unrated players starting (${unratedLineupPlayers.map(p => p.player!.name).join(', ')}). Rate them in the Confirmed Pool to get balance recommendations.`
      });
    }

    if (developingPlayers.length === 0 && lineupPlayers.some(lp => lp.player) && unratedLineupPlayers.length === 0) {
      results.push({
        type: 'info',
        message: "Lineup is perfectly balanced! Excellent team structure with solid ability pairing."
      });
    }

    return results;
  }, [club, tacticalLineup, selectedFormation]);

  const handleMoveToLineup = (userId: string) => {
    const newStarting = [...(match.startingLineupIds || [])];
    const newBench = (match.benchIds || []).filter(id => id !== userId);
    if (!newStarting.includes(userId)) newStarting.push(userId);
    onUpdateMatchData(match.id, { startingLineupIds: newStarting, benchIds: newBench });
  };

  const handleMoveToBench = (userId: string) => {
    const newBench = [...(match.benchIds || [])];
    const newStarting = (match.startingLineupIds || []).filter(id => id !== userId);
    if (!newBench.includes(userId)) newBench.push(userId);
    onUpdateMatchData(match.id, { startingLineupIds: newStarting, benchIds: newBench });
  };

  const handleUnassign = (userId: string) => {
    const newStarting = (match.startingLineupIds || []).filter(id => id !== userId);
    const newBench = (match.benchIds || []).filter(id => id !== userId);
    onUpdateMatchData(match.id, { startingLineupIds: newStarting, benchIds: newBench });
  };

  const handleAutoFill = () => {
    const unassignedPlayers = [...confirmedSquad];
    const newTacticalLineup: Record<string, string> = {};
    const positions = FORMATIONS[selectedFormation] || FORMATIONS['4-4-2'];

    // 1. Try to match GK first
    const gkPos = positions.find(p => p.label === 'GK');
    if (gkPos) {
      const gkIndex = unassignedPlayers.findIndex(p => 
        p.favPosition?.toLowerCase().includes('gk') || 
        p.favPosition?.toLowerCase().includes('goal') ||
        p.favPosition?.toLowerCase().includes('keeper')
      );
      if (gkIndex !== -1) {
        newTacticalLineup[gkPos.id] = unassignedPlayers[gkIndex].id;
        unassignedPlayers.splice(gkIndex, 1);
      }
    }

    // 2. Try to match exact/soft favorite positions for outfield roles
    positions.forEach(pos => {
      if (pos.label === 'GK') return; // GK handled
      
      const labelLower = pos.label.toLowerCase();
      let matchIdx = -1;

      if (labelLower.includes('st') || labelLower.includes('cf') || labelLower.includes('lw') || labelLower.includes('rw')) {
        // Forward
        matchIdx = unassignedPlayers.findIndex(p => {
          const fav = p.favPosition?.toLowerCase() || '';
          return fav.includes('st') || fav.includes('striker') || fav.includes('forward') || fav.includes('lw') || fav.includes('rw') || fav.includes('wing') || fav.includes('attack');
        });
      } else if (labelLower.includes('m') || labelLower.includes('dm') || labelLower.includes('am')) {
        // Midfielder
        matchIdx = unassignedPlayers.findIndex(p => {
          const fav = p.favPosition?.toLowerCase() || '';
          return fav.includes('mid') || fav.includes('cm') || fav.includes('cdm') || fav.includes('cam') || fav.includes('lm') || fav.includes('rm') || fav.includes('centre') || fav.includes('center');
        });
      } else if (labelLower.includes('b') || labelLower.includes('cb') || labelLower.includes('lb') || labelLower.includes('rb')) {
        // Defender
        matchIdx = unassignedPlayers.findIndex(p => {
          const fav = p.favPosition?.toLowerCase() || '';
          return fav.includes('def') || fav.includes('back') || fav.includes('cb') || fav.includes('lb') || fav.includes('rb') || fav.includes('lwb') || fav.includes('rwb');
        });
      }

      if (matchIdx !== -1) {
        newTacticalLineup[pos.id] = unassignedPlayers[matchIdx].id;
        unassignedPlayers.splice(matchIdx, 1);
      }
    });

    // 3. Fill any remaining spots with remaining players
    positions.forEach(pos => {
      if (!newTacticalLineup[pos.id] && unassignedPlayers.length > 0) {
        newTacticalLineup[pos.id] = unassignedPlayers[0].id;
        unassignedPlayers.splice(0, 1);
      }
    });

    setTacticalLineup(newTacticalLineup);
  };

  const handleShareLineupToFeed = () => {
    const positions = FORMATIONS[selectedFormation] || FORMATIONS['4-4-2'];
    const startersList = positions
      .map(pos => {
        const pId = tacticalLineup[pos.id];
        const p = confirmedSquad.find(player => player.id === pId);
        return p ? `${p.name} (${pos.label})` : null;
      })
      .filter(Boolean);

    if (startersList.length === 0) return;

    const content = `📋 Tactical Lineup Announced! Formation: ${selectedFormation}. Starting XI: ${startersList.join(', ')}.`;
    onAddEvent({ type: 'COMMENT', content });
  };

  const handleSaveTactics = async () => {
    setIsSavingTactics(true);
    const updatedLineupPlayerIds = Object.values(tacticalLineup).filter(Boolean);
    const unassignedPlayerIds = confirmedSquad
      .filter(p => !updatedLineupPlayerIds.includes(p.id))
      .map(p => p.id);

    try {
      await onUpdateMatchData(match.id, {
        formation: selectedFormation,
        tacticalLineup: tacticalLineup,
        startingLineupIds: updatedLineupPlayerIds,
        benchIds: unassignedPlayerIds
      });
      setTimeout(() => {
        setIsSavingTactics(false);
      }, 500);
    } catch (e) {
      setIsSavingTactics(false);
    }
  };

  const potmResults = useMemo(() => {
    const counts: Record<string, number> = {};
    if (!match.potmVotes) return counts;
    (Object.values(match.potmVotes) as string[]).forEach((playerId: string) => {
      counts[playerId] = (counts[playerId] || 0) + 1;
    });
    return counts;
  }, [match.potmVotes]);

  const totalVotes = useMemo(() => 
    (Object.values(potmResults) as number[]).reduce((a: number, b: number) => a + b, 0), 
  [potmResults]);

  const hasVoted = useMemo(() => 
    currentUser && match.potmVotes && !!match.potmVotes[currentUser.id], 
  [match.potmVotes, currentUser]);

  const liveIconMapping: Record<string, React.ReactNode> = {
    'GOAL': <Goal className="w-4 h-4 text-green-500 fill-current" />,
    'START': <Play className="w-4 h-4 text-blue-500 fill-current" />,
    'HALF_TIME': <Clock className="w-4 h-4 text-orange-500" />,
    'SECOND_HALF': <Play className="w-4 h-4 text-blue-500 fill-current" />,
    'END': <Flag className="w-4 h-4 text-red-500 fill-current" />,
    'COMMENT': <MessageSquare className="w-4 h-4 text-slate-500" />,
    'YELLOW_CARD': <AlertTriangle className="w-4 h-4 text-yellow-500 fill-current" />,
    'RED_CARD': <AlertOctagon className="w-4 h-4 text-red-600 fill-current" />,
    'CANCELLED': <AlertCircle className="w-4 h-4 text-red-500 fill-current" />,
    'SUB': <ArrowRightLeft className="w-4 h-4 text-orange-500" />
  };

  const hasHalfTime = useMemo(() => initialEvents.some(e => e.type === 'HALF_TIME'), [initialEvents]);
  const hasSecondHalf = useMemo(() => initialEvents.some(e => e.type === 'SECOND_HALF'), [initialEvents]);
  const isMatchInPlay = match.status === 'LIVE' && (!hasHalfTime || hasSecondHalf);

  const handleActionClick = (type: EventType) => {
    // Request notification permission on first interaction (needed for mobile browsers)
    if ('Notification' in window && Notification.permission === 'default') {
      Notification.requestPermission();
    }

    if (!isMatchInPlay) return; 
    if (activeActionType === type) {
      setActiveActionType(null);
    } else {
      setActiveActionType(type);
      setSelectedPlayerId('');
      setSelectedPlayerId2('');
      setSelectedTeam('A');
    }
  };

  const handleMatchProgression = () => {
    if (match.status === 'UPCOMING') {
      onUpdateStatus('LIVE');
      onAddEvent({ type: 'START', content: 'Match started! Kick off!' });
    } else if (match.status === 'LIVE') {
      if (!hasHalfTime) {
        onAddEvent({ type: 'HALF_TIME', content: 'Half Time! The referee blows for the break.' });
        setActiveActionType(null); 
      } else if (!hasSecondHalf) {
        onAddEvent({ type: 'SECOND_HALF', content: 'Second Half underway! Let’s get back to it.' });
      } else {
        onUpdateStatus('COMPLETED');
        onAddEvent({ type: 'END', content: 'Full time! The match has ended.' });
        setActiveActionType(null);
      }
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmitAction = (e: React.FormEvent) => {
    e.preventDefault();
    const typeToUse = selectedImage ? 'MEDIA' : (activeActionType || 'COMMENT');
    
    if (typeToUse !== 'COMMENT' && typeToUse !== 'MEDIA' && !isMatchInPlay) {
      setActiveActionType(null);
      return;
    }

    const p1Name = squadPlayers.find(p => p.id === selectedPlayerId)?.name || 'Someone';
    const p2Name = squadPlayers.find(p => p.id === selectedPlayerId2)?.name || 'Someone';
    const teamName = selectedTeam === 'A' ? teamAName : teamBName;
    
    let content = newEventContent;
    let details: any = { team: selectedTeam };

    if (typeToUse === 'GOAL') {
      content = `GOAL for ${teamName}! ${selectedPlayerId ? `Scored by ${p1Name}.` : ''} ${newEventContent}`;
      if (selectedPlayerId) details = { ...details, scorer: selectedPlayerId };
      
      if (selectedTeam === 'A') {
        onUpdateMatchData(match.id, { scoreA: (match.scoreA || 0) + 1 });
      } else {
        onUpdateMatchData(match.id, { scoreB: (match.scoreB || 0) + 1 });
      }
    } else if (typeToUse === 'YELLOW_CARD') {
      content = `YELLOW CARD (${teamName}) ${selectedPlayerId ? `shown to ${p1Name}.` : ''} ${newEventContent}`;
      if (selectedPlayerId) details = { ...details, player: selectedPlayerId };
    } else if (typeToUse === 'RED_CARD') {
      content = `RED CARD (${teamName}) ${selectedPlayerId ? `shown to ${p1Name}.` : ''} ${newEventContent}`;
      if (selectedPlayerId) details = { ...details, player: selectedPlayerId };
    } else if (typeToUse === 'SUB') {
      if (selectedTeam === 'A') {
        content = `SUBSTITUTION (${teamName}): ${p1Name} OFF, ${p2Name} ON.`;
        details = { ...details, playerOut: selectedPlayerId, playerIn: selectedPlayerId2 };
      } else {
        content = `SUBSTITUTION for ${teamName}. ${newEventContent}`;
      }
    } else if (typeToUse === 'MEDIA') {
      content = newEventContent || 'Shared a photo from the match';
    }

    if (!content && typeToUse === 'COMMENT' && !selectedImage) return;
    if (!content && !selectedImage) content = `${typeToUse} recorded for ${teamName}`;

    onAddEvent({ 
      type: typeToUse, 
      content, 
      details,
      mediaUrl: selectedImage || undefined
    });
    
    setNewEventContent('');
    setSelectedPlayerId('');
    setSelectedPlayerId2('');
    setActiveActionType(null);
    setSelectedImage(null);
  };

  const handleSaveSummary = () => {
    onUpdateMatchData(match.id, { managerSummary: summaryDraft });
    setIsEditingSummary(false);
  };

  const handleSaveSocialStats = () => {
    onUpdateMatchData(match.id, { 
      playerStats: editingStats,
      teamA: teamADraft,
      teamB: teamBDraft
    });
  };

  const handleTogglePlayed = (playerId: string, played: boolean) => {
    setRetrospectiveAvailability(prev => ({
      ...prev,
      [playerId]: played ? 'CONFIRMED' : 'UNAVAILABLE'
    }));

    if (played) {
      updatePlayerStat(playerId, 'minutesPlayed', editingStats[playerId]?.minutesPlayed || 90);
    } else {
      updatePlayerStat(playerId, 'minutesPlayed', 0);
      updatePlayerStat(playerId, 'goals', 0);
      updatePlayerStat(playerId, 'assists', 0);
      updatePlayerStat(playerId, 'yellowCards', 0);
      updatePlayerStat(playerId, 'redCards', 0);
      if (club?.type === 'SOCIAL') {
        updatePlayerStat(playerId, 'ballsOverFence', 0);
        updatePlayerStat(playerId, 'isInjured', false);
        updatePlayerStat(playerId, 'isLastMinuteDropout', false);
      }
    }
  };

  const handleAddRetroGoal = (e: React.FormEvent) => {
    e.preventDefault();
    
    const teamName = retroGoalTeam === 'A' ? teamAName : teamBName;
    const scorerName = squadPlayers.find(p => p.id === retroGoalScorer)?.name || '';
    const assistName = squadPlayers.find(p => p.id === retroGoalAssist)?.name || '';
    
    let content = `GOAL for ${teamName}!`;
    if (retroGoalScorer && retroGoalScorer !== 'opponent') {
      content += ` Scored by ${scorerName}.`;
    } else {
      content += ` Scored by Opponent/Other.`;
    }
    if (retroGoalAssist && retroGoalAssist !== 'opponent') {
      content += ` Assisted by ${assistName}.`;
    }
    if (retroGoalMinute) {
      content += ` (${retroGoalMinute}')`;
    }
    if (retroGoalComment) {
      content += ` - ${retroGoalComment}`;
    }

    onAddEvent({
      type: 'GOAL',
      content,
      details: {
        team: retroGoalTeam,
        scorer: (retroGoalScorer && retroGoalScorer !== 'opponent') ? retroGoalScorer : undefined,
        assist: (retroGoalAssist && retroGoalAssist !== 'opponent') ? retroGoalAssist : undefined
      }
    });

    if (retroGoalTeam === 'A') {
      setScoreADraft(prev => prev + 1);
    } else {
      setScoreBDraft(prev => prev + 1);
    }

    if (retroGoalScorer && retroGoalScorer !== 'opponent') {
      setRetrospectiveAvailability(prev => ({
        ...prev,
        [retroGoalScorer]: 'CONFIRMED'
      }));
      setEditingStats(prev => {
        const currentStats = prev[retroGoalScorer] || { goals: 0, assists: 0, yellowCards: 0, redCards: 0, ballsOverFence: 0, isInjured: false, isLastMinuteDropout: false, minutesPlayed: 90 };
        return {
          ...prev,
          [retroGoalScorer]: {
            ...currentStats,
            goals: (currentStats.goals || 0) + 1,
            minutesPlayed: currentStats.minutesPlayed || 90
          }
        };
      });
    }

    if (retroGoalAssist && retroGoalAssist !== 'opponent') {
      setRetrospectiveAvailability(prev => ({
        ...prev,
        [retroGoalAssist]: 'CONFIRMED'
      }));
      setEditingStats(prev => {
        const currentStats = prev[retroGoalAssist] || { goals: 0, assists: 0, yellowCards: 0, redCards: 0, ballsOverFence: 0, isInjured: false, isLastMinuteDropout: false, minutesPlayed: 90 };
        return {
          ...prev,
          [retroGoalAssist]: {
            ...currentStats,
            assists: (currentStats.assists || 0) + 1,
            minutesPlayed: currentStats.minutesPlayed || 90
          }
        };
      });
    }

    setRetroGoalScorer('');
    setRetroGoalAssist('');
    setRetroGoalMinute('');
    setRetroGoalComment('');
  };

  const handleSaveRetrospectiveData = () => {
    onUpdateMatchData(match.id, {
      scoreA: scoreADraft,
      scoreB: scoreBDraft,
      playerStats: editingStats,
      availability: retrospectiveAvailability,
      teamA: teamADraft,
      teamB: teamBDraft,
      status: retrospectiveStatus
    });
  };

  const updatePlayerStat = (userId: string, field: keyof PlayerStats, value: any) => {
    setEditingStats(prev => ({
      ...prev,
      [userId]: {
        ...(prev[userId] || { goals: 0, assists: 0, yellowCards: 0, redCards: 0, ballsOverFence: 0, isInjured: false, isLastMinuteDropout: false }),
        [field]: value
      }
    }));
  };

  const toggleTeamAssignment = (userId: string, team: 'A' | 'B' | null) => {
    setTeamADraft(prev => prev.filter(id => id !== userId));
    setTeamBDraft(prev => prev.filter(id => id !== userId));
    
    if (team === 'A') setTeamADraft(prev => [...prev, userId]);
    if (team === 'B') setTeamBDraft(prev => [...prev, userId]);
  };

  const handleSuggestTeams = () => {
    if (!allMatches || !club) return;

    const players = match.signedUpPlayerIds || [];
    if (players.length === 0) return;

    const playerWinRates: Record<string, number> = {};
    
    players.forEach(pid => {
      let wins = 0;
      let total = 0;
      
      allMatches.forEach(m => {
        if (m.clubId === club.id && m.status === 'COMPLETED') {
          const teamA = m.teamA || [];
          const teamB = m.teamB || [];
          const scoreA = m.scoreA || 0;
          const scoreB = m.scoreB || 0;

          if (teamA.includes(pid)) {
            total++;
            if (scoreA > scoreB) wins++;
          } else if (teamB.includes(pid)) {
            total++;
            if (scoreB > scoreA) wins++;
          }
        }
      });
      
      playerWinRates[pid] = total > 0 ? wins / total : 0.5;
    });

    const sortedPlayers = [...players].sort((a, b) => playerWinRates[b] - playerWinRates[a]);

    const teamA: string[] = [];
    const teamB: string[] = [];

    sortedPlayers.forEach((pid, idx) => {
      if (idx % 2 === 0) {
        teamA.push(pid);
      } else {
        teamB.push(pid);
      }
    });

    setTeamADraft(teamA);
    setTeamBDraft(teamB);
  };

  const handleStartEdit = (event: FeedEvent) => {
    setEditingEventId(event.id);
    setEditContent(event.content);
  };

  const handleSaveEdit = (eventId: string) => {
    if (editContent.trim()) {
      onUpdateEvent(eventId, editContent);
    }
    setEditingEventId(null);
  };

  const handleFetchIntel = async () => {
    setIsFetchingIntel(true);
    try {
      const data = await getMatchIntel(match.location, match.date, match.kickOffTime);
      setIntel(data);
    } catch (e) {
      onApiKeyTrouble();
    } finally {
      setIsFetchingIntel(false);
    }
  };

  const progressionButton = useMemo(() => {
    if (match.status === 'UPCOMING') {
      return { label: 'Kick Off', icon: <Play className="w-5 h-5 fill-current" />, color: 'bg-blue-600 text-white shadow-blue-200' };
    }
    if (match.status === 'LIVE') {
      if (!hasHalfTime) {
        return { label: 'Half Time', icon: <Coffee className="w-5 h-5" />, color: 'bg-orange-500 text-white shadow-orange-200' };
      }
      if (!hasSecondHalf) {
        return { label: 'Start 2nd Half', icon: <Play className="w-5 h-5 fill-current" />, color: 'bg-blue-600 text-white shadow-blue-200' };
      }
      return { label: 'Full Time', icon: <Flag className="w-5 h-5" />, color: 'bg-slate-900 text-white shadow-slate-200' };
    }
    return null;
  }, [match.status, hasHalfTime, hasSecondHalf]);

  const renderPlayerRow = (player: any) => {
    const canToggle = canModerate || (currentUser?.id === player.id);
    return (
      <div key={player.id} className="flex items-center justify-between p-4 bg-white rounded-2xl border border-slate-100 shadow-sm hover:border-slate-200 transition-all group">
        <div className="flex items-center gap-4">
          <div className="relative">
            <img src={player.avatar || `https://i.pravatar.cc/100?u=${player.id}`} className="w-10 h-10 rounded-xl object-cover border border-slate-100" alt="" />
            {player.id === currentUser?.id && (
              <div className="absolute -top-1 -right-1 bg-blue-600 w-3 h-3 rounded-full border-2 border-white"></div>
            )}
          </div>
          <div>
            <p className="text-sm font-black text-slate-900 leading-tight">{player.name} {player.id === currentUser?.id && <span className="text-blue-500 ml-1">(You)</span>}</p>
            <p className="text-[9px] font-black uppercase text-slate-400 tracking-widest mt-0.5">
              {player.roles.includes('ADMIN') ? 'Manager' : 'Player'}
            </p>
          </div>
        </div>

        {canToggle ? (
          <div className="flex items-center gap-2">
            <button 
              onClick={() => handleSetAvailability(player.id, player.status === 'CONFIRMED' ? null : 'CONFIRMED')}
              className={`p-2.5 rounded-xl border transition-all ${
                player.status === 'CONFIRMED' 
                  ? 'bg-green-600 text-white border-green-700 shadow-md shadow-green-100' 
                  : 'bg-white text-slate-300 border-slate-100 hover:text-green-600 hover:border-green-100 hover:bg-green-50'
              }`}
              title="Confirm Availability"
            >
              <UserCheck className="w-4 h-4" />
            </button>
            <button 
              onClick={() => handleSetAvailability(player.id, player.status === 'UNAVAILABLE' ? null : 'UNAVAILABLE')}
              className={`p-2.5 rounded-xl border transition-all ${
                player.status === 'UNAVAILABLE' 
                  ? 'bg-red-600 text-white border-red-700 shadow-md shadow-red-100' 
                  : 'bg-white text-slate-300 border-slate-100 hover:text-red-600 hover:border-red-100 hover:bg-red-50'
              }`}
              title="Mark Unavailable"
            >
              <UserX className="w-4 h-4" />
            </button>
          </div>
        ) : (
          <div className={`px-3 py-1.5 rounded-lg text-[9px] font-black uppercase tracking-widest flex items-center gap-1.5 border ${
            player.status === 'CONFIRMED' ? 'bg-green-50 text-green-700 border-green-100' :
            player.status === 'UNAVAILABLE' ? 'bg-red-50 text-red-700 border-red-100' :
            'bg-slate-50 text-slate-400 border-slate-100'
          }`}>
            {player.status === 'CONFIRMED' && <UserCheck className="w-3 h-3" />}
            {player.status === 'UNAVAILABLE' && <UserX className="w-3 h-3" />}
            {player.status}
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="flex flex-col h-[calc(100vh-8.5rem)] md:h-[calc(100vh-6.5rem)] bg-slate-50 rounded-2xl sm:rounded-[2.5rem] p-2.5 xs:p-4 md:p-6 shadow-xl border border-slate-200 overflow-hidden relative">
      <div className="flex items-center gap-2 mb-2 sm:mb-6 shrink-0 min-w-0">
        {onBack && (
          <button 
            onClick={onBack} 
            className="p-1.5 hover:bg-slate-100 rounded-xl transition-all text-slate-600 shrink-0"
            title="Back to Dashboard"
          >
            <ChevronRight className="w-5 h-5 rotate-180" />
          </button>
        )}
        <div className="min-w-0 flex-1 pr-1">
          <h1 className="text-base sm:text-2xl md:text-3xl font-black text-slate-900 leading-none truncate">{match.title}</h1>
          <p className="text-[10px] sm:text-xs text-slate-500 flex flex-wrap items-center gap-x-2 gap-y-0.5 mt-1">
            <span className="flex items-center gap-1 min-w-0 truncate"><MapPin className="w-3 h-3 text-red-400 shrink-0" /> {match.location}</span>
            <span className="hidden sm:inline w-1 h-1 bg-slate-300 rounded-full shrink-0"></span>
            <span className="flex items-center gap-1 shrink-0"><Clock className="w-3 h-3 text-slate-400 shrink-0" /> {match.kickOffTime}</span>
          </p>
        </div>
        <button 
          onClick={handleFetchIntel}
          disabled={isFetchingIntel}
          className="bg-white p-2.5 sm:p-3 rounded-xl sm:rounded-2xl border border-slate-200 shadow-sm hover:bg-slate-50 transition-all group shrink-0"
        >
          {isFetchingIntel ? <RefreshCw className="w-4 h-4 sm:w-5 sm:h-5 animate-spin text-blue-600" /> : <CloudSun className="w-4 h-4 sm:w-5 sm:h-5 text-blue-500 group-hover:scale-110 transition-transform" />}
        </button>
        {canModerate && onDeleteMatch && (
          <button 
            onClick={() => setShowDeleteConfirm(true)}
            className="bg-white p-2.5 sm:p-3 rounded-xl sm:rounded-2xl border border-slate-200 hover:border-red-100 shadow-sm hover:bg-red-50 text-red-500 transition-all group shrink-0"
            title="Delete Match"
          >
            <Trash2 className="w-4 h-4 sm:w-5 sm:h-5 group-hover:scale-110 transition-transform" />
          </button>
        )}
      </div>
      
      <div className="flex gap-1 p-1 bg-slate-200/50 rounded-2xl mb-1.5 sm:mb-4 shrink-0">
        {club?.type !== 'SOCIAL' && (
          <button 
            onClick={() => setActiveView('FEED')}
            className={`flex-1 flex items-center justify-center gap-1.5 sm:gap-2 py-2 sm:py-3 rounded-xl text-[9px] sm:text-[10px] font-black uppercase tracking-widest transition-all ${activeView === 'FEED' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
          >
            <History className="w-3.5 h-3.5 sm:w-4 sm:h-4" /> Live Feed
          </button>
        )}
        <button 
          onClick={() => setActiveView('STATS')}
          className={`flex-1 flex items-center justify-center gap-1.5 sm:gap-2 py-2 sm:py-3 rounded-xl text-[9px] sm:text-[10px] font-black uppercase tracking-widest transition-all ${activeView === 'STATS' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
        >
          <Trophy className="w-3.5 h-3.5 sm:w-4 sm:h-4" /> Stats
        </button>
        <button 
          onClick={() => setActiveView('SQUAD')}
          className={`flex-1 flex items-center justify-center gap-1.5 sm:gap-2 py-2 sm:py-3 rounded-xl text-[9px] sm:text-[10px] font-black uppercase tracking-widest transition-all ${activeView === 'SQUAD' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
        >
          <LayoutGrid className="w-3.5 h-3.5 sm:w-4 sm:h-4" /> Squad
        </button>
        {canModerate && (
          <button 
            onClick={() => setActiveView('TACTICS')}
            className={`flex-1 flex items-center justify-center gap-1.5 sm:gap-2 py-2 sm:py-3 rounded-xl text-[9px] sm:text-[10px] font-black uppercase tracking-widest transition-all ${activeView === 'TACTICS' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
          >
            <Users className="w-3.5 h-3.5 sm:w-4 sm:h-4" /> Tactics
          </button>
        )}
      </div>

      {(activeView === 'FEED' || activeView === 'STATS') && (
        <div className={`flex items-center justify-center ${club?.type === 'SOCIAL' ? 'gap-1.5 py-1 px-3 mb-1.5' : 'gap-4 sm:gap-8 py-1.5 px-3 sm:py-3 mb-1.5 sm:mb-4 bg-white'} rounded-xl sm:rounded-3xl border border-slate-100 shadow-sm shrink-0`}>
          <div className="text-right flex-1 min-w-0">
            <p className="text-[7px] sm:text-[10px] font-black uppercase tracking-widest text-slate-400 mb-0.5 truncate">{teamAName}</p>
            <p className={`${club?.type === 'SOCIAL' ? 'text-base sm:text-xl' : 'text-lg sm:text-3xl'} font-black text-slate-900 tabular-nums leading-none`}>{match.scoreA}</p>
          </div>
          <div className="flex flex-col items-center mx-1">
            <div className={`w-px ${club?.type === 'SOCIAL' ? 'h-2 sm:h-4' : 'h-3 sm:h-6'} bg-slate-100 mb-0.5`}></div>
            <span className="text-[7px] sm:text-[10px] font-black text-slate-300 uppercase tracking-widest">VS</span>
          </div>
          <div className="text-left flex-1 min-w-0">
            <p className="text-[7px] sm:text-[10px] font-black uppercase tracking-widest text-slate-400 mb-0.5 truncate">{teamBName}</p>
            <p className={`${club?.type === 'SOCIAL' ? 'text-base sm:text-xl' : 'text-lg sm:text-3xl'} font-black text-slate-900 tabular-nums leading-none`}>{match.scoreB}</p>
          </div>
        </div>
      )}

      <div className="flex-1 overflow-y-auto min-h-0 scrollbar-hide">
        {activeView === 'FEED' ? (
          <div className="space-y-3 sm:space-y-6 pb-28 sm:pb-36 md:pb-32">
            {intel && (
              <div className="bg-gradient-to-br from-blue-600 to-indigo-700 p-3 sm:p-5 rounded-xl sm:rounded-[2rem] text-white shadow-md animate-in slide-in-from-top-4 duration-500">
                <button 
                  onClick={() => setIsIntelExpanded(!isIntelExpanded)}
                  className="w-full flex items-center justify-between focus:outline-none"
                >
                  <div className="flex items-center gap-2 sm:gap-3">
                    <div className="p-1 sm:p-2 bg-white/20 rounded-lg">
                      <CloudSun className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-white" />
                    </div>
                    <h4 className="font-black text-[9px] sm:text-xs uppercase tracking-widest text-left">Venue Intelligence</h4>
                  </div>
                  <ChevronUp className={`w-4 h-4 transition-transform duration-200 shrink-0 ${isIntelExpanded ? '' : 'rotate-180'}`} />
                </button>
                
                {isIntelExpanded && (
                  <div className="space-y-2 sm:space-y-3 mt-2 sm:mt-3 pt-2 sm:pt-3 border-t border-white/10 animate-in fade-in duration-200">
                    <div className="flex items-start gap-2 sm:gap-3">
                      <Wind className="w-3.5 h-3.5 text-blue-200 shrink-0 mt-0.5" />
                      <p className="text-xs sm:text-sm font-medium leading-relaxed">{intel.weather}</p>
                    </div>
                    {intel.links && intel.links.length > 0 && (
                      <div className="flex flex-wrap gap-1.5 sm:gap-2 pt-1 sm:pt-2">
                        {intel.links.map((link, idx) => (
                          <a key={idx} href={link.uri} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1.5 bg-white/10 hover:bg-white/20 px-2.5 py-1 sm:px-4 sm:py-2 rounded-lg sm:rounded-xl text-[8px] sm:text-[10px] font-black uppercase tracking-widest transition-all border border-white/10">
                            <ExternalLink className="w-2 h-2 sm:w-3 h-3" /> {link.title}
                          </a>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}

            {match.status === 'COMPLETED' && (
              <div className="bg-white p-4 sm:p-8 rounded-2xl sm:rounded-[2.5rem] border border-slate-200 shadow-sm space-y-4 sm:space-y-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5 sm:gap-3">
                    <div className="p-2 sm:p-3 bg-blue-100 text-blue-600 rounded-xl sm:rounded-2xl">
                      <BookOpen className="w-5 h-5 sm:w-6 sm:h-6" />
                    </div>
                    <div>
                      <h3 className="text-base sm:text-lg font-black text-slate-900 tracking-tight">Manager's Summary</h3>
                      <p className="text-[9px] sm:text-[10px] font-black text-slate-400 uppercase tracking-widest">Post-match analysis</p>
                    </div>
                  </div>
                  {canModerate && !isEditingSummary && (
                    <button 
                      onClick={() => setIsEditingSummary(true)}
                      className="p-1.5 sm:p-2 hover:bg-slate-50 rounded-xl transition-all text-blue-600"
                    >
                      <Edit2 className="w-4.5 h-4.5 sm:w-5 sm:h-5" />
                    </button>
                  )}
                </div>

                {isEditingSummary ? (
                  <div className="space-y-3 sm:space-y-4">
                    <textarea
                      value={summaryDraft}
                      onChange={(e) => setSummaryDraft(e.target.value)}
                      placeholder="Write your match summary here..."
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl sm:rounded-2xl p-3 sm:p-4 text-xs sm:text-sm font-medium focus:outline-none focus:ring-4 focus:ring-blue-500/10 min-h-[120px] sm:min-h-[150px]"
                    />
                    <div className="flex gap-2">
                      <button 
                        onClick={handleSaveSummary}
                        className="flex-1 bg-blue-600 text-white py-2.5 sm:py-3 rounded-xl font-black text-[10px] uppercase tracking-widest shadow-lg shadow-blue-100"
                      >
                        Save Summary
                      </button>
                      <button 
                        onClick={() => setIsEditingSummary(false)}
                        className="px-4 sm:px-6 bg-slate-100 text-slate-500 py-2.5 sm:py-3 rounded-xl font-black text-[10px] uppercase tracking-widest"
                      >
                        Cancel
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="relative">
                    {match.managerSummary ? (
                      <p className="text-xs sm:text-sm text-slate-600 font-medium leading-relaxed italic">
                        "{match.managerSummary}"
                      </p>
                    ) : (
                      <div className="py-4 sm:py-6 text-center border-2 border-dashed border-slate-100 rounded-xl sm:rounded-2xl">
                        <p className="text-xs sm:text-sm text-slate-400 font-medium italic">No manager summary added yet.</p>
                        {canModerate && (
                          <button 
                            onClick={() => setIsEditingSummary(true)}
                            className="mt-1.5 sm:mt-2 text-[10px] sm:text-xs font-black text-blue-600 uppercase tracking-widest hover:underline"
                          >
                            Add Summary
                          </button>
                        )}
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}

            {match.status === 'COMPLETED' && (
              <div className="bg-white p-4 sm:p-6 rounded-2xl sm:rounded-[2.5rem] border border-slate-200 shadow-sm animate-in slide-in-from-top-4 duration-500">
                <div className="flex items-center gap-2.5 sm:gap-3 mb-4 sm:mb-6">
                  <div className="p-2 sm:p-3 bg-amber-100 text-amber-600 rounded-xl sm:rounded-2xl">
                    <Award className="w-5 h-5 sm:w-6 sm:h-6" />
                  </div>
                  <div>
                    <h3 className="text-base sm:text-lg font-black text-slate-900 tracking-tight">Player of the Match</h3>
                    <p className="text-[9px] sm:text-[10px] font-black text-slate-400 uppercase tracking-widest">{hasVoted ? 'Current Voting Results' : 'Club Member Voting'}</p>
                  </div>
                </div>

                {!isMember ? (
                  <div className="py-3 sm:py-4 text-center">
                    <p className="text-xs sm:text-sm font-medium text-slate-500 italic">Voting restricted to club members.</p>
                  </div>
                ) : hasVoted ? (
                  <div className="space-y-3 sm:space-y-4">
                    {confirmedSquad.map(player => {
                      const votes = potmResults[player.id] || 0;
                      const percentage = totalVotes > 0 ? (votes / totalVotes) * 100 : 0;
                      return (
                        <div key={player.id} className="space-y-1.5">
                          <div className="flex justify-between items-center px-1">
                            <span className="text-xs font-black text-slate-900 uppercase tracking-tight truncate flex-1 pr-2">{player.name}</span>
                            <span className="text-[9px] sm:text-[10px] font-black text-slate-500 tabular-nums">{votes} {votes === 1 ? 'vote' : 'votes'} ({Math.round(percentage)}%)</span>
                          </div>
                          <div className="h-1.5 sm:h-2 bg-slate-100 rounded-full overflow-hidden">
                            <div className="h-full bg-amber-400 rounded-full transition-all duration-1000" style={{ width: `${percentage}%` }}></div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 sm:gap-3">
                    {confirmedSquad.map(player => (
                      <button key={player.id} onClick={() => onVoteForPotm(player.id)} className="flex flex-col items-center gap-2 sm:gap-3 p-3 sm:p-4 bg-slate-50 hover:bg-amber-50 rounded-xl sm:rounded-2xl border border-slate-100 hover:border-amber-200 transition-all group">
                        <img src={player.avatar || `https://i.pravatar.cc/100?u=${player.id}`} className="w-10 h-10 sm:w-12 sm:h-12 rounded-lg sm:rounded-xl object-cover border-2 border-white shadow-sm group-hover:scale-110 transition-transform" alt="" />
                        <span className="text-[9px] sm:text-[10px] font-black text-slate-700 uppercase tracking-tight text-center leading-tight truncate w-full px-1">{player.name.split(' ')[0]}</span>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            )}

            {isMember && match.status !== 'COMPLETED' && (
              <div className="space-y-2.5 sm:space-y-3">
                {canModerate && progressionButton && (
                  <button onClick={handleMatchProgression} className={`w-full flex items-center justify-center gap-2 sm:gap-3 py-3.5 sm:py-5 rounded-2xl sm:rounded-[2rem] font-black text-[10px] sm:text-xs uppercase tracking-[0.15em] sm:tracking-[0.2em] transition-all group shadow-xl hover:-translate-y-1 active:translate-y-0 ${progressionButton.color}`}>
                    <div className="group-hover:scale-110 transition-transform">{progressionButton.icon}</div>
                    <span>{progressionButton.label}</span>
                  </button>
                )}
                {isMatchInPlay && (
                  <div className="grid grid-cols-4 gap-1.5 sm:gap-2 p-1.5 sm:p-2 bg-white rounded-2xl sm:rounded-[2rem] border border-slate-200 shadow-sm animate-in slide-in-from-top-2 duration-300">
                    <button onClick={() => handleActionClick('GOAL')} className={`flex flex-col items-center justify-center gap-1 sm:gap-1.5 p-2 sm:p-4 rounded-xl sm:rounded-2xl transition-all group ${activeActionType === 'GOAL' ? 'bg-green-100 text-green-700' : 'bg-green-50 text-green-700 hover:bg-green-100'}`}><Goal className="w-4 h-4 sm:w-5 sm:h-5 group-hover:scale-110 transition-transform" /><span className="font-black text-[7px] sm:text-[8px] uppercase tracking-widest">Goal</span></button>
                    <button onClick={() => handleActionClick('SUB')} className={`flex flex-col items-center justify-center gap-1 sm:gap-1.5 p-2 sm:p-4 rounded-xl sm:rounded-2xl transition-all group ${activeActionType === 'SUB' ? 'bg-orange-100 text-orange-700' : 'bg-orange-50 text-orange-700 hover:bg-orange-100'}`}><ArrowRightLeft className="w-4 h-4 sm:w-5 sm:h-5 group-hover:scale-110 transition-transform" /><span className="font-black text-[7px] sm:text-[8px] uppercase tracking-widest">Sub</span></button>
                    <button onClick={() => handleActionClick('YELLOW_CARD')} className={`flex flex-col items-center justify-center gap-1 sm:gap-1.5 p-2 sm:p-4 rounded-xl sm:rounded-2xl transition-all group ${activeActionType === 'YELLOW_CARD' ? 'bg-yellow-100 text-yellow-700' : 'bg-yellow-50 text-yellow-700 hover:bg-yellow-100'}`}><AlertTriangle className="w-4 h-4 sm:w-5 sm:h-5 group-hover:scale-110 transition-transform" /><span className="font-black text-[7px] sm:text-[8px] uppercase tracking-widest">Yellow</span></button>
                    <button onClick={() => handleActionClick('RED_CARD')} className={`flex flex-col items-center justify-center gap-1 sm:gap-1.5 p-2 sm:p-4 rounded-xl sm:rounded-2xl transition-all group ${activeActionType === 'RED_CARD' ? 'bg-red-100 text-red-700' : 'bg-red-50 text-red-700 hover:bg-red-100'}`}><AlertOctagon className="w-4 h-4 sm:w-5 sm:h-5 group-hover:scale-110 transition-transform" /><span className="font-black text-[7px] sm:text-[8px] uppercase tracking-widest">Red</span></button>
                  </div>
                )}
                {!isMatchInPlay && <div className="text-center py-3 sm:py-4 bg-slate-100/50 rounded-2xl sm:rounded-[2rem] border border-dashed border-slate-200"><p className="text-[9px] sm:text-[10px] font-black uppercase tracking-[0.15em] sm:tracking-[0.2em] text-slate-400">{match.status === 'UPCOMING' ? 'Waiting for Kick Off' : 'Match at Half-Time'}</p></div>}
              </div>
            )}

            <div className="space-y-3 sm:space-y-4">
              <h3 className="text-[9px] sm:text-[10px] font-black uppercase tracking-widest text-slate-400 flex items-center gap-2 px-2"><History className="w-3.5 h-3.5" /> Match Timeline</h3>
              {events.length === 0 ? (
                <div className="py-12 sm:py-20 text-center"><div className="bg-slate-100 w-12 h-12 sm:w-16 sm:h-16 rounded-2xl sm:rounded-3xl flex items-center justify-center mx-auto mb-3 sm:mb-4"><History className="w-5 h-5 sm:w-6 sm:h-6 text-slate-300" /></div><p className="text-xs sm:text-sm font-bold text-slate-300 italic">Waiting for events...</p></div>
              ) : (
                events.map(event => (
                  <div key={event.id} className="bg-white p-3.5 sm:p-5 rounded-2xl sm:rounded-[2rem] border border-slate-100 shadow-sm flex items-start gap-3 sm:gap-4 animate-in slide-in-from-top-2 duration-300 relative group">
                    <div className="p-2 sm:p-3 bg-slate-50 rounded-xl sm:rounded-2xl shrink-0">{liveIconMapping[event.type] || <Info className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-slate-400" />}</div>
                    <div className="flex-1 min-w-0">
                      <div className="flex justify-between items-center mb-1">
                        <p className="text-[9px] sm:text-[10px] font-black text-slate-900 uppercase tracking-widest">{event.userName}</p>
                        <div className="flex items-center gap-2">
                          <p className="text-[8px] sm:text-[9px] text-slate-400 font-bold">{new Date(event.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</p>
                          {(event.userId === currentUser?.id || canModerate) && editingEventId !== event.id && (
                            <div className="flex items-center gap-1 md:opacity-0 md:group-hover:opacity-100 transition-opacity">
                              {event.userId === currentUser?.id && <button onClick={() => handleStartEdit(event)} className="p-1 text-slate-300 hover:text-blue-500 transition-colors"><Edit2 className="w-3 h-3" /></button>}
                              <button onClick={() => onDeleteEvent(event.id)} className="p-1 text-slate-300 hover:text-red-500 transition-colors"><Trash2 className="w-3 h-3" /></button>
                            </div>
                          )}
                        </div>
                      </div>
                      {editingEventId === event.id ? (
                        <div className="flex gap-2 items-center mt-2">
                          <input autoFocus type="text" value={editContent} onChange={(e) => setEditContent(e.target.value)} className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-4 py-2 text-sm font-medium focus:outline-none focus:ring-2 focus:ring-blue-500/20" />
                          <button onClick={() => handleSaveEdit(event.id)} className="p-2 bg-blue-600 text-white rounded-xl shadow-sm"><Check className="w-4 h-4" /></button>
                          <button onClick={() => setEditingEventId(null)} className="p-2 bg-slate-100 text-slate-400 rounded-xl"><X className="w-4 h-4" /></button>
                        </div>
                      ) : (
                        <div className="space-y-3">
                          <p className="text-sm text-slate-600 font-medium leading-snug">{event.content}</p>
                          {event.mediaUrl && (
                            <div className="rounded-2xl overflow-hidden border border-slate-100 shadow-sm">
                              <img 
                                src={event.mediaUrl} 
                                alt="Match media" 
                                className="w-full h-auto max-h-[400px] object-cover"
                                referrerPolicy="no-referrer"
                              />
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        ) : activeView === 'STATS' ? (
          <div className="space-y-8 pb-48 md:pb-32 animate-in fade-in duration-500">
            {/* Retrospective Post-Match Recorder Card */}
            {canModerate && (
              <div className="bg-white p-6 sm:p-8 rounded-[2.5rem] border border-slate-200 shadow-sm space-y-6">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 bg-blue-50 text-blue-600 rounded-2xl">
                      <Trophy className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="text-base sm:text-lg font-black text-slate-900 tracking-tight">Retrospective Post-Match Recorder</h3>
                      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Update results & player stats after the game</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={handleSaveRetrospectiveData}
                      className="bg-blue-600 text-white px-5 py-2.5 rounded-xl font-black text-[10px] uppercase tracking-widest shadow-lg shadow-blue-100 hover:bg-blue-700 transition-all flex items-center gap-1.5"
                    >
                      <Check className="w-4 h-4" /> Save Record
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  {/* Status & Final Scores */}
                  <div className="bg-slate-50/50 p-5 rounded-2xl border border-slate-100 space-y-4">
                    <h4 className="text-[10px] font-black uppercase tracking-widest text-slate-500 flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5" /> Match Status & Score
                    </h4>
                    
                    <div className="space-y-3">
                      <div>
                        <label className="text-[9px] font-black uppercase text-slate-400 tracking-widest block mb-1">Status</label>
                        <div className="grid grid-cols-2 sm:grid-cols-4 gap-1 sm:gap-1.5 bg-slate-100 p-1 rounded-xl">
                          {(['UPCOMING', 'LIVE', 'COMPLETED', 'CANCELLED'] as const).map(st => (
                            <button
                              key={st}
                              type="button"
                              onClick={() => setRetrospectiveStatus(st)}
                              className={`py-1.5 rounded-lg text-[8px] sm:text-[9px] font-black uppercase tracking-widest transition-all ${
                                retrospectiveStatus === st 
                                  ? 'bg-white text-slate-900 shadow-sm' 
                                  : 'text-slate-400 hover:text-slate-600'
                              }`}
                            >
                              {st}
                            </button>
                          ))}
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4 pt-2">
                        <div>
                          <label className="text-[9px] font-black uppercase text-slate-400 tracking-widest block mb-1 truncate">{teamAName}</label>
                          <input
                            type="number"
                            min="0"
                            value={scoreADraft}
                            onChange={(e) => setScoreADraft(parseInt(e.target.value) || 0)}
                            className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-sm font-bold text-center focus:ring-2 focus:ring-blue-500 focus:outline-none"
                          />
                        </div>
                        <div>
                          <label className="text-[9px] font-black uppercase text-slate-400 tracking-widest block mb-1 truncate">{teamBName}</label>
                          <input
                            type="number"
                            min="0"
                            value={scoreBDraft}
                            onChange={(e) => setScoreBDraft(parseInt(e.target.value) || 0)}
                            className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-sm font-bold text-center focus:ring-2 focus:ring-blue-500 focus:outline-none"
                          />
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Retrospective Goal & Assist Logger */}
                  <div className="bg-slate-50/50 p-5 rounded-2xl border border-slate-100 space-y-4">
                    <h4 className="text-[10px] font-black uppercase tracking-widest text-slate-500 flex items-center gap-1.5">
                      <Trophy className="w-3.5 h-3.5 text-blue-500" /> Log Goal & Assist
                    </h4>
                    
                    <form onSubmit={handleAddRetroGoal} className="space-y-3">
                      <div>
                        <label className="text-[8px] font-black uppercase text-slate-400 tracking-widest block mb-1">Scoring Team</label>
                        <div className="grid grid-cols-2 gap-1 bg-slate-100 p-1 rounded-xl">
                          <button
                            type="button"
                            onClick={() => setRetroGoalTeam('A')}
                            className={`py-1 rounded-lg text-[8px] sm:text-[9px] font-black uppercase tracking-widest transition-all ${
                              retroGoalTeam === 'A' 
                                ? 'bg-white text-blue-600 shadow-sm' 
                                : 'text-slate-500 hover:text-slate-700'
                            }`}
                          >
                            {teamAName}
                          </button>
                          <button
                            type="button"
                            onClick={() => setRetroGoalTeam('B')}
                            className={`py-1 rounded-lg text-[8px] sm:text-[9px] font-black uppercase tracking-widest transition-all ${
                              retroGoalTeam === 'B' 
                                ? 'bg-white text-blue-600 shadow-sm' 
                                : 'text-slate-500 hover:text-slate-700'
                            }`}
                          >
                            {teamBName}
                          </button>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="text-[8px] font-black uppercase text-slate-400 tracking-widest block mb-1">Scorer</label>
                          <select
                            value={retroGoalScorer}
                            onChange={(e) => setRetroGoalScorer(e.target.value)}
                            className="w-full bg-white border border-slate-200 rounded-lg px-2 py-1.5 text-xs font-bold focus:outline-none focus:border-blue-500"
                          >
                            <option value="">Select Scorer...</option>
                            <option value="opponent">Opponent / Other</option>
                            {squadPlayersRetrospective.map(p => (
                              <option key={p.id} value={p.id}>{p.name}</option>
                            ))}
                          </select>
                        </div>

                        <div>
                          <label className="text-[8px] font-black uppercase text-slate-400 tracking-widest block mb-1">Assist</label>
                          <select
                            value={retroGoalAssist}
                            disabled={retroGoalScorer === 'opponent'}
                            onChange={(e) => setRetroGoalAssist(e.target.value)}
                            className="w-full bg-white border border-slate-200 rounded-lg px-2 py-1.5 text-xs font-bold focus:outline-none focus:border-blue-500 disabled:opacity-50 disabled:bg-slate-100"
                          >
                            <option value="">No Assist</option>
                            {squadPlayersRetrospective.map(p => (
                              <option key={p.id} value={p.id}>{p.name}</option>
                            ))}
                          </select>
                        </div>
                      </div>

                      <div className="grid grid-cols-3 gap-2">
                        <div className="col-span-1">
                          <label className="text-[8px] font-black uppercase text-slate-400 tracking-widest block mb-1">Minute</label>
                          <input
                            type="number"
                            min="1"
                            max="120"
                            placeholder="Min"
                            value={retroGoalMinute}
                            onChange={(e) => setRetroGoalMinute(e.target.value)}
                            className="w-full bg-white border border-slate-200 rounded-lg px-2 py-1 text-xs font-bold text-center focus:outline-none focus:border-blue-500"
                          />
                        </div>
                        <div className="col-span-2">
                          <label className="text-[8px] font-black uppercase text-slate-400 tracking-widest block mb-1">Goal Detail</label>
                          <input
                            type="text"
                            placeholder="e.g. Header, penalty"
                            value={retroGoalComment}
                            onChange={(e) => setRetroGoalComment(e.target.value)}
                            className="w-full bg-white border border-slate-200 rounded-lg px-2 py-1 text-xs font-medium focus:outline-none focus:border-blue-500"
                          />
                        </div>
                      </div>

                      <button
                        type="submit"
                        className="w-full bg-blue-600 hover:bg-blue-700 text-white py-2 rounded-lg font-black text-[9px] uppercase tracking-widest shadow-sm transition-all cursor-pointer"
                      >
                        Add Goal to Record
                      </button>
                    </form>
                  </div>

                  {/* Fast Match Finalizer Explanation */}
                  <div className="bg-slate-50/50 p-5 rounded-2xl border border-slate-100 flex flex-col justify-between">
                    <div className="space-y-2">
                      <h4 className="text-[10px] font-black uppercase tracking-widest text-slate-500">Fast Match Finalizer</h4>
                      <p className="text-xs text-slate-500 font-medium leading-relaxed">
                        To quickly record an unrecorded match, enter the scores above, toggle the "Played" status for players below, and enter their stats. Click "Save Record" to complete.
                      </p>
                    </div>
                    {club?.type === 'SOCIAL' && (
                      <button
                        onClick={handleSuggestTeams}
                        className="mt-4 bg-white hover:bg-slate-50 text-slate-700 px-4 py-2.5 rounded-xl border border-slate-200 font-black text-[9px] uppercase tracking-widest shadow-sm transition-all text-center"
                      >
                        Suggest Balanced Draft Teams
                      </button>
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* Squad Match Stats Entry Card */}
            <div className="bg-white p-6 sm:p-8 rounded-[2.5rem] border border-slate-200 shadow-sm space-y-6">
              <div>
                <h3 className="text-base sm:text-lg font-black text-slate-900 tracking-tight">Squad Match Stats</h3>
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mt-0.5">Toggle "Played" to set default minutes and record goals, assists, and cards.</p>
              </div>

              <div className="space-y-4">
                {squadPlayersRetrospective.map(player => {
                  const played = retrospectiveAvailability[player.id] === 'CONFIRMED';
                  return (
                    <div 
                      key={player.id} 
                      className={`p-4 rounded-2xl border transition-all ${
                        played 
                          ? 'bg-blue-50/30 border-blue-100 shadow-sm' 
                          : 'bg-white border-slate-100 hover:border-slate-200'
                      }`}
                    >
                      {/* Player Header with Checkbox */}
                      <div className="flex flex-wrap items-center justify-between gap-3 pb-3">
                        <div className="flex items-center gap-3 min-w-0">
                          <input
                            type="checkbox"
                            id={`played-${player.id}`}
                            checked={played}
                            onChange={(e) => handleTogglePlayed(player.id, e.target.checked)}
                            className="w-4 h-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500 cursor-pointer"
                          />
                          <label htmlFor={`played-${player.id}`} className="flex items-center gap-2.5 cursor-pointer min-w-0">
                            <img src={player.avatar || `https://i.pravatar.cc/100?u=${player.id}`} className="w-8 h-8 rounded-lg object-cover" alt="" />
                            <span className="text-sm font-black text-slate-900 truncate">{player.name}</span>
                          </label>
                        </div>

                        {/* Team assignment for SOCIAL match */}
                        {club?.type === 'SOCIAL' && (
                          <div className="flex items-center gap-1.5">
                            <button
                              type="button"
                              onClick={() => toggleTeamAssignment(player.id, 'A')}
                              className={`px-2 py-1 rounded text-[8px] font-black uppercase tracking-widest border transition-all ${
                                teamADraft.includes(player.id)
                                  ? 'bg-blue-600 border-blue-700 text-white'
                                  : 'bg-white border-slate-100 text-slate-400 hover:text-slate-600'
                              }`}
                            >
                              {teamAName}
                            </button>
                            <button
                              type="button"
                              onClick={() => toggleTeamAssignment(player.id, 'B')}
                              className={`px-2 py-1 rounded text-[8px] font-black uppercase tracking-widest border transition-all ${
                                teamBDraft.includes(player.id)
                                  ? 'bg-slate-900 border-black text-white'
                                  : 'bg-white border-slate-100 text-slate-400 hover:text-slate-600'
                              }`}
                            >
                              {teamBName}
                            </button>
                            <button
                              type="button"
                              onClick={() => toggleTeamAssignment(player.id, null)}
                              className={`px-2 py-1 rounded text-[8px] font-black uppercase tracking-widest border transition-all ${
                                !teamADraft.includes(player.id) && !teamBDraft.includes(player.id)
                                  ? 'bg-slate-200 border-slate-300 text-slate-700'
                                  : 'bg-white border-slate-100 text-slate-400 hover:text-slate-600'
                              }`}
                            >
                              Unassigned
                            </button>
                          </div>
                        )}
                      </div>

                      {/* Stats Inputs (Expand if Played) */}
                      {played && (
                        <div className="grid grid-cols-2 xs:grid-cols-3 sm:grid-cols-5 md:grid-cols-5 gap-3 pt-3 border-t border-slate-100/50 animate-in slide-in-from-top-2 duration-200">
                          <div>
                            <label className="text-[8px] font-black uppercase text-slate-400 tracking-widest block mb-1">Goals</label>
                            <input 
                              type="number" 
                              min="0"
                              value={editingStats[player.id]?.goals || 0}
                              onChange={(e) => updatePlayerStat(player.id, 'goals', parseInt(e.target.value) || 0)}
                              className="w-full bg-white border border-slate-200 rounded-lg px-2.5 py-1 text-xs font-bold text-center"
                            />
                          </div>
                          <div>
                            <label className="text-[8px] font-black uppercase text-slate-400 tracking-widest block mb-1">Assists</label>
                            <input 
                              type="number" 
                              min="0"
                              value={editingStats[player.id]?.assists || 0}
                              onChange={(e) => updatePlayerStat(player.id, 'assists', parseInt(e.target.value) || 0)}
                              className="w-full bg-white border border-slate-200 rounded-lg px-2.5 py-1 text-xs font-bold text-center"
                            />
                          </div>
                          <div>
                            <label className="text-[8px] font-black uppercase text-slate-400 tracking-widest block mb-1">Yellow Cards</label>
                            <input 
                              type="number" 
                              min="0"
                              max="2"
                              value={editingStats[player.id]?.yellowCards || 0}
                              onChange={(e) => updatePlayerStat(player.id, 'yellowCards', parseInt(e.target.value) || 0)}
                              className="w-full bg-white border border-slate-200 rounded-lg px-2.5 py-1 text-xs font-bold text-center"
                            />
                          </div>
                          <div>
                            <label className="text-[8px] font-black uppercase text-slate-400 tracking-widest block mb-1">Red Cards</label>
                            <input 
                              type="number" 
                              min="0"
                              max="1"
                              value={editingStats[player.id]?.redCards || 0}
                              onChange={(e) => updatePlayerStat(player.id, 'redCards', parseInt(e.target.value) || 0)}
                              className="w-full bg-white border border-slate-200 rounded-lg px-2.5 py-1 text-xs font-bold text-center"
                            />
                          </div>
                          <div>
                            <label className="text-[8px] font-black uppercase text-slate-400 tracking-widest block mb-1">Minutes</label>
                            <input 
                              type="number" 
                              min="0"
                              value={editingStats[player.id]?.minutesPlayed || 0}
                              onChange={(e) => updatePlayerStat(player.id, 'minutesPlayed', parseInt(e.target.value) || 0)}
                              className="w-full bg-white border border-slate-200 rounded-lg px-2.5 py-1 text-xs font-bold text-center"
                            />
                          </div>

                          {/* Social specific stats */}
                          {club?.type === 'SOCIAL' && (
                            <>
                              <div>
                                <label className="text-[8px] font-black uppercase text-slate-400 tracking-widest block mb-1">Balls Over</label>
                                <input 
                                  type="number" 
                                  min="0"
                                  value={editingStats[player.id]?.ballsOverFence || 0}
                                  onChange={(e) => updatePlayerStat(player.id, 'ballsOverFence', parseInt(e.target.value) || 0)}
                                  className="w-full bg-white border border-slate-200 rounded-lg px-2.5 py-1 text-xs font-bold text-center"
                                />
                              </div>
                              <div className="flex items-center gap-1.5 pt-3">
                                <input 
                                  type="checkbox" 
                                  id={`injured-${player.id}`}
                                  checked={editingStats[player.id]?.isInjured || false}
                                  onChange={(e) => updatePlayerStat(player.id, 'isInjured', e.target.checked)}
                                  className="w-4 h-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500 cursor-pointer"
                                />
                                <label htmlFor={`injured-${player.id}`} className="text-[8px] font-black uppercase text-slate-400 tracking-widest cursor-pointer select-none">Injured</label>
                              </div>
                              <div className="flex items-center gap-1.5 pt-3">
                                <input 
                                  type="checkbox" 
                                  id={`dropout-${player.id}`}
                                  checked={editingStats[player.id]?.isLastMinuteDropout || false}
                                  onChange={(e) => updatePlayerStat(player.id, 'isLastMinuteDropout', e.target.checked)}
                                  className="w-4 h-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500 cursor-pointer"
                                />
                                <label htmlFor={`dropout-${player.id}`} className="text-[8px] font-black uppercase text-slate-400 tracking-widest cursor-pointer select-none">Dropout</label>
                              </div>
                            </>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Manager's Summary & Media Upload Section */}
            {match.status === 'COMPLETED' && (
              <div className="bg-white p-8 rounded-[2.5rem] border border-slate-200 shadow-sm space-y-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="p-3 bg-blue-100 text-blue-600 rounded-2xl">
                      <BookOpen className="w-6 h-6" />
                    </div>
                    <div>
                      <h3 className="text-lg font-black text-slate-900 tracking-tight">Manager's Summary</h3>
                      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Post-match analysis</p>
                    </div>
                  </div>
                  {canModerate && !isEditingSummary && (
                    <button 
                      onClick={() => setIsEditingSummary(true)}
                      className="p-2 hover:bg-slate-50 rounded-xl transition-all text-blue-600"
                    >
                      <Edit2 className="w-5 h-5" />
                    </button>
                  )}
                </div>

                {isEditingSummary ? (
                  <div className="space-y-4">
                    <textarea
                      value={summaryDraft}
                      onChange={(e) => setSummaryDraft(e.target.value)}
                      placeholder="Write your match summary here..."
                      className="w-full bg-slate-50 border border-slate-200 rounded-2xl p-4 text-sm font-medium focus:outline-none focus:ring-4 focus:ring-blue-500/10 min-h-[150px]"
                    />
                    <div className="flex gap-2">
                      <button 
                        onClick={handleSaveSummary}
                        className="flex-1 bg-blue-600 text-white py-3 rounded-xl font-black text-[10px] uppercase tracking-widest shadow-lg shadow-blue-100"
                      >
                        Save Summary
                      </button>
                      <button 
                        onClick={() => setIsEditingSummary(false)}
                        className="px-6 bg-slate-100 text-slate-500 py-3 rounded-xl font-black text-[10px] uppercase tracking-widest"
                      >
                        Cancel
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="relative">
                    {match.managerSummary ? (
                      <p className="text-sm text-slate-600 font-medium leading-relaxed italic">
                        "{match.managerSummary}"
                      </p>
                    ) : (
                      <div className="py-6 text-center border-2 border-dashed border-slate-100 rounded-2xl">
                        <p className="text-sm text-slate-400 font-medium italic">No manager summary added yet.</p>
                        {canModerate && (
                          <button 
                            onClick={() => setIsEditingSummary(true)}
                            className="mt-2 text-xs font-black text-blue-600 uppercase tracking-widest hover:underline"
                          >
                            Add Summary
                          </button>
                        )}
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}

            {/* Post Highlight Section */}
            {isMember && (
              <div className="bg-white p-6 rounded-[2.5rem] border border-slate-200 shadow-sm space-y-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="p-2 bg-blue-600 text-white rounded-xl">
                    <MessageSquare className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="font-black text-slate-900 text-sm">Post Highlight</h3>
                    <p className="text-[10px] font-black uppercase text-slate-400 tracking-widest">Share a photo or comment</p>
                  </div>
                </div>
                
                <form onSubmit={handleSubmitAction} className="space-y-3">
                  {selectedImage && (
                    <div className="relative w-full aspect-video rounded-2xl overflow-hidden border border-slate-200">
                      <img src={selectedImage} alt="Preview" className="w-full h-full object-cover" />
                      <button 
                        type="button"
                        onClick={() => setSelectedImage(null)}
                        className="absolute top-2 right-2 p-1.5 bg-black/50 text-white rounded-full hover:bg-black/70 transition-colors"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  )}
                  
                  <div className="flex gap-2 sm:gap-3">
                    <input 
                      type="text" 
                      value={newEventContent} 
                      onChange={(e) => setNewEventContent(e.target.value)} 
                      placeholder="Add a caption or highlight..." 
                      className="flex-1 min-w-0 bg-slate-50 border border-slate-200 rounded-xl px-3 sm:px-4 py-2.5 sm:py-3 text-xs sm:text-sm font-medium focus:outline-none focus:border-blue-500 transition-all" 
                    />
                    <input 
                      type="file" 
                      id="social-photo-upload" 
                      accept="image/*" 
                      className="hidden" 
                      onChange={handleImageUpload}
                    />
                    <label 
                      htmlFor="social-photo-upload"
                      className="p-2.5 sm:p-3 bg-slate-100 text-slate-600 rounded-xl hover:bg-slate-200 transition-all cursor-pointer flex items-center justify-center shrink-0"
                    >
                      <Camera className="w-4 h-4 sm:w-5 sm:h-5" />
                    </label>
                    <button type="submit" className="p-2.5 sm:p-3 bg-blue-600 text-white rounded-xl shadow-lg shadow-blue-100 hover:bg-blue-700 transition-all flex items-center justify-center shrink-0">
                      <Send className="w-4 h-4 sm:w-5 sm:h-5" />
                    </button>
                  </div>
                </form>
              </div>
            )}

            <div className="bg-white p-4 sm:p-8 rounded-2xl sm:rounded-[2.5rem] border border-slate-200 shadow-sm space-y-4 sm:space-y-6">
              <div className="flex items-center gap-2.5 sm:gap-3">
                <div className="p-2 sm:p-3 bg-blue-100 text-blue-600 rounded-xl sm:rounded-2xl">
                  <ImageIcon className="w-5 h-5 sm:w-6 sm:h-6" />
                </div>
                <div>
                  <h3 className="text-base sm:text-lg font-black text-slate-900 tracking-tight">Photos & Highlights</h3>
                  <p className="text-[9px] sm:text-[10px] font-black text-slate-400 uppercase tracking-widest">Match moments</p>
                </div>
              </div>
              
              <div className="space-y-4 sm:space-y-6">
                {events.length === 0 ? (
                  <div className="py-8 sm:py-12 text-center border-2 border-dashed border-slate-100 rounded-2xl sm:rounded-[2.5rem]">
                    <MessageSquare className="w-8 h-8 sm:w-10 sm:h-10 text-slate-200 mx-auto mb-2.5 sm:mb-3" />
                    <p className="text-xs sm:text-sm text-slate-400 font-medium italic">No photos or highlights yet.</p>
                  </div>
                ) : (
                  events.map((event, idx) => (
                    <div key={event.id} className="relative pl-4 sm:pl-6 border-l-2 border-slate-100 pb-4 sm:pb-6 last:pb-0">
                      <div className="absolute -left-[9px] top-0 w-4 h-4 rounded-full bg-white border-2 border-slate-200"></div>
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <span className="text-[9px] sm:text-[10px] font-black text-slate-400 uppercase tracking-widest">{event.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                        </div>
                        {canModerate && (
                          <div className="flex gap-1">
                            {event.userId === currentUser?.id && <button onClick={() => handleStartEdit(event)} className="p-1 text-slate-300 hover:text-blue-500 transition-colors"><Edit2 className="w-3 h-3" /></button>}
                            <button onClick={() => onDeleteEvent(event.id)} className="p-1 text-slate-300 hover:text-red-500 transition-colors"><Trash2 className="w-3 h-3" /></button>
                          </div>
                        )}
                      </div>
                      {editingEventId === event.id ? (
                        <div className="flex gap-2 items-center mt-2">
                          <input autoFocus type="text" value={editContent} onChange={(e) => setEditContent(e.target.value)} className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 sm:px-4 sm:py-2 text-xs sm:text-sm font-medium focus:outline-none focus:ring-2 focus:ring-blue-500/20" />
                          <button onClick={() => handleSaveEdit(event.id)} className="p-2 bg-blue-600 text-white rounded-xl shadow-sm"><Check className="w-4 h-4" /></button>
                          <button onClick={() => setEditingEventId(null)} className="p-2 bg-slate-100 text-slate-400 rounded-xl"><X className="w-4 h-4" /></button>
                        </div>
                      ) : (
                        <div className="space-y-2 sm:space-y-3">
                          <p className="text-xs sm:text-sm text-slate-600 font-medium leading-snug">{event.content}</p>
                          {event.mediaUrl && (
                            <div className="rounded-xl sm:rounded-2xl overflow-hidden border border-slate-100 shadow-sm">
                              <img 
                                src={event.mediaUrl} 
                                alt="Match media" 
                                className="w-full h-auto max-h-[250px] sm:max-h-[400px] object-cover"
                                referrerPolicy="no-referrer"
                              />
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        ) : (activeView === 'TACTICS' && canModerate) ? (
          <div className="space-y-6 animate-in fade-in duration-500 pb-10">
            <div className="bg-white p-6 rounded-[2.5rem] border border-slate-200 shadow-sm space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-blue-600 text-white rounded-xl shadow-lg">
                    <Users className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-black text-slate-900 text-sm">Tactical Team Selector</h3>
                    <p className="text-[10px] font-black uppercase text-slate-400 tracking-widest">Select formation and place players</p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <select
                    value={selectedFormation}
                    onChange={(e) => {
                      setSelectedFormation(e.target.value);
                      setTacticalLineup({});
                    }}
                    className="bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-700 focus:outline-none focus:border-blue-500"
                  >
                    {Object.keys(FORMATIONS).map(form => (
                      <option key={form} value={form}>{form}</option>
                    ))}
                  </select>

                  {canModerate && (
                    <div className="flex items-center gap-2">
                      <button
                        onClick={handleAutoFill}
                        title="Auto-fill open slots based on players' favorite positions"
                        className="p-2 bg-amber-50 text-amber-600 rounded-xl border border-amber-200 hover:bg-amber-100 transition-all flex items-center gap-1.5 text-xs font-bold"
                      >
                        <Sparkles className="w-4 h-4" />
                        <span className="hidden md:inline uppercase tracking-wider text-[9px] font-black">Auto-Fill</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => setShowBalanceHelper(prev => !prev)}
                        className={`p-2 rounded-xl border transition-all flex items-center gap-1.5 text-xs font-bold ${
                          showBalanceHelper 
                            ? 'bg-blue-50 text-blue-600 border-blue-200 hover:bg-blue-100' 
                            : 'bg-slate-50 text-slate-500 border-slate-200 hover:bg-slate-100'
                        }`}
                        title="Toggle Tactical Balance Advisor"
                      >
                        <Sparkles className="w-4 h-4" />
                        <span className="hidden md:inline uppercase tracking-wider text-[9px] font-black">Advisor {showBalanceHelper ? 'On' : 'Off'}</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => setShowSubPlanner(prev => !prev)}
                        className={`p-2 rounded-xl border transition-all flex items-center gap-1.5 text-xs font-bold ${
                          showSubPlanner 
                            ? 'bg-amber-50 text-amber-600 border-amber-200 hover:bg-amber-100' 
                            : 'bg-slate-50 text-slate-500 border-slate-200 hover:bg-slate-100'
                        }`}
                        title="Toggle Smart Substitution Planner"
                      >
                        <Clock className="w-4 h-4" />
                        <span className="hidden md:inline uppercase tracking-wider text-[9px] font-black">Planner {showSubPlanner ? 'On' : 'Off'}</span>
                      </button>
                    </div>
                  )}
                </div>
              </div>

              {/* Pitch Visualizer */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2 flex flex-col items-center gap-4">
                  <div className="w-full flex justify-center">
                    <div 
                      className="relative w-full aspect-[4/5] max-w-[440px] bg-gradient-to-b from-emerald-700 via-emerald-800 to-green-950 rounded-[2.5rem] border-2 border-emerald-600 shadow-2xl overflow-hidden"
                      style={{
                        backgroundImage: `repeating-linear-gradient(0deg, rgba(255,255,255,0.015), rgba(255,255,255,0.015) 30px, transparent 30px, transparent 60px)`
                      }}
                    >
                      {/* Pitch markings */}
                      <div className="absolute inset-4 border border-white/10 pointer-events-none rounded-lg"></div>
                      <div className="absolute left-4 right-4 top-1/2 h-px bg-white/15 pointer-events-none"></div>
                      <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-24 h-24 rounded-full border border-white/15 pointer-events-none"></div>
                      <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-2 h-2 bg-white/20 rounded-full pointer-events-none"></div>

                      {/* Top Penalty Box */}
                      <div className="absolute top-4 left-1/2 -translate-x-1/2 w-1/2 h-[18%] border-b border-x border-white/10 pointer-events-none"></div>
                      <div className="absolute top-4 left-1/2 -translate-x-1/2 w-1/4 h-[6%] border-b border-x border-white/15 pointer-events-none"></div>
                      <div className="absolute top-[18%] left-1/2 -translate-x-1/2 w-12 h-6 rounded-b-full border-b border-x border-white/10 border-t-transparent pointer-events-none"></div>

                      {/* Bottom Penalty Box */}
                      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 w-1/2 h-[18%] border-t border-x border-white/10 pointer-events-none"></div>
                      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 w-1/4 h-[6%] border-t border-x border-white/15 pointer-events-none"></div>
                      <div className="absolute bottom-[18%] left-1/2 -translate-x-1/2 w-12 h-6 rounded-t-full border-t border-x border-white/10 border-b-transparent pointer-events-none"></div>

                      {/* Players render */}
                      {(FORMATIONS[selectedFormation] || FORMATIONS['4-4-2']).map((pos) => {
                        const playerId = tacticalLineup[pos.id];
                        const player = confirmedSquad.find(p => p.id === playerId);
                        const isDraggedOver = draggedOverPosId === pos.id;

                        return (
                          <div
                            key={pos.id}
                            className={`absolute -translate-x-1/2 -translate-y-1/2 flex flex-col items-center z-10 group transition-all duration-200 ${
                              isDraggedOver ? 'scale-115 z-20' : ''
                            }`}
                            style={{ left: `${pos.x}%`, top: `${pos.y}%` }}
                            onDragOver={(e) => {
                              if (canModerate) {
                                e.preventDefault();
                                if (draggedOverPosId !== pos.id) {
                                  setDraggedOverPosId(pos.id);
                                }
                              }
                            }}
                            onDragEnter={(e) => {
                              if (canModerate) {
                                e.preventDefault();
                                if (draggedOverPosId !== pos.id) {
                                  setDraggedOverPosId(pos.id);
                                }
                              }
                            }}
                            onDragLeave={() => {
                              if (canModerate) {
                                setDraggedOverPosId(null);
                              }
                            }}
                            onDrop={(e) => {
                              if (canModerate) {
                                e.preventDefault();
                                setDraggedOverPosId(null);
                                const pId = e.dataTransfer.getData('text/plain');
                                if (pId) {
                                  setTacticalLineup(prev => {
                                    const next = { ...prev };
                                    // Clear player if already in another position
                                    Object.keys(next).forEach(k => {
                                      if (next[k] === pId) delete next[k];
                                    });
                                    next[pos.id] = pId;
                                    return next;
                                  });
                                }
                              }
                            }}
                          >
                            {player ? (
                              <div 
                                className="relative flex flex-col items-center"
                                draggable={canModerate}
                                onDragStart={(e) => {
                                  if (canModerate) {
                                    e.dataTransfer.setData('text/plain', player.id);
                                  }
                                }}
                              >
                                <button
                                  type="button"
                                  disabled={!canModerate}
                                  onClick={() => canModerate && setIsAssigningPos(pos.id)}
                                  className={`w-9 h-9 xs:w-11 xs:h-11 sm:w-12 sm:h-12 rounded-full border shadow-md xs:shadow-lg overflow-hidden bg-white hover:scale-105 active:scale-95 transition-all duration-300 cursor-pointer ${
                                    isDraggedOver ? 'border-amber-400 ring-2 sm:ring-4 ring-amber-400/30' : 
                                    starPlayerIds.includes(player.id) ? 'border-amber-400 ring-2 sm:ring-4 ring-amber-400/70 scale-105 shadow-[0_0_15px_rgba(245,158,11,0.5)]' :
                                    weakerPlayerIds.includes(player.id) ? 'border-indigo-400 ring-2 sm:ring-4 ring-indigo-400/50 shadow-[0_0_10px_rgba(99,102,241,0.3)]' :
                                    'border-white'
                                  }`}
                                >
                                  <img src={player.avatar || `https://i.pravatar.cc/100?u=${player.id}`} className="w-full h-full object-cover" alt={player.name} />
                                </button>
                                
                                {/* Star/Weaker Indicator Overlay */}
                                {starPlayerIds.includes(player.id) && (
                                  <div className="absolute -bottom-1 -left-1 bg-amber-400 text-white p-0.5 rounded-full shadow-sm text-[8px] leading-none z-20 border border-white" title="Star Player">
                                    ⭐
                                  </div>
                                )}
                                {weakerPlayerIds.includes(player.id) && (
                                  <div className="absolute -bottom-1 -left-1 bg-indigo-500 text-white p-0.5 rounded-full shadow-sm text-[8px] leading-none z-20 border border-white" title="Developing Player">
                                    📉
                                  </div>
                                )}

                                {/* Small Position Tag */}
                                <div className="absolute -top-1 -right-1 xs:-top-1.5 xs:-right-1.5 bg-blue-600 border border-white text-white text-[6px] xs:text-[7px] font-black px-1 py-0.5 rounded-full shadow-sm">
                                  {pos.label}
                                </div>
 
                                <div className="px-1.5 py-0.5 bg-slate-950/85 backdrop-blur-sm text-[7px] xs:text-[8px] font-bold text-white rounded border border-white/10 shadow-sm whitespace-nowrap truncate max-w-[55px] xs:max-w-[70px] mt-1 xs:mt-1.5 flex flex-col items-center gap-0.5">
                                  <span>{player.name.split(' ')[0]}</span>
                                  {canModerate && player.abilityRating && (
                                    <span className="text-[6px] xs:text-[7px] text-amber-300 font-black">
                                      {'★'.repeat(player.abilityRating)}
                                    </span>
                                  )}
                                </div>

                                {canModerate && (
                                  <button
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      setTacticalLineup(prev => {
                                        const next = { ...prev };
                                        delete next[pos.id];
                                        return next;
                                      });
                                    }}
                                    className="absolute -top-1 -left-1 bg-red-500 hover:bg-red-600 text-white rounded-full p-0.5 shadow-md scale-0 group-hover:scale-100 transition-all duration-200"
                                    title="Unassign Player"
                                  >
                                    <X className="w-3 h-3" />
                                  </button>
                                )}
                              </div>
                            ) : (
                              <button
                                type="button"
                                disabled={!canModerate}
                                onClick={() => canModerate && setIsAssigningPos(pos.id)}
                                className={`w-9 h-9 xs:w-11 xs:h-11 sm:w-12 sm:h-12 rounded-full border xs:border-2 transition-all flex flex-col items-center justify-center text-white cursor-pointer shadow-md xs:shadow-lg hover:scale-110 active:scale-95 ${
                                  isDraggedOver 
                                    ? 'border-amber-400 bg-emerald-800 ring-2 sm:ring-4 ring-amber-400/30' 
                                    : 'border-white/90 bg-emerald-950/80 hover:bg-emerald-900 hover:border-white'
                                }`}
                              >
                                <span className="text-[7px] xs:text-[9px] font-black tracking-tight text-white leading-none">{pos.label}</span>
                                <Plus className="w-2.5 h-2.5 xs:w-3.5 xs:h-3.5 mt-0.5 text-white" />
                              </button>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {/* Tactical Balance Advisor Panel */}
                  {canModerate && showBalanceHelper && (
                    <div className="w-full bg-slate-50/80 p-5 rounded-[2rem] border border-slate-100 shadow-sm space-y-3.5 max-w-[440px] animate-in slide-in-from-bottom duration-300">
                      <div className="flex justify-between items-center">
                        <div className="flex items-center gap-2">
                          <Sparkles className="w-4 h-4 text-amber-500 animate-pulse" />
                          <h4 className="font-black text-slate-800 text-xs uppercase tracking-wider">Tactical Balance Advisor</h4>
                        </div>
                        <span className="text-[8px] bg-slate-200 text-slate-600 px-2 py-0.5 rounded-full font-black uppercase">Admin Only</span>
                      </div>

                      <div className="space-y-2">
                        {balanceFeedback.length === 0 ? (
                          <p className="text-[10px] text-slate-400 font-bold italic leading-relaxed">Assign rated players to the pitch to view real-time positional cover and balancing suggestions.</p>
                        ) : (
                          <div className="flex flex-col gap-2">
                            {balanceFeedback.map((feedback, idx) => (
                              <div
                                key={idx}
                                className={`p-3 rounded-2xl border text-[10px] leading-relaxed font-bold flex items-start gap-2.5 transition-all hover:scale-[1.01] ${
                                  feedback.type === 'success'
                                    ? 'bg-emerald-50/80 border-emerald-100 text-emerald-800 shadow-sm shadow-emerald-100/30'
                                    : feedback.type === 'warning'
                                    ? 'bg-amber-50/80 border-amber-100 text-amber-800 shadow-sm shadow-amber-100/30'
                                    : 'bg-blue-50/80 border-blue-100 text-blue-800 shadow-sm shadow-blue-100/30'
                                }`}
                              >
                                {feedback.type === 'success' && <div className="text-sm shrink-0">✅</div>}
                                {feedback.type === 'warning' && <div className="text-sm shrink-0">⚠️</div>}
                                {feedback.type === 'info' && <div className="text-sm shrink-0">ℹ️</div>}
                                <div>{feedback.message}</div>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  )}

                  {/* Smart Substitution Planner & Time Balancer Panel */}
                  {canModerate && showSubPlanner && (
                    <div className="w-full bg-slate-50 p-5 rounded-[2rem] border border-amber-100 shadow-sm space-y-4 max-w-[440px] animate-in slide-in-from-bottom duration-300">
                      <div className="flex justify-between items-center pb-2 border-b border-amber-100/50">
                        <div className="flex items-center gap-2">
                          <Clock className="w-4 h-4 text-amber-500 animate-pulse" />
                          <h4 className="font-black text-slate-800 text-xs uppercase tracking-wider">Smart Rotation Planner</h4>
                        </div>
                        <span className="text-[7px] bg-amber-100 text-amber-800 px-2 py-0.5 rounded-full font-black uppercase tracking-wider">Equal Playtime Advisor</span>
                      </div>

                      {/* Simulation Controls */}
                      <div className="grid grid-cols-3 gap-2 bg-white p-3 rounded-2xl border border-slate-100 shadow-sm">
                        <div className="space-y-1">
                          <label className="text-[8px] font-black uppercase tracking-wider text-slate-400">Match Duration</label>
                          <div className="flex items-center gap-1">
                            <input
                              type="number"
                              min="10"
                              max="120"
                              value={matchDuration}
                              onChange={(e) => setMatchDuration(Number(e.target.value))}
                              className="w-full bg-slate-50 border border-slate-200 rounded-lg p-1 text-xs font-bold text-center text-slate-700 focus:outline-none focus:border-amber-500"
                            />
                            <span className="text-[8px] font-bold text-slate-400">m</span>
                          </div>
                        </div>
                        
                        <div className="space-y-1">
                          <label className="text-[8px] font-black uppercase tracking-wider text-slate-400">Sub Interval</label>
                          <div className="flex items-center gap-1">
                            <input
                              type="number"
                              min="5"
                              max="45"
                              value={subInterval}
                              onChange={(e) => setSubInterval(Number(e.target.value))}
                              className="w-full bg-slate-50 border border-slate-200 rounded-lg p-1 text-xs font-bold text-center text-slate-700 focus:outline-none focus:border-amber-500"
                            />
                            <span className="text-[8px] font-bold text-slate-400">m</span>
                          </div>
                        </div>

                        <div className="space-y-1">
                          <label className="text-[8px] font-black uppercase tracking-wider text-slate-400">Max Subs Window</label>
                          <input
                            type="number"
                            min="1"
                            max="5"
                            value={maxSubsPerWindow}
                            onChange={(e) => setMaxSubsPerWindow(Number(e.target.value))}
                            className="w-full bg-slate-50 border border-slate-200 rounded-lg p-1 text-xs font-bold text-center text-slate-700 focus:outline-none focus:border-amber-500"
                          />
                        </div>
                      </div>

                      {/* Constraints Info Indicator */}
                      <div className="bg-slate-100/80 p-2.5 rounded-xl text-[9px] font-medium text-slate-600 border border-slate-200/50 flex flex-col gap-1">
                        <p className="flex items-center gap-1 font-bold text-slate-700 text-[10px]">
                          <Info className="w-3 h-3 text-blue-500" /> Planner Rotation Rules:
                        </p>
                        <p>1. Goalkeeper & highlighted <span className="font-bold text-amber-600">⭐ Star Players</span> play the entire {matchDuration} minutes without subbing off.</p>
                        <p>2. Standard and <span className="font-bold text-indigo-600">📉 Weaker Players</span> rotate in windows to balance and equalize total playtime.</p>
                      </div>

                      {/* Sub Plan Result Display */}
                      {subPlanResult && ('error' in subPlanResult) ? (
                        <div className="p-3 bg-amber-50 border border-amber-200 rounded-2xl text-[10px] font-bold text-amber-800 text-center">
                          {subPlanResult.error}
                        </div>
                      ) : subPlanResult ? (
                        <div className="space-y-3.5">
                          {/* Playtime Balance Chart/List */}
                          <div className="space-y-1.5">
                            <h5 className="text-[9px] font-black uppercase tracking-widest text-slate-400">Estimated Total Playtime</h5>
                            <div className="bg-white p-3 rounded-2xl border border-slate-150 shadow-sm space-y-2 max-h-[160px] overflow-y-auto">
                              {confirmedSquad.map(player => {
                                const mins = subPlanResult.playTimes[player.id] || 0;
                                const percent = Math.min(100, (mins / matchDuration) * 100);
                                const isStar = starPlayerIds.includes(player.id);
                                const isWeaker = weakerPlayerIds.includes(player.id);
                                const isFixed = subPlanResult.fixedPlayerIds.includes(player.id);

                                return (
                                  <div key={player.id} className="space-y-0.5 text-[10px]">
                                    <div className="flex justify-between items-center font-bold">
                                      <span className="flex items-center gap-1 text-slate-700 truncate max-w-[180px]">
                                        {player.name} 
                                        {isStar && <span className="text-[8px] text-amber-500">⭐</span>}
                                        {isWeaker && <span className="text-[8px] text-indigo-500">📉</span>}
                                        {isFixed && !isStar && <span className="text-[8px] text-slate-400 font-normal">(GK)</span>}
                                      </span>
                                      <span className="text-slate-500 font-mono text-[9px]">{mins} min</span>
                                    </div>
                                    <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden flex">
                                      <div 
                                        className={`h-full rounded-full transition-all duration-500 ${
                                          isStar ? 'bg-amber-400' : isWeaker ? 'bg-indigo-500' : 'bg-blue-500'
                                        }`}
                                        style={{ width: `${percent}%` }}
                                      ></div>
                                    </div>
                                  </div>
                                );
                              })}
                            </div>
                          </div>

                          {/* Steps/Timeline */}
                          <div className="space-y-1.5">
                            <h5 className="text-[9px] font-black uppercase tracking-widest text-slate-400">Substitution Schedule</h5>
                            <div className="bg-white p-3 rounded-2xl border border-slate-150 shadow-sm space-y-2.5 max-h-[220px] overflow-y-auto">
                              <div className="flex items-start gap-2.5 text-[10px] font-bold border-l-2 border-green-500 pl-2.5 py-0.5">
                                <span className="font-mono text-green-600 bg-green-50 px-1 py-0.2 rounded text-[9px]">0'</span>
                                <div className="text-slate-600">
                                  <p className="text-slate-800 font-black">Kick-off Lineup Takes the Field</p>
                                  <p className="text-[8px] text-slate-400 font-medium">All starting positions are set.</p>
                                </div>
                              </div>

                              {subPlanResult.events.length === 0 ? (
                                <p className="text-[9px] text-slate-400 italic text-center py-2 font-bold">No substitution events needed. Add more players to rotation bench to plan swaps.</p>
                              ) : (
                                subPlanResult.events.map((evt, idx) => (
                                  <div key={idx} className="flex items-start gap-2.5 text-[10px] font-bold border-l-2 border-blue-500 pl-2.5 py-0.5">
                                    <span className="font-mono text-blue-600 bg-blue-50 px-1 py-0.2 rounded text-[9px]">{evt.minute}'</span>
                                    <div className="text-slate-600 space-y-1 flex-1">
                                      <p className="text-slate-800 font-black">Rotation Subs Window</p>
                                      <div className="space-y-0.5 bg-slate-50 p-1.5 rounded-lg border border-slate-100">
                                        {evt.subs.map((sub, sIdx) => (
                                          <div key={sIdx} className="flex items-center gap-1.5 flex-wrap">
                                            <span className="text-red-500 line-through truncate max-w-[80px]" title={sub.outName}>⬇s {sub.outName}</span>
                                            <span className="text-slate-300">➜</span>
                                            <span className="text-emerald-600 truncate max-w-[80px]" title={sub.inName}>⬆s {sub.inName}</span>
                                          </div>
                                        ))}
                                      </div>
                                    </div>
                                  </div>
                                ))
                              )}

                              <div className="flex items-start gap-2.5 text-[10px] font-bold border-l-2 border-slate-400 pl-2.5 py-0.5">
                                <span className="font-mono text-slate-600 bg-slate-100 px-1 py-0.2 rounded text-[9px]">{matchDuration}'</span>
                                <div className="text-slate-600">
                                  <p className="text-slate-800 font-black">Full-Time (Match Ends)</p>
                                  <p className="text-[8px] text-slate-400 font-medium">Equalized playtime accomplished!</p>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      ) : null}
                    </div>
                  )}
                </div>

                {/* Side info: squad members pool */}
                <div className="flex flex-col gap-4">
                  <div className="bg-slate-50 p-4 rounded-3xl border border-slate-100 flex-1 flex flex-col min-h-[250px]">
                    <div className="flex justify-between items-center mb-3">
                      <h4 className="text-[10px] font-black uppercase tracking-widest text-slate-500">Confirmed Players Pool</h4>
                      <span className="text-[9px] bg-slate-200 text-slate-600 px-1.5 py-0.5 rounded-full font-bold">
                        {confirmedSquad.filter(p => !Object.values(tacticalLineup).includes(p.id)).length} unassigned
                      </span>
                    </div>

                    <div className="flex-1 overflow-y-auto max-h-[350px] space-y-2 pr-1">
                      {confirmedSquad.length === 0 ? (
                        <div className="py-12 text-center">
                          <p className="text-xs text-slate-400 italic font-bold">No players are confirmed for this match yet.</p>
                        </div>
                      ) : (
                        confirmedSquad.map(player => {
                          const currentPosId = Object.keys(tacticalLineup).find(k => tacticalLineup[k] === player.id);
                          const pos = currentPosId ? (FORMATIONS[selectedFormation] || FORMATIONS['4-4-2']).find(p => p.id === currentPosId) : null;

                          return (
                            <div 
                              key={player.id} 
                              draggable={canModerate}
                              onDragStart={(e) => {
                                if (canModerate) {
                                  e.dataTransfer.setData('text/plain', player.id);
                                }
                              }}
                              className={`flex items-center justify-between p-2.5 bg-white rounded-xl border border-slate-150 shadow-sm transition-all ${
                                canModerate ? 'cursor-grab active:cursor-grabbing hover:border-slate-300 hover:shadow-md' : ''
                              }`}
                            >
                              <div className="flex items-center gap-2 min-w-0">
                                <img src={player.avatar} className="w-7 h-7 rounded-lg object-cover" alt="" />
                                <div className="min-w-0">
                                  <p className="text-xs font-black text-slate-700 truncate leading-none mb-0.5">{player.name}</p>
                                  <div className="flex items-center gap-1.5 leading-none">
                                    <p className="text-[8px] text-slate-400 uppercase font-black tracking-wider">
                                      Fav: {player.favPosition || 'Any'}
                                    </p>
                                    {canModerate && (
                                      <div className="flex items-center gap-0.5" onClick={(e) => e.stopPropagation()}>
                                        {[1, 2, 3, 4, 5].map((star) => {
                                          const rating = player.abilityRating || 0;
                                          return (
                                            <button
                                              key={star}
                                              type="button"
                                              onClick={() => {
                                                if (club && onUpdateClubMemberRating) {
                                                  onUpdateClubMemberRating(club.id, player.id, star);
                                                }
                                              }}
                                              className="p-0.5 hover:scale-125 transition-transform"
                                              title={`Set ability rating: ${star}/5`}
                                            >
                                              <Star
                                                className={`w-2.5 h-2.5 ${
                                                  star <= rating
                                                    ? 'fill-amber-400 text-amber-400'
                                                    : 'text-slate-200 hover:text-amber-300'
                                                }`}
                                              />
                                            </button>
                                          );
                                        })}
                                      </div>
                                    )}
                                  </div>
                                  
                                  <div className="flex flex-wrap items-center gap-1.5 mt-1" onClick={(e) => e.stopPropagation()}>
                                    {/* Star / Weaker badges for everyone */}
                                    {starPlayerIds.includes(player.id) && (
                                      <span className="bg-amber-100 text-amber-800 border border-amber-200 px-1.5 py-0.5 rounded text-[7px] font-black uppercase tracking-wider flex items-center gap-0.5 shadow-sm">
                                        ⭐ Star
                                      </span>
                                    )}
                                    {weakerPlayerIds.includes(player.id) && (
                                      <span className="bg-indigo-100 text-indigo-800 border border-indigo-200 px-1.5 py-0.5 rounded text-[7px] font-black uppercase tracking-wider flex items-center gap-0.5 shadow-sm">
                                        📉 Weaker
                                      </span>
                                    )}

                                    {/* Edit controls for manager/admin */}
                                    {canModerate && (
                                      <div className="flex items-center gap-1 border-l border-slate-150 pl-1.5 ml-1">
                                        <button
                                          onClick={() => togglePlayerTier(player.id, 'STAR')}
                                          className={`px-1.5 py-0.5 rounded text-[7px] font-black uppercase tracking-wider border transition-all ${
                                            starPlayerIds.includes(player.id)
                                              ? 'bg-amber-500 text-white border-amber-600'
                                              : 'bg-slate-50 text-slate-500 hover:bg-amber-50 hover:text-amber-600 border-slate-250'
                                          }`}
                                          title="Mark as Star Player (keeps on pitch)"
                                        >
                                          Star
                                        </button>
                                        <button
                                          onClick={() => togglePlayerTier(player.id, 'WEAKER')}
                                          className={`px-1.5 py-0.5 rounded text-[7px] font-black uppercase tracking-wider border transition-all ${
                                            weakerPlayerIds.includes(player.id)
                                              ? 'bg-indigo-600 text-white border-indigo-700'
                                              : 'bg-slate-50 text-slate-500 hover:bg-indigo-50 hover:text-indigo-600 border-slate-250'
                                          }`}
                                          title="Mark as Developing/Weaker Player"
                                        >
                                          Weaker
                                        </button>
                                        {(starPlayerIds.includes(player.id) || weakerPlayerIds.includes(player.id)) && (
                                          <button
                                            onClick={() => togglePlayerTier(player.id, 'STANDARD')}
                                            className="px-1 py-0.5 rounded bg-red-50 hover:bg-red-100 text-red-600 border border-red-100 text-[7px] font-black uppercase"
                                            title="Reset to standard rotation"
                                          >
                                            Reset
                                          </button>
                                        )}
                                      </div>
                                    )}
                                  </div>
                                </div>
                              </div>

                              {pos ? (
                                <span className="bg-blue-50 text-blue-600 px-2 py-0.5 rounded text-[8px] font-black uppercase border border-blue-100">
                                  {pos.label}
                                </span>
                              ) : (
                                canModerate && (
                                  <button
                                    onClick={() => {
                                      const openPos = (FORMATIONS[selectedFormation] || FORMATIONS['4-4-2']).find(
                                        p => !tacticalLineup[p.id]
                                      );
                                      if (openPos) {
                                        setTacticalLineup(prev => ({
                                          ...prev,
                                          [openPos.id]: player.id
                                        }));
                                      }
                                    }}
                                    className="p-1 text-slate-400 hover:text-blue-600 transition-colors"
                                    title="Add to pitch"
                                  >
                                    <Plus className="w-4 h-4" />
                                  </button>
                                )
                              )}
                            </div>
                          );
                        })
                      )}
                    </div>
                  </div>

                  {/* Actions footer */}
                  {canModerate && (
                    <div className="space-y-2">
                      <button
                        onClick={handleSaveTactics}
                        disabled={isSavingTactics}
                        className="w-full bg-slate-900 text-white py-3 rounded-xl font-black text-[10px] uppercase tracking-widest shadow-lg hover:bg-slate-800 transition-all flex items-center justify-center gap-2"
                      >
                        {isSavingTactics ? (
                          <RefreshCw className="w-4 h-4 animate-spin" />
                        ) : (
                          <Check className="w-4 h-4" />
                        )}
                        {isSavingTactics ? 'Saving Layout...' : 'Save Layout & Teams'}
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Quick help guide */}
            <div className="bg-slate-100/50 rounded-[2.5rem] p-6 border border-slate-200/50 text-center">
              <h4 className="font-bold text-slate-800 text-xs mb-1">💡 Interactive Pitch Guide</h4>
              <p className="text-[10px] text-slate-500 max-w-md mx-auto leading-relaxed">
                Click on any dashed slot on the pitch to assign a confirmed player to that position. Hover or click an assigned player to swap or unassign them. Saving the layout automatically sets starting players and moves the rest to the bench!
              </p>
            </div>

            {/* Assignment dialog overlay */}
            {isAssigningPos && (
              <div className="fixed inset-0 z-[120] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-300">
                <div className="bg-white rounded-[2rem] shadow-2xl w-full max-w-sm overflow-hidden animate-in zoom-in-95 duration-300">
                  <div className="p-6 border-b border-slate-100 flex items-center justify-between">
                    <div>
                      <h3 className="text-lg font-black text-slate-900">Assign Player</h3>
                      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                        Position: {(FORMATIONS[selectedFormation] || FORMATIONS['4-4-2']).find(p => p.id === isAssigningPos)?.label}
                      </p>
                    </div>
                    <button onClick={() => setIsAssigningPos(null)} className="p-2 hover:bg-slate-100 rounded-full transition-colors text-slate-400">
                      <X className="w-5 h-5" />
                    </button>
                  </div>
                  <div className="p-4 max-h-[300px] overflow-y-auto space-y-2">
                    {confirmedSquad.length === 0 ? (
                      <p className="text-xs text-slate-400 text-center py-6 font-bold">No players have confirmed attendance yet.</p>
                    ) : (
                      <>
                        {tacticalLineup[isAssigningPos] && (
                          <button
                            onClick={() => {
                              setTacticalLineup(prev => {
                                const next = { ...prev };
                                delete next[isAssigningPos];
                                return next;
                              });
                              setIsAssigningPos(null);
                            }}
                            className="w-full flex items-center gap-3 p-3 text-red-600 hover:bg-red-50 rounded-xl transition-all font-bold text-xs uppercase tracking-widest"
                          >
                            <X className="w-4 h-4" /> Clear Position
                          </button>
                        )}
                        
                        {confirmedSquad.map(player => {
                          const isAssignedElsewhere = Object.entries(tacticalLineup).some(
                            ([posId, pId]) => posId !== isAssigningPos && pId === player.id
                          );
                          
                          return (
                            <button
                              key={player.id}
                              disabled={isAssignedElsewhere}
                              onClick={() => {
                                setTacticalLineup(prev => {
                                  const next = { ...prev };
                                  Object.keys(next).forEach(k => {
                                    if (next[k] === player.id) delete next[k];
                                  });
                                  next[isAssigningPos] = player.id;
                                  return next;
                                });
                                setIsAssigningPos(null);
                              }}
                              className={`w-full flex items-center justify-between p-3 rounded-xl transition-all border text-left ${
                                isAssignedElsewhere 
                                  ? 'opacity-40 bg-slate-50 border-transparent cursor-not-allowed' 
                                  : tacticalLineup[isAssigningPos] === player.id
                                    ? 'bg-blue-50 border-blue-200 text-blue-700'
                                    : 'bg-white hover:bg-slate-50 border-slate-100'
                              }`}
                            >
                              <div className="flex items-center gap-3">
                                <img src={player.avatar} className="w-8 h-8 rounded-lg object-cover" alt="" />
                                <div>
                                  <span className="text-xs font-black text-slate-800 block leading-tight">{player.name}</span>
                                  {player.favPosition && (
                                    <span className="text-[9px] font-black uppercase text-blue-500 tracking-wider">
                                      Fav: {player.favPosition}
                                    </span>
                                  )}
                                </div>
                              </div>
                              {tacticalLineup[isAssigningPos] === player.id && <Check className="w-4 h-4 text-blue-600" />}
                            </button>
                          );
                        })}
                      </>
                    )}
                  </div>
                </div>
              </div>
            )}
          </div>
        ) : (
          <div className="space-y-8 animate-in fade-in duration-500 pb-10">
            <div className="text-center py-8">
              <div className="inline-flex p-5 bg-blue-50 text-blue-600 rounded-[2rem] mb-4"><Users className="w-8 h-8" /></div>
              <h2 className="text-2xl font-black text-slate-900 tracking-tight">Availability</h2>
              <p className="text-sm text-slate-500 font-medium mt-1">Confirmed players for this game</p>
              {club?.type === 'SOCIAL' && canModerate && allMatches && (
                <div className="mt-6">
                  <button 
                    onClick={handleSuggestTeams}
                    className="inline-flex items-center gap-2 bg-blue-600 text-white px-6 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-lg shadow-blue-100 hover:bg-blue-700 transition-all"
                  >
                    <Sparkles className="w-4 h-4" /> Suggest Balanced Teams
                  </button>
                </div>
              )}
            </div>

            <div className="space-y-10">
              {/* Team Selection for Social Clubs */}
              {club?.type === 'SOCIAL' && canModerate && (
                <div className="bg-white p-6 rounded-[2.5rem] border border-slate-200 shadow-sm space-y-6">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-blue-600 text-white rounded-xl shadow-lg shadow-blue-100">
                        <Users className="w-5 h-5" />
                      </div>
                      <div>
                        <h3 className="font-black text-slate-900 text-sm">Team Assignments</h3>
                        <p className="text-[10px] font-black uppercase text-slate-400 tracking-widest">Assign players to Team A or B</p>
                      </div>
                    </div>
                    <div className="flex gap-4">
                      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">A: {teamADraft.length}</p>
                      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">B: {teamBDraft.length}</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {/* Team A */}
                    <div className="space-y-3">
                      <h4 className="text-[10px] font-black uppercase tracking-widest text-blue-600 flex items-center gap-2">
                        {teamAName}
                      </h4>
                      <div className="bg-blue-50/50 rounded-2xl p-3 border border-blue-100 min-h-[100px] space-y-2">
                        {confirmedSquad.filter(p => teamADraft.includes(p.id)).map(p => (
                          <div key={p.id} className="flex items-center justify-between p-2 bg-white rounded-xl border border-blue-100 shadow-sm">
                            <div className="flex items-center gap-2">
                              <img src={p.avatar} className="w-6 h-6 rounded-lg object-cover" alt="" />
                              <span className="text-xs font-bold text-slate-700">{p.name}</span>
                            </div>
                            <button onClick={() => toggleTeamAssignment(p.id, null)} className="p-1 text-slate-300 hover:text-red-500 transition-colors">
                              <X className="w-4 h-4" />
                            </button>
                          </div>
                        ))}
                        {confirmedSquad.filter(p => teamADraft.includes(p.id)).length === 0 && <p className="text-[10px] text-slate-400 italic text-center py-4">No players in Team A</p>}
                      </div>
                    </div>

                    {/* Team B */}
                    <div className="space-y-3">
                      <h4 className="text-[10px] font-black uppercase tracking-widest text-slate-500 flex items-center gap-2">
                        {teamBName}
                      </h4>
                      <div className="bg-slate-100/50 rounded-2xl p-3 border border-slate-200 min-h-[100px] space-y-2">
                        {confirmedSquad.filter(p => teamBDraft.includes(p.id)).map(p => (
                          <div key={p.id} className="flex items-center justify-between p-2 bg-white rounded-xl border border-slate-200 shadow-sm">
                            <div className="flex items-center gap-2">
                              <img src={p.avatar} className="w-6 h-6 rounded-lg object-cover" alt="" />
                              <span className="text-xs font-bold text-slate-700">{p.name}</span>
                            </div>
                            <button onClick={() => toggleTeamAssignment(p.id, null)} className="p-1 text-slate-300 hover:text-red-500 transition-colors">
                              <X className="w-4 h-4" />
                            </button>
                          </div>
                        ))}
                        {confirmedSquad.filter(p => teamBDraft.includes(p.id)).length === 0 && <p className="text-[10px] text-slate-400 italic text-center py-4">No players in Team B</p>}
                      </div>
                    </div>
                  </div>

                  {/* Unassigned Players */}
                  {confirmedSquad.filter(p => !teamADraft.includes(p.id) && !teamBDraft.includes(p.id)).length > 0 && (
                    <div className="space-y-3 pt-4 border-t border-slate-100">
                      <h4 className="text-[10px] font-black uppercase tracking-widest text-slate-500">Unassigned Players</h4>
                      <div className="flex flex-wrap gap-2">
                        {confirmedSquad.filter(p => !teamADraft.includes(p.id) && !teamBDraft.includes(p.id)).map(p => (
                          <div key={p.id} className="flex items-center gap-2 bg-white px-3 py-2 rounded-xl border border-slate-100 shadow-sm">
                            <img src={p.avatar} className="w-6 h-6 rounded-lg object-cover" alt="" />
                            <span className="text-xs font-bold text-slate-700">{p.name}</span>
                            <div className="flex gap-1 ml-2">
                              <button 
                                onClick={() => toggleTeamAssignment(p.id, 'A')}
                                className="px-2 py-1 bg-blue-50 text-blue-600 rounded-lg text-[8px] font-black uppercase tracking-widest hover:bg-blue-100 transition-all"
                              >
                                Team A
                              </button>
                              <button 
                                onClick={() => toggleTeamAssignment(p.id, 'B')}
                                className="px-2 py-1 bg-slate-100 text-slate-600 rounded-lg text-[8px] font-black uppercase tracking-widest hover:bg-slate-200 transition-all"
                              >
                                Team B
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                  
                  <button 
                    onClick={handleSaveSocialStats}
                    className="w-full bg-slate-900 text-white py-3 rounded-xl font-black text-[10px] uppercase tracking-widest shadow-lg hover:bg-slate-800 transition-all"
                  >
                    Save Team Assignments
                  </button>
                </div>
              )}

              {/* Lineup Selection for Admins (Competitive Clubs Only) */}
              {club?.type !== 'SOCIAL' && canModerate && match.status === 'UPCOMING' && (
                <div className="bg-blue-50/50 p-6 rounded-[2.5rem] border border-blue-100 space-y-6">
                  <div className="flex items-center gap-3 mb-2">
                    <div className="p-2 bg-blue-600 text-white rounded-xl shadow-lg shadow-blue-100">
                      <LayoutGrid className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="font-black text-slate-900 text-sm">Match Lineup</h3>
                      <p className="text-[10px] font-black uppercase text-slate-400 tracking-widest">Select starting XI and bench</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {/* Starting XI */}
                    <div className="space-y-3">
                      <h4 className="text-[10px] font-black uppercase tracking-widest text-slate-500 flex items-center gap-2">
                        Starting XI ({startingLineup.length})
                      </h4>
                      <div className="bg-white/60 rounded-2xl p-3 border border-slate-100 min-h-[100px] space-y-2">
                        {startingLineup.map(p => (
                          <div key={p.id} className="flex items-center justify-between p-2 bg-white rounded-xl border border-slate-100 shadow-sm">
                            <div className="flex items-center gap-2">
                              <img src={p.avatar} className="w-6 h-6 rounded-lg object-cover" alt="" />
                              <span className="text-xs font-bold text-slate-700">{p.name}</span>
                            </div>
                            <button onClick={() => handleUnassign(p.id)} className="p-1 text-slate-300 hover:text-red-500 transition-colors">
                              <X className="w-4 h-4" />
                            </button>
                          </div>
                        ))}
                        {startingLineup.length === 0 && <p className="text-[10px] text-slate-400 italic text-center py-4">No starters selected</p>}
                      </div>
                    </div>

                    {/* Bench */}
                    <div className="space-y-3">
                      <h4 className="text-[10px] font-black uppercase tracking-widest text-slate-500 flex items-center gap-2">
                        Bench ({bench.length})
                      </h4>
                      <div className="bg-white/60 rounded-2xl p-3 border border-slate-100 min-h-[100px] space-y-2">
                        {bench.map(p => (
                          <div key={p.id} className="flex items-center justify-between p-2 bg-white rounded-xl border border-slate-100 shadow-sm">
                            <div className="flex items-center gap-2">
                              <img src={p.avatar} className="w-6 h-6 rounded-lg object-cover" alt="" />
                              <span className="text-xs font-bold text-slate-700">{p.name}</span>
                            </div>
                            <button onClick={() => handleUnassign(p.id)} className="p-1 text-slate-300 hover:text-red-500 transition-colors">
                              <X className="w-4 h-4" />
                            </button>
                          </div>
                        ))}
                        {bench.length === 0 && <p className="text-[10px] text-slate-400 italic text-center py-4">No subs selected</p>}
                      </div>
                    </div>
                  </div>

                  {/* Unassigned Confirmed Players */}
                  {unassigned.length > 0 && (
                    <div className="space-y-3 pt-4 border-t border-blue-100">
                      <h4 className="text-[10px] font-black uppercase tracking-widest text-slate-500">Available to Assign</h4>
                      <div className="flex flex-wrap gap-2">
                        {unassigned.map(p => (
                          <div key={p.id} className="flex items-center gap-2 bg-white px-3 py-2 rounded-xl border border-slate-100 shadow-sm">
                            <img src={p.avatar} className="w-6 h-6 rounded-lg object-cover" alt="" />
                            <span className="text-xs font-bold text-slate-700">{p.name}</span>
                            <div className="flex gap-1 ml-2">
                              <button 
                                onClick={() => handleMoveToLineup(p.id)}
                                className="p-1 bg-green-50 text-green-600 rounded-lg hover:bg-green-100 transition-all"
                                title="Add to Lineup"
                              >
                                <Users className="w-3.5 h-3.5" />
                              </button>
                              <button 
                                onClick={() => handleMoveToBench(p.id)}
                                className="p-1 bg-amber-50 text-amber-600 rounded-lg hover:bg-amber-100 transition-all"
                                title="Add to Bench"
                              >
                                <ArrowRightLeft className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Confirmed Section */}
              <div className="space-y-4">
                <div className="flex items-center justify-between px-2">
                  <h3 className="text-[10px] font-black uppercase tracking-widest text-slate-400 flex items-center gap-2">
                    <UserCheck className="w-3.5 h-3.5 text-green-500" /> Confirmed ({confirmedSquad.length})
                  </h3>
                </div>
                <div className="space-y-2">
                  {confirmedSquad.length === 0 ? (
                    <div className="p-8 text-center bg-white rounded-[2rem] border border-dashed border-slate-200">
                      <p className="text-xs text-slate-400 font-bold">No confirmed players yet</p>
                    </div>
                  ) : confirmedSquad.map(player => renderPlayerRow(player))}
                </div>
              </div>

              {/* Pending Section */}
              {squadPlayers.filter(p => p.status === 'PENDING').length > 0 && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between px-2">
                    <h3 className="text-[10px] font-black uppercase tracking-widest text-slate-400 flex items-center gap-2">
                      <Clock className="w-3.5 h-3.5 text-amber-500" /> Pending ({squadPlayers.filter(p => p.status === 'PENDING').length})
                    </h3>
                  </div>
                  <div className="space-y-2">
                    {squadPlayers.filter(p => p.status === 'PENDING').map(player => renderPlayerRow(player))}
                  </div>
                </div>
              )}

              {/* Unavailable Section */}
              {squadPlayers.filter(p => p.status === 'UNAVAILABLE').length > 0 && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between px-2">
                    <h3 className="text-[10px] font-black uppercase tracking-widest text-slate-400 flex items-center gap-2">
                      <UserX className="w-3.5 h-3.5 text-red-500" /> Unavailable ({squadPlayers.filter(p => p.status === 'UNAVAILABLE').length})
                    </h3>
                  </div>
                  <div className="space-y-2 opacity-60">
                    {squadPlayers.filter(p => p.status === 'UNAVAILABLE').map(player => renderPlayerRow(player))}
                  </div>
                </div>
              )}
            </div>

            <div className="bg-slate-100/50 rounded-[2.5rem] p-8 border border-slate-200/50 text-center">
              <Shield className="w-10 h-10 text-slate-300 mx-auto mb-3" />
              <h3 className="font-bold text-slate-900 text-sm">Opponent: {match.opponentName || 'TBC'}</h3>
              <p className="text-[10px] font-black uppercase text-slate-400 tracking-widest mt-1">Lineup confirmed at venue</p>
            </div>
          </div>
        )}
      </div>

      {isMember && activeView === 'FEED' && club?.type !== 'SOCIAL' && (
        <div className="absolute bottom-0 left-0 right-0 p-1.5 sm:p-4 z-40 pointer-events-none">
          <div className="max-w-4xl mx-auto pointer-events-auto">
            <div className="bg-white/95 backdrop-blur-2xl rounded-xl sm:rounded-[2.5rem] shadow-[0_8px_20px_-12px_rgba(0,0,0,0.15)] sm:shadow-[0_20px_50px_-12px_rgba(0,0,0,0.25)] border border-white/50 overflow-hidden transition-all duration-300 ring-1 ring-black/5">
              {activeActionType && isMatchInPlay && (
                <div className="p-3.5 sm:p-5 bg-slate-50/80 border-b border-slate-100 animate-in slide-in-from-bottom-4 duration-300">
                  <div className="flex items-center justify-between mb-2.5 sm:mb-4">
                    <div className="flex items-center gap-1.5 sm:gap-2"><div className="p-1.5 sm:p-2 bg-blue-600 text-white rounded-xl shadow-lg shadow-blue-100">{liveIconMapping[activeActionType]}</div><span className="font-black text-[9px] sm:text-[10px] uppercase tracking-widest text-slate-900">{activeActionType.replace('_', ' ')} Detail</span></div>
                    <button type="button" onClick={() => setActiveActionType(null)} className="p-1 sm:p-1.5 text-slate-400 hover:text-slate-600 hover:bg-white rounded-full transition-all border border-transparent hover:border-slate-200"><X className="w-4 h-4 sm:w-5 sm:h-5" /></button>
                  </div>
                  <div className="flex flex-col gap-2.5 sm:gap-4">
                    <div className="flex gap-1.5 p-1 bg-white rounded-xl sm:rounded-2xl border border-slate-200">
                      <button type="button" onClick={() => setSelectedTeam('A')} className={`flex-1 py-1.5 sm:py-2 rounded-lg sm:rounded-xl font-black text-[9px] sm:text-[10px] uppercase tracking-widest transition-all ${selectedTeam === 'A' ? 'bg-slate-900 text-white shadow-md' : 'text-slate-400'}`}>{teamAName}</button>
                      <button type="button" onClick={() => setSelectedTeam('B')} className={`flex-1 py-1.5 sm:py-2 rounded-lg sm:rounded-xl font-black text-[9px] sm:text-[10px] uppercase tracking-widest transition-all ${selectedTeam === 'B' ? 'bg-slate-900 text-white shadow-md' : 'text-slate-400'}`}>{teamBName}</button>
                    </div>
                    {selectedTeam === 'A' && (activeActionType === 'GOAL' || activeActionType === 'YELLOW_CARD' || activeActionType === 'RED_CARD' || activeActionType === 'SUB') && (
                      <div className="flex flex-col sm:flex-row gap-2 sm:gap-3">
                        <select required value={selectedPlayerId} onChange={(e) => setSelectedPlayerId(e.target.value)} className="flex-1 bg-white border border-slate-200 rounded-xl px-3 py-2 sm:px-4 sm:py-2.5 text-xs font-bold focus:outline-none focus:border-blue-500 appearance-none shadow-sm text-slate-900">
                          <option value="">Select Scorer/Player...</option>
                          {confirmedSquad.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                        </select>
                        {activeActionType === 'SUB' && (
                          <select required value={selectedPlayerId2} onChange={(e) => setSelectedPlayerId2(e.target.value)} className="flex-1 bg-white border border-slate-200 rounded-xl px-3 py-2 sm:px-4 sm:py-2.5 text-xs font-bold focus:outline-none focus:border-blue-500 appearance-none shadow-sm text-slate-900">
                            <option value="">Select Player In...</option>
                            {confirmedSquad.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                          </select>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              )}
              <form onSubmit={handleSubmitAction} className="p-2 sm:p-4 flex flex-col gap-2 sm:gap-3">
                {selectedImage && (
                  <div className="relative w-full aspect-video rounded-2xl overflow-hidden border border-slate-200 mb-2">
                    <img src={selectedImage} alt="Preview" className="w-full h-full object-cover" />
                    <button 
                      type="button"
                      onClick={() => setSelectedImage(null)}
                      className="absolute top-2 right-2 p-1.5 bg-black/50 text-white rounded-full hover:bg-black/70 transition-colors"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                )}
                <div className="flex gap-2 sm:gap-3 items-center w-full">
                  <div className="relative flex-1">
                    <input 
                      type="text" 
                      value={newEventContent} 
                      onChange={(e) => setNewEventContent(e.target.value)} 
                      placeholder={selectedImage ? "Add a caption..." : (activeActionType ? "Add highlight notes..." : "Post live commentary...")} 
                      className="w-full bg-slate-50 border border-slate-200 rounded-lg sm:rounded-[1.5rem] pl-3.5 sm:pl-6 pr-4 py-1.5 sm:py-4 h-9 sm:h-14 text-xs sm:text-sm font-medium focus:outline-none focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 transition-all placeholder:text-slate-300" 
                    />
                    {activeActionType && <div className="absolute right-2.5 sm:right-4 top-1/2 -translate-y-1/2"><div className="px-1.5 py-0.5 sm:px-2 sm:py-1 bg-blue-50 text-blue-600 text-[7px] sm:text-[8px] font-black uppercase rounded-md tracking-widest border border-blue-100">{activeActionType.split('_')[0]}</div></div>}
                  </div>
                  <input 
                    type="file" 
                    id="photo-upload" 
                    accept="image/*" 
                    className="hidden" 
                    onChange={handleImageUpload}
                  />
                  <label 
                    htmlFor="photo-upload"
                    className="h-9 w-9 sm:h-14 sm:w-14 bg-slate-100 text-slate-600 rounded-lg sm:rounded-[1.5rem] hover:bg-slate-200 transition-all cursor-pointer flex items-center justify-center shrink-0"
                  >
                    <Camera className="w-3.5 h-3.5 sm:w-6 sm:h-6" />
                  </label>
                  <button type="submit" className="h-9 w-9 sm:h-14 sm:w-14 bg-blue-600 text-white rounded-lg sm:rounded-[1.5rem] shadow-xl shadow-blue-100 hover:bg-blue-700 hover:scale-105 active:scale-95 transition-all flex items-center justify-center shrink-0"><Send className="w-3.5 h-3.5 sm:w-6 sm:h-6" /></button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-300">
          <div className="bg-white rounded-[2rem] shadow-2xl w-full max-w-md overflow-hidden animate-in zoom-in-95 duration-300">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between">
              <h3 className="text-xl font-bold text-red-900">Delete Match Completely</h3>
              <button onClick={() => setShowDeleteConfirm(false)} className="p-2 hover:bg-slate-100 rounded-full transition-colors text-slate-400">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-8 text-center space-y-6">
              <Trash2 className="w-16 h-16 text-red-500 mx-auto animate-bounce" />
              <div>
                <p className="text-slate-900 font-black text-lg">Are you absolutely sure?</p>
                <p className="text-slate-500 font-medium leading-relaxed mt-1 text-sm">
                  This will completely and permanently remove this match and all its events, stats, and live timeline records from Firestore.
                </p>
              </div>
              <div className="flex gap-4">
                <button 
                  type="button" 
                  onClick={() => setShowDeleteConfirm(false)}
                  className="flex-1 py-3.5 rounded-xl font-black text-slate-500 bg-slate-100 hover:bg-slate-200 transition-all uppercase tracking-widest text-[10px]"
                >
                  Keep Match
                </button>
                <button 
                  type="button" 
                  onClick={() => {
                    if (onDeleteMatch) {
                      onDeleteMatch(match.id);
                    }
                    setShowDeleteConfirm(false);
                  }}
                  className="flex-1 py-3.5 rounded-xl font-black text-white bg-red-600 shadow-xl shadow-red-100 hover:bg-red-700 transition-all uppercase tracking-widest text-[10px]"
                >
                  <Trash2 className="w-4 h-4 inline-block mr-1" /> Yes, Delete
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};


import React, { useMemo, useState } from 'react';
import { Club, Match, FeedEvent, User } from '../types';
import { 
  Trophy, 
  Target, 
  Users, 
  TrendingUp, 
  Activity, 
  Award,
  ChevronRight,
  BarChart3,
  PieChart as PieChartIcon,
  Calendar,
  Clock,
  Filter,
  Download,
  FileText,
  AlertTriangle,
  AlertOctagon,
  BookOpen,
  Camera,
  X
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  Cell,
  PieChart,
  Pie
} from 'recharts';

interface StatsDashboardProps {
  club: Club;
  matches: Match[];
  events: FeedEvent[];
}

const StatsDashboard: React.FC<StatsDashboardProps> = ({ club, matches, events }) => {
  const [selectedMatchId, setSelectedMatchId] = useState<string>('all');
  const [showReport, setShowReport] = useState(false);
  const [showMemoryBook, setShowMemoryBook] = useState(false);

  const clubMatches = useMemo(() => {
    const base = matches.filter(m => m.clubId === club.id && m.status === 'COMPLETED');
    if (selectedMatchId === 'all') return base;
    return base.filter(m => m.id === selectedMatchId);
  }, [matches, club.id, selectedMatchId]);

  const stats = useMemo(() => {
    let wins = 0;
    let draws = 0;
    let losses = 0;
    let goalsFor = 0;
    let goalsAgainst = 0;

    clubMatches.forEach(m => {
      const isTeam = club.type === 'TEAM';
      let clubScore = 0;
      let oppScore = 0;

      if (isTeam) {
        if (m.isHome) {
          clubScore = m.scoreA;
          oppScore = m.scoreB;
        } else {
          clubScore = m.scoreB;
          oppScore = m.scoreA;
        }
      } else {
        // For social matches, we just track total goals scored in the game
        clubScore = m.scoreA + m.scoreB;
        oppScore = 0;
      }

      goalsFor += clubScore;
      goalsAgainst += oppScore;

      if (isTeam) {
        if (clubScore > oppScore) wins++;
        else if (clubScore === oppScore) draws++;
        else losses++;
      }
    });

    // Player Stats
    const playerStats: Record<string, { 
      goals: number; 
      assists: number;
      apps: number; 
      name: string; 
      avatar: string; 
      minutesPlayed: number; 
      yellowCards: number; 
      redCards: number; 
      potmWins: number;
      ballsOverFence: number;
      isInjured: number;
      isLastMinuteDropout: number;
      wins: number;
      losses: number;
      draws: number;
    }> = {};
    
    // Initialize with club members
    club.members.forEach(m => {
      playerStats[m.id] = { 
        goals: 0, 
        assists: 0,
        apps: 0, 
        name: m.name, 
        avatar: m.avatar, 
        minutesPlayed: 0, 
        yellowCards: 0, 
        redCards: 0, 
        potmWins: 0,
        ballsOverFence: 0,
        isInjured: 0,
        isLastMinuteDropout: 0,
        wins: 0,
        losses: 0,
        draws: 0
      };
    });

    // Count Appearances, POTM, and Social Stats
    matches.filter(m => m.clubId === club.id && (selectedMatchId === 'all' || m.id === selectedMatchId)).forEach(m => {
      const availability = m.availability || {};
      Object.entries(availability).forEach(([userId, status]) => {
        if (status === 'CONFIRMED' && playerStats[userId]) {
          playerStats[userId].apps++;
        }
      });

      // Track Wins/Losses for players in social matches
      if (club.type === 'SOCIAL' && m.status === 'COMPLETED') {
        const teamA = m.teamA || [];
        const teamB = m.teamB || [];
        const scoreA = m.scoreA || 0;
        const scoreB = m.scoreB || 0;

        teamA.forEach(pid => {
          if (playerStats[pid]) {
            if (scoreA > scoreB) playerStats[pid].wins++;
            else if (scoreA < scoreB) playerStats[pid].losses++;
            else playerStats[pid].draws++;
          }
        });

        teamB.forEach(pid => {
          if (playerStats[pid]) {
            if (scoreB > scoreA) playerStats[pid].wins++;
            else if (scoreB < scoreA) playerStats[pid].losses++;
            else playerStats[pid].draws++;
          }
        });
      }

      // Aggregate manual player stats
      if (m.playerStats) {
        Object.entries(m.playerStats).forEach(([pid, pStat]) => {
          if (playerStats[pid]) {
            playerStats[pid].goals += pStat.goals || 0;
            playerStats[pid].assists += pStat.assists || 0;
            playerStats[pid].yellowCards += pStat.yellowCards || 0;
            playerStats[pid].redCards += pStat.redCards || 0;
            playerStats[pid].ballsOverFence += pStat.ballsOverFence || 0;
            if (pStat.isInjured) playerStats[pid].isInjured++;
            if (pStat.isLastMinuteDropout) playerStats[pid].isLastMinuteDropout++;
            playerStats[pid].minutesPlayed += pStat.minutesPlayed || 0;
          }
        });
      }

      // Calculate POTM for this match
      if (m.potmVotes && Object.keys(m.potmVotes).length > 0) {
        const voteCounts: Record<string, number> = {};
        Object.values(m.potmVotes).forEach(votedId => {
          voteCounts[votedId] = (voteCounts[votedId] || 0) + 1;
        });

        let winnerId = '';
        let maxVotes = 0;
        Object.entries(voteCounts).forEach(([pid, count]) => {
          if (count > maxVotes) {
            maxVotes = count;
            winnerId = pid;
          }
        });

        if (winnerId && playerStats[winnerId]) {
          playerStats[winnerId].potmWins++;
        }
      }
    });

    // Count Goals and Cards from events
    events.forEach(e => {
      if (selectedMatchId !== 'all' && e.matchId !== selectedMatchId) return;
      
      if (e.type === 'GOAL') {
        if (e.details?.scorer && playerStats[e.details.scorer]) {
          playerStats[e.details.scorer].goals++;
        }
        if (e.details?.assist && playerStats[e.details.assist]) {
          playerStats[e.details.assist].assists++;
        }
      }
      if (e.type === 'YELLOW_CARD' && e.details?.player && playerStats[e.details.player]) {
        playerStats[e.details.player].yellowCards++;
      }
      if (e.type === 'RED_CARD' && e.details?.player && playerStats[e.details.player]) {
        playerStats[e.details.player].redCards++;
      }
    });

    // Calculate Minutes Played
    matches.filter(m => m.clubId === club.id && m.status === 'COMPLETED' && (selectedMatchId === 'all' || m.id === selectedMatchId)).forEach(m => {
      const matchEvents = events.filter(e => e.matchId === m.id).sort((a, b) => a.timestamp.getTime() - b.timestamp.getTime());
      
      const startEvent = matchEvents.find(e => e.type === 'START');
      const endEvent = matchEvents.find(e => e.type === 'END');
      const halfTimeEvent = matchEvents.find(e => e.type === 'HALF_TIME');
      const secondHalfEvent = matchEvents.find(e => e.type === 'SECOND_HALF');

      if (!startEvent || !endEvent) return;

      // Track who is on the pitch
      let playersOnPitch = new Set<string>(m.startingLineupIds || []);
      
      const calculateSegment = (from: FeedEvent, to: FeedEvent) => {
        const segmentDuration = Math.round((to.timestamp.getTime() - from.timestamp.getTime()) / 60000);
        if (segmentDuration <= 0) return;

        // Sub-segments based on subs and red cards
        const segmentEvents = matchEvents.filter(e => 
          (e.type === 'SUB' || e.type === 'RED_CARD') && 
          e.timestamp > from.timestamp && 
          e.timestamp < to.timestamp &&
          (e.type === 'RED_CARD' || e.details?.team === (m.isHome ? 'A' : 'B'))
        );

        let lastTime = from.timestamp.getTime();
        
        // Process each event in the segment
        segmentEvents.forEach(evt => {
          const evtTime = evt.timestamp.getTime();
          const minsBeforeEvt = Math.round((evtTime - lastTime) / 60000);
          
          playersOnPitch.forEach(pid => {
            if (playerStats[pid]) {
              playerStats[pid].minutesPlayed = (playerStats[pid].minutesPlayed || 0) + minsBeforeEvt;
            }
          });

          if (evt.type === 'SUB') {
            if (evt.details?.playerOut) playersOnPitch.delete(evt.details.playerOut);
            if (evt.details?.playerIn) playersOnPitch.add(evt.details.playerIn);
          } else if (evt.type === 'RED_CARD') {
            if (evt.details?.player) playersOnPitch.delete(evt.details.player);
          }
          
          lastTime = evtTime;
        });

        // Remaining time in segment
        const remainingMins = Math.round((to.timestamp.getTime() - lastTime) / 60000);
        playersOnPitch.forEach(pid => {
          if (playerStats[pid]) {
            playerStats[pid].minutesPlayed = (playerStats[pid].minutesPlayed || 0) + remainingMins;
          }
        });
      };

      if (halfTimeEvent) {
        calculateSegment(startEvent, halfTimeEvent);
        if (secondHalfEvent) {
          calculateSegment(secondHalfEvent, endEvent);
        }
      } else {
        calculateSegment(startEvent, endEvent);
      }
    });

    const topScorers = Object.values(playerStats)
      .filter(p => p.goals > 0)
      .sort((a, b) => b.goals - a.goals)
      .slice(0, 5);

    const topAssists = Object.values(playerStats)
      .filter(p => p.assists > 0)
      .sort((a, b) => b.assists - a.assists)
      .slice(0, 5);

    const topApps = Object.values(playerStats)
      .filter(p => p.apps > 0)
      .sort((a, b) => b.apps - a.apps)
      .slice(0, 5);

    const topMinutes = Object.values(playerStats)
      .filter(p => (p.minutesPlayed || 0) > 0)
      .sort((a, b) => (b.minutesPlayed || 0) - (a.minutesPlayed || 0))
      .slice(0, 5);

    const topCards = Object.values(playerStats)
      .filter(p => p.yellowCards > 0 || p.redCards > 0)
      .sort((a, b) => (b.redCards * 2 + b.yellowCards) - (a.redCards * 2 + a.yellowCards))
      .slice(0, 5);

    const topPotm = Object.values(playerStats)
      .filter(p => p.potmWins > 0)
      .sort((a, b) => b.potmWins - a.potmWins)
      .slice(0, 5);

    const topBallsOverFence = Object.values(playerStats)
      .filter(p => p.ballsOverFence > 0)
      .sort((a, b) => b.ballsOverFence - a.ballsOverFence)
      .slice(0, 5);

    const topInjured = Object.values(playerStats)
      .filter(p => p.isInjured > 0)
      .sort((a, b) => b.isInjured - a.isInjured)
      .slice(0, 5);

    const topDropouts = Object.values(playerStats)
      .filter(p => p.isLastMinuteDropout > 0)
      .sort((a, b) => b.isLastMinuteDropout - a.isLastMinuteDropout)
      .slice(0, 5);

    const topWinRate = Object.values(playerStats)
      .filter(p => (p.wins + p.losses + p.draws) >= 3) // Minimum 3 games for win rate
      .sort((a, b) => {
        const rateA = a.wins / (a.wins + a.losses + a.draws || 1);
        const rateB = b.wins / (b.wins + b.losses + b.draws || 1);
        return rateB - rateA;
      })
      .slice(0, 5);

    const memoryBook = matches
      .filter(m => m.clubId === club.id && m.status === 'COMPLETED')
      .map(m => {
        const matchEvents = events.filter(e => e.matchId === m.id);
        const photos = matchEvents.filter(e => e.type === 'MEDIA' && e.mediaUrl).map(e => ({
          url: e.mediaUrl!,
          caption: e.content,
          userName: e.userName,
          timestamp: e.timestamp
        }));
        
        return {
          matchId: m.id,
          title: m.title,
          date: m.date,
          summary: m.managerSummary,
          photos
        };
      })
      .filter(m => m.summary || m.photos.length > 0)
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

    return {
      wins,
      draws,
      losses,
      goalsFor,
      goalsAgainst,
      totalGames: clubMatches.length,
      topScorers,
      topAssists,
      topApps,
      topMinutes,
      topCards,
      topPotm,
      topBallsOverFence,
      topInjured,
      topDropouts,
      topWinRate,
      memoryBook,
      playerStats: Object.values(playerStats),
      winRate: clubMatches.length > 0 ? Math.round((wins / clubMatches.length) * 100) : 0
    };
  }, [clubMatches, club, events, matches, selectedMatchId]);

  const chartData = [
    { name: 'Wins', value: stats.wins, color: '#10b981' },
    { name: 'Draws', value: stats.draws, color: '#f59e0b' },
    { name: 'Losses', value: stats.losses, color: '#ef4444' },
  ];

  const goalsData = clubMatches.slice(-5).map((m, i) => ({
    name: `G${i + 1}`,
    goals: club.type === 'TEAM' ? (m.isHome ? m.scoreA : m.scoreB) : (m.scoreA + m.scoreB)
  }));

  return (
    <div className="space-y-6 sm:space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700 pb-24">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">Analytics Hub</h2>
          <p className="text-xs sm:text-sm text-slate-500 font-medium mt-1">Performance insights for {club.name}</p>
        </div>
        <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
          <div className="relative flex-1 md:flex-none">
            <Filter className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <select 
              value={selectedMatchId}
              onChange={(e) => setSelectedMatchId(e.target.value)}
              className="pl-10 pr-4 py-2 bg-white border border-slate-200 rounded-xl text-[10px] sm:text-xs font-black uppercase tracking-widest appearance-none focus:ring-2 focus:ring-blue-500 outline-none w-full md:min-w-[200px]"
            >
              <option value="all">All Matches</option>
              {matches.filter(m => m.clubId === club.id && m.status === 'COMPLETED').map(m => (
                <option key={m.id} value={m.id}>{m.title} ({new Date(m.date).toLocaleDateString()})</option>
              ))}
            </select>
          </div>
          <button 
            onClick={() => setShowMemoryBook(true)}
            className="flex-1 md:flex-none p-2 bg-white border border-slate-200 text-slate-700 rounded-xl shadow-sm hover:bg-slate-50 transition-all flex items-center justify-center gap-1.5 px-3 xs:px-4"
          >
            <BookOpen className="w-3.5 h-3.5 text-blue-600" />
            <span className="text-[9px] sm:text-[10px] font-black uppercase tracking-widest whitespace-nowrap">Memory Book</span>
          </button>
          <button 
            onClick={() => setShowReport(true)}
            className="flex-1 md:flex-none p-2 bg-slate-900 text-white rounded-xl shadow-lg shadow-slate-200 hover:bg-slate-800 transition-all flex items-center justify-center gap-1.5 px-3 xs:px-4"
          >
            <FileText className="w-3.5 h-3.5" />
            <span className="text-[9px] sm:text-[10px] font-black uppercase tracking-widest whitespace-nowrap">Report</span>
          </button>
        </div>
      </div>

      {showReport && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-2 xs:p-4">
          <div className="bg-white rounded-2xl sm:rounded-[3rem] w-full max-w-4xl max-h-[95vh] sm:max-h-[90vh] overflow-hidden flex flex-col shadow-2xl">
            <div className="p-4 xs:p-6 sm:p-8 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <div className="min-w-0">
                <h3 className="text-lg xs:text-xl sm:text-2xl font-black text-slate-900 tracking-tight truncate">Season Report</h3>
                <p className="text-[10px] xs:text-xs sm:text-sm text-slate-500 font-medium truncate">{club.name} • {new Date().getFullYear()} Summary</p>
              </div>
              <button onClick={() => setShowReport(false)} className="p-1.5 hover:bg-white rounded-lg sm:rounded-xl transition-all shrink-0">
                <X className="w-5 h-5 xs:w-6 xs:h-6 text-slate-400" />
              </button>
            </div>
            
            <div className="flex-1 overflow-y-auto p-4 xs:p-6 sm:p-8 space-y-6 sm:space-y-10">
              {/* Summary Section */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 sm:gap-6">
                <div className="bg-blue-50 p-4 xs:p-6 rounded-2xl sm:rounded-3xl border border-blue-100">
                  <p className="text-[8px] xs:text-[10px] font-black uppercase text-blue-600 tracking-widest mb-1">Total Games</p>
                  <p className="text-2xl xs:text-4xl font-black text-blue-900">{stats.totalGames}</p>
                </div>
                <div className="bg-emerald-50 p-4 xs:p-6 rounded-2xl sm:rounded-3xl border border-emerald-100">
                  <p className="text-[8px] xs:text-[10px] font-black uppercase text-emerald-600 tracking-widest mb-1">Win Rate</p>
                  <p className="text-2xl xs:text-4xl font-black text-emerald-900">{stats.winRate}%</p>
                </div>
                <div className="bg-amber-50 p-4 xs:p-6 rounded-2xl sm:rounded-3xl border border-amber-100">
                  <p className="text-[8px] xs:text-[10px] font-black uppercase text-amber-600 tracking-widest mb-1">Goals Scored</p>
                  <p className="text-2xl xs:text-4xl font-black text-amber-900">{stats.goalsFor}</p>
                </div>
              </div>

              {/* Full Squad Stats Table */}
              <div className="space-y-4">
                <h4 className="text-sm font-black text-slate-900 uppercase tracking-widest">Squad Performance</h4>
                <div className="overflow-x-auto rounded-3xl border border-slate-100">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="bg-slate-50">
                        <th className="p-4 text-[10px] font-black uppercase text-slate-400 tracking-widest">Player</th>
                        <th className="p-4 text-[10px] font-black uppercase text-slate-400 tracking-widest text-center">Apps</th>
                        <th className="p-4 text-[10px] font-black uppercase text-slate-400 tracking-widest text-center">Goals</th>
                        <th className="p-4 text-[10px] font-black uppercase text-slate-400 tracking-widest text-center">Assists</th>
                        <th className="p-4 text-[10px] font-black uppercase text-slate-400 tracking-widest text-center">Mins</th>
                        <th className="p-4 text-[10px] font-black uppercase text-slate-400 tracking-widest text-center">Yel</th>
                        <th className="p-4 text-[10px] font-black uppercase text-slate-400 tracking-widest text-center">Red</th>
                        <th className="p-4 text-[10px] font-black uppercase text-slate-400 tracking-widest text-center">POTM</th>
                        {club.type === 'SOCIAL' && (
                          <>
                            <th className="p-4 text-[10px] font-black uppercase text-slate-400 tracking-widest text-center">Balls Over</th>
                            <th className="p-4 text-[10px] font-black uppercase text-slate-400 tracking-widest text-center">Injuries</th>
                            <th className="p-4 text-[10px] font-black uppercase text-slate-400 tracking-widest text-center">Dropouts</th>
                            <th className="p-4 text-[10px] font-black uppercase text-slate-400 tracking-widest text-center">W/L/D</th>
                          </>
                        )}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-50">
                      {stats.playerStats.sort((a, b) => b.goals - a.goals || b.apps - a.apps).map(p => (
                        <tr key={p.name} className="hover:bg-slate-50/50 transition-colors">
                          <td className="p-4">
                            <div className="flex items-center gap-3">
                              <img src={p.avatar} className="w-8 h-8 rounded-lg object-cover" alt="" />
                              <span className="font-bold text-slate-700 text-sm">{p.name}</span>
                            </div>
                          </td>
                          <td className="p-4 text-center font-black text-slate-900">{p.apps}</td>
                          <td className="p-4 text-center font-black text-blue-600">{p.goals}</td>
                          <td className="p-4 text-center font-black text-emerald-600">{p.assists}</td>
                          <td className="p-4 text-center font-black text-slate-600">{p.minutesPlayed}</td>
                          <td className="p-4 text-center font-black text-amber-500">{p.yellowCards}</td>
                          <td className="p-4 text-center font-black text-red-500">{p.redCards}</td>
                          <td className="p-4 text-center font-black text-emerald-600">{p.potmWins}</td>
                          {club.type === 'SOCIAL' && (
                            <>
                              <td className="p-4 text-center font-black text-orange-600">{p.ballsOverFence}</td>
                              <td className="p-4 text-center font-black text-rose-600">{p.isInjured}</td>
                              <td className="p-4 text-center font-black text-slate-400">{p.isLastMinuteDropout}</td>
                              <td className="p-4 text-center font-black text-slate-500 text-[10px]">
                                {p.wins}/{p.losses}/{p.draws}
                              </td>
                            </>
                          )}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>

            <div className="p-4 xs:p-6 sm:p-8 border-t border-slate-100 bg-slate-50 flex justify-end gap-3 xs:gap-4">
              <button 
                onClick={() => window.print()}
                className="bg-slate-900 text-white px-4 py-2.5 xs:px-8 xs:py-4 rounded-xl xs:rounded-2xl font-black text-[10px] xs:text-xs uppercase tracking-widest shadow-xl shadow-slate-200 flex items-center gap-2"
              >
                <Download className="w-3.5 h-3.5 xs:w-4 xs:h-4" /> Export PDF
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Overview Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4">
        <div className="bg-white p-4 xs:p-6 rounded-2xl sm:rounded-[2rem] border border-slate-200 shadow-sm">
          <div className="p-2 sm:p-3 bg-blue-50 text-blue-600 rounded-xl sm:rounded-2xl w-fit mb-3 sm:mb-4">
            <Activity className="w-5 h-5" />
          </div>
          <p className="text-[8px] xs:text-[10px] font-black uppercase text-slate-400 tracking-widest">Played</p>
          <p className="text-xl xs:text-3xl font-black text-slate-900 mt-1">{stats.totalGames}</p>
        </div>
        <div className="bg-white p-4 xs:p-6 rounded-2xl sm:rounded-[2rem] border border-slate-200 shadow-sm">
          <div className="p-2 sm:p-3 bg-emerald-50 text-emerald-600 rounded-xl sm:rounded-2xl w-fit mb-3 sm:mb-4">
            <Trophy className="w-5 h-5" />
          </div>
          <p className="text-[8px] xs:text-[10px] font-black uppercase text-slate-400 tracking-widest">Win Rate</p>
          <p className="text-xl xs:text-3xl font-black text-slate-900 mt-1">{stats.winRate}%</p>
        </div>
        <div className="bg-white p-4 xs:p-6 rounded-2xl sm:rounded-[2rem] border border-slate-200 shadow-sm">
          <div className="p-2 sm:p-3 bg-orange-50 text-orange-600 rounded-xl sm:rounded-2xl w-fit mb-3 sm:mb-4">
            <Target className="w-5 h-5" />
          </div>
          <p className="text-[8px] xs:text-[10px] font-black uppercase text-slate-400 tracking-widest">Goals For</p>
          <p className="text-xl xs:text-3xl font-black text-slate-900 mt-1">{stats.goalsFor}</p>
        </div>
        <div className="bg-white p-4 xs:p-6 rounded-2xl sm:rounded-[2rem] border border-slate-200 shadow-sm">
          <div className="p-2 sm:p-3 bg-indigo-50 text-indigo-600 rounded-xl sm:rounded-2xl w-fit mb-3 sm:mb-4">
            <Users className="w-5 h-5" />
          </div>
          <p className="text-[8px] xs:text-[10px] font-black uppercase text-slate-400 tracking-widest">Squad Size</p>
          <p className="text-xl xs:text-3xl font-black text-slate-900 mt-1">{club.members.length}</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 sm:gap-8">
        {/* Record Chart */}
        <div className="bg-white p-4 xs:p-6 sm:p-8 rounded-2xl sm:rounded-[2.5rem] border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between mb-4 sm:mb-8">
            <h3 className="text-base sm:text-lg font-black text-slate-900 tracking-tight flex items-center gap-2">
              <PieChartIcon className="w-5 h-5 text-blue-600" /> Match Record
            </h3>
          </div>
          <div className="h-[220px] sm:h-[250px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={chartData}
                  cx="50%"
                  cy="50%"
                  innerRadius={50}
                  outerRadius={70}
                  paddingAngle={8}
                  dataKey="value"
                >
                  {chartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} stroke="none" />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)' }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="flex flex-wrap justify-center gap-3 sm:gap-6 mt-2">
            {chartData.map(item => (
              <div key={item.name} className="flex items-center gap-1.5">
                <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: item.color }}></div>
                <span className="text-[8px] sm:text-[10px] font-black uppercase text-slate-500 tracking-widest">{item.name} ({item.value})</span>
              </div>
            ))}
          </div>
        </div>

        {/* Recent Scoring */}
        <div className="bg-white p-4 xs:p-6 sm:p-8 rounded-2xl sm:rounded-[2.5rem] border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between mb-4 sm:mb-8">
            <h3 className="text-base sm:text-lg font-black text-slate-900 tracking-tight flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-emerald-600" /> Scoring Trend
            </h3>
            <span className="text-[8px] sm:text-[10px] font-black text-slate-400 uppercase tracking-widest">Last 5 Games</span>
          </div>
          <div className="h-[220px] sm:h-[250px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={goalsData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis 
                  dataKey="name" 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fontSize: 9, fontWeight: 900, fill: '#94a3b8' }}
                />
                <YAxis 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fontSize: 9, fontWeight: 900, fill: '#94a3b8' }}
                />
                <Tooltip 
                  cursor={{ fill: '#f8fafc' }}
                  contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)' }}
                />
                <Bar dataKey="goals" fill="#3b82f6" radius={[6, 6, 0, 0]} barSize={28} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 sm:gap-8">
        {/* Top Scorers */}
        <div className="bg-white p-4 xs:p-6 sm:p-8 rounded-2xl sm:rounded-[2.5rem] border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between mb-4 sm:mb-8">
            <h3 className="text-base sm:text-lg font-black text-slate-900 tracking-tight flex items-center gap-2">
              <Award className="w-5 h-5 text-amber-500" /> Top Scorers
            </h3>
          </div>
          <div className="space-y-3 sm:space-y-4">
            {stats.topScorers.length === 0 ? (
              <div className="py-10 text-center text-slate-400 italic text-sm">No goals recorded yet</div>
            ) : stats.topScorers.map((player, idx) => (
              <div key={player.name} className="flex items-center justify-between p-3 sm:p-4 bg-slate-50 rounded-2xl border border-slate-100 group hover:border-blue-200 transition-all">
                <div className="flex items-center gap-3 sm:gap-4">
                  <div className="relative">
                    <img src={player.avatar} className="w-8 h-8 sm:w-10 sm:h-10 rounded-xl object-cover" alt="" />
                    <div className="absolute -top-1.5 -left-1.5 bg-slate-900 text-white w-4 h-4 sm:w-5 sm:h-5 rounded-md sm:rounded-lg flex items-center justify-center text-[8px] sm:text-[10px] font-black">
                      {idx + 1}
                    </div>
                  </div>
                  <span className="font-black text-slate-900 text-xs sm:text-sm">{player.name}</span>
                </div>
                <div className="flex items-center gap-1.5 sm:gap-2">
                  <span className="text-xl sm:text-2xl font-black text-blue-600">{player.goals}</span>
                  <span className="text-[8px] sm:text-[10px] font-black text-slate-400 uppercase tracking-widest">Goals</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Top Assists */}
        <div className="bg-white p-4 xs:p-6 sm:p-8 rounded-2xl sm:rounded-[2.5rem] border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between mb-4 sm:mb-8">
            <h3 className="text-base sm:text-lg font-black text-slate-900 tracking-tight flex items-center gap-2">
              <Target className="w-5 h-5 text-emerald-500" /> Top Assists
            </h3>
          </div>
          <div className="space-y-3 sm:space-y-4">
            {stats.topAssists.length === 0 ? (
              <div className="py-10 text-center text-slate-400 italic text-sm">No assists recorded yet</div>
            ) : stats.topAssists.map((player, idx) => (
              <div key={player.name} className="flex items-center justify-between p-3 sm:p-4 bg-slate-50 rounded-2xl border border-slate-100 group hover:border-emerald-200 transition-all">
                <div className="flex items-center gap-3 sm:gap-4">
                  <div className="relative">
                    <img src={player.avatar} className="w-8 h-8 sm:w-10 sm:h-10 rounded-xl object-cover" alt="" />
                    <div className="absolute -top-1.5 -left-1.5 bg-slate-900 text-white w-4 h-4 sm:w-5 sm:h-5 rounded-md sm:rounded-lg flex items-center justify-center text-[8px] sm:text-[10px] font-black">
                      {idx + 1}
                    </div>
                  </div>
                  <span className="font-black text-slate-900 text-xs sm:text-sm">{player.name}</span>
                </div>
                <div className="flex items-center gap-1.5 sm:gap-2">
                  <span className="text-xl sm:text-2xl font-black text-emerald-600">{player.assists}</span>
                  <span className="text-[8px] sm:text-[10px] font-black text-slate-400 uppercase tracking-widest">Assists</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Appearances */}
        <div className="bg-white p-4 xs:p-6 sm:p-8 rounded-2xl sm:rounded-[2.5rem] border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between mb-4 sm:mb-8">
            <h3 className="text-base sm:text-lg font-black text-slate-900 tracking-tight flex items-center gap-2">
              <Calendar className="w-5 h-5 text-indigo-500" /> Most Appearances
            </h3>
          </div>
          <div className="space-y-3 sm:space-y-4">
            {stats.topApps.length === 0 ? (
              <div className="py-10 text-center text-slate-400 italic text-sm">No match data available</div>
            ) : stats.topApps.map((player, idx) => (
              <div key={player.name} className="flex items-center justify-between p-3 sm:p-4 bg-slate-50 rounded-2xl border border-slate-100 group hover:border-indigo-200 transition-all">
                <div className="flex items-center gap-3 sm:gap-4">
                  <div className="relative">
                    <img src={player.avatar} className="w-8 h-8 sm:w-10 sm:h-10 rounded-xl object-cover" alt="" />
                    <div className="absolute -top-1.5 -left-1.5 bg-slate-900 text-white w-4 h-4 sm:w-5 sm:h-5 rounded-md sm:rounded-lg flex items-center justify-center text-[8px] sm:text-[10px] font-black">
                      {idx + 1}
                    </div>
                  </div>
                  <span className="font-black text-slate-900 text-xs sm:text-sm">{player.name}</span>
                </div>
                <div className="flex items-center gap-1.5 sm:gap-2">
                  <span className="text-xl sm:text-2xl font-black text-indigo-600">{player.apps}</span>
                  <span className="text-[8px] sm:text-[10px] font-black text-slate-400 uppercase tracking-widest">Games</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Minutes Played */}
        <div className="bg-white p-4 xs:p-6 sm:p-8 rounded-2xl sm:rounded-[2.5rem] border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between mb-4 sm:mb-8">
            <h3 className="text-base sm:text-lg font-black text-slate-900 tracking-tight flex items-center gap-2">
              <Clock className="w-5 h-5 text-rose-500" /> Minutes Played
            </h3>
          </div>
          <div className="space-y-3 sm:space-y-4">
            {stats.topMinutes.length === 0 ? (
              <div className="py-10 text-center text-slate-400 italic text-sm">No minutes recorded yet</div>
            ) : stats.topMinutes.map((player, idx) => (
              <div key={player.name} className="flex items-center justify-between p-3 sm:p-4 bg-slate-50 rounded-2xl border border-slate-100 group hover:border-rose-200 transition-all">
                <div className="flex items-center gap-3 sm:gap-4">
                  <div className="relative">
                    <img src={player.avatar} className="w-8 h-8 sm:w-10 sm:h-10 rounded-xl object-cover" alt="" />
                    <div className="absolute -top-1.5 -left-1.5 bg-slate-900 text-white w-4 h-4 sm:w-5 sm:h-5 rounded-md sm:rounded-lg flex items-center justify-center text-[8px] sm:text-[10px] font-black">
                      {idx + 1}
                    </div>
                  </div>
                  <span className="font-black text-slate-900 text-xs sm:text-sm">{player.name}</span>
                </div>
                <div className="flex items-center gap-1.5 sm:gap-2">
                  <span className="text-xl sm:text-2xl font-black text-rose-600">{player.minutesPlayed}</span>
                  <span className="text-[8px] sm:text-[10px] font-black text-slate-400 uppercase tracking-widest">Mins</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Discipline */}
        <div className="bg-white p-4 xs:p-6 sm:p-8 rounded-2xl sm:rounded-[2.5rem] border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between mb-4 sm:mb-8">
            <h3 className="text-base sm:text-lg font-black text-slate-900 tracking-tight flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-amber-500" /> Discipline
            </h3>
          </div>
          <div className="space-y-3 sm:space-y-4">
            {stats.topCards.length === 0 ? (
              <div className="py-10 text-center text-slate-400 italic text-sm">Clean sheet! No cards recorded</div>
            ) : stats.topCards.map((player, idx) => (
              <div key={player.name} className="flex items-center justify-between p-3 sm:p-4 bg-slate-50 rounded-2xl border border-slate-100 group hover:border-amber-200 transition-all">
                <div className="flex items-center gap-3 sm:gap-4">
                  <div className="relative">
                    <img src={player.avatar} className="w-8 h-8 sm:w-10 sm:h-10 rounded-xl object-cover" alt="" />
                    <div className="absolute -top-1.5 -left-1.5 bg-slate-900 text-white w-4 h-4 sm:w-5 sm:h-5 rounded-md sm:rounded-lg flex items-center justify-center text-[8px] sm:text-[10px] font-black">
                      {idx + 1}
                    </div>
                  </div>
                  <span className="font-black text-slate-900 text-xs sm:text-sm">{player.name}</span>
                </div>
                <div className="flex items-center gap-3 sm:gap-4">
                  <div className="flex items-center gap-1">
                    <div className="w-2.5 h-3.5 bg-amber-400 rounded-sm shadow-sm"></div>
                    <span className="text-base sm:text-lg font-black text-slate-900">{player.yellowCards}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <div className="w-2.5 h-3.5 bg-red-500 rounded-sm shadow-sm"></div>
                    <span className="text-base sm:text-lg font-black text-slate-900">{player.redCards}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Player of the Match */}
        <div className="bg-white p-4 xs:p-6 sm:p-8 rounded-2xl sm:rounded-[2.5rem] border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between mb-4 sm:mb-8">
            <h3 className="text-base sm:text-lg font-black text-slate-900 tracking-tight flex items-center gap-2">
              <Trophy className="w-5 h-5 text-emerald-500" /> Player of the Match
            </h3>
          </div>
          <div className="space-y-3 sm:space-y-4">
            {stats.topPotm.length === 0 ? (
              <div className="py-10 text-center text-slate-400 italic text-sm">No POTM awards yet</div>
            ) : stats.topPotm.map((player, idx) => (
              <div key={player.name} className="flex items-center justify-between p-3 sm:p-4 bg-slate-50 rounded-2xl border border-slate-100 group hover:border-emerald-200 transition-all">
                <div className="flex items-center gap-3 sm:gap-4">
                  <div className="relative">
                    <img src={player.avatar} className="w-8 h-8 sm:w-10 sm:h-10 rounded-xl object-cover" alt="" />
                    <div className="absolute -top-1.5 -left-1.5 bg-slate-900 text-white w-4 h-4 sm:w-5 sm:h-5 rounded-md sm:rounded-lg flex items-center justify-center text-[8px] sm:text-[10px] font-black">
                      {idx + 1}
                    </div>
                  </div>
                  <span className="font-black text-slate-900 text-xs sm:text-sm">{player.name}</span>
                </div>
                <div className="flex items-center gap-1.5 sm:gap-2">
                  <span className="text-xl sm:text-2xl font-black text-emerald-600">{player.potmWins}</span>
                  <span className="text-[8px] sm:text-[10px] font-black text-slate-400 uppercase tracking-widest">Wins</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Social Funny Stats */}
        {club.type === 'SOCIAL' && (
          <>
            <div className="bg-white p-4 xs:p-6 sm:p-8 rounded-2xl sm:rounded-[2.5rem] border border-slate-200 shadow-sm">
              <div className="flex items-center justify-between mb-4 sm:mb-8">
                <h3 className="text-base sm:text-lg font-black text-slate-900 tracking-tight flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-orange-500" /> Balls Over Fence
                </h3>
              </div>
              <div className="space-y-3 sm:space-y-4">
                {stats.topBallsOverFence.length === 0 ? (
                  <div className="py-10 text-center text-slate-400 italic text-sm">No balls lost yet!</div>
                ) : stats.topBallsOverFence.map((player, idx) => (
                  <div key={player.name} className="flex items-center justify-between p-3 sm:p-4 bg-slate-50 rounded-2xl border border-slate-100 group hover:border-orange-200 transition-all">
                    <div className="flex items-center gap-3 sm:gap-4">
                      <div className="relative">
                        <img src={player.avatar} className="w-8 h-8 sm:w-10 sm:h-10 rounded-xl object-cover" alt="" />
                        <div className="absolute -top-1.5 -left-1.5 bg-slate-900 text-white w-4 h-4 sm:w-5 sm:h-5 rounded-md sm:rounded-lg flex items-center justify-center text-[8px] sm:text-[10px] font-black">
                          {idx + 1}
                        </div>
                      </div>
                      <span className="font-black text-slate-900 text-xs sm:text-sm">{player.name}</span>
                    </div>
                    <div className="flex items-center gap-1.5 sm:gap-2">
                      <span className="text-2xl font-black text-orange-600">{player.ballsOverFence}</span>
                      <span className="text-[8px] sm:text-[10px] font-black text-slate-400 uppercase tracking-widest">Balls</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-white p-4 xs:p-6 sm:p-8 rounded-2xl sm:rounded-[2.5rem] border border-slate-200 shadow-sm">
              <div className="flex items-center justify-between mb-4 sm:mb-8">
                <h3 className="text-base sm:text-lg font-black text-slate-900 tracking-tight flex items-center gap-2">
                  <AlertOctagon className="w-5 h-5 text-rose-500" /> Most Injury Prone
                </h3>
              </div>
              <div className="space-y-3 sm:space-y-4">
                {stats.topInjured.length === 0 ? (
                  <div className="py-10 text-center text-slate-400 italic text-sm">Everyone is healthy!</div>
                ) : stats.topInjured.map((player, idx) => (
                  <div key={player.name} className="flex items-center justify-between p-3 sm:p-4 bg-slate-50 rounded-2xl border border-slate-100 group hover:border-rose-200 transition-all">
                    <div className="flex items-center gap-3 sm:gap-4">
                      <div className="relative">
                        <img src={player.avatar} className="w-8 h-8 sm:w-10 sm:h-10 rounded-xl object-cover" alt="" />
                        <div className="absolute -top-1.5 -left-1.5 bg-slate-900 text-white w-4 h-4 sm:w-5 sm:h-5 rounded-md sm:rounded-lg flex items-center justify-center text-[8px] sm:text-[10px] font-black">
                          {idx + 1}
                        </div>
                      </div>
                      <span className="font-black text-slate-900 text-xs sm:text-sm">{player.name}</span>
                    </div>
                    <div className="flex items-center gap-1.5 sm:gap-2">
                      <span className="text-2xl font-black text-rose-600">{player.isInjured}</span>
                      <span className="text-[8px] sm:text-[10px] font-black text-slate-400 uppercase tracking-widest">Injuries</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-white p-4 xs:p-6 sm:p-8 rounded-2xl sm:rounded-[2.5rem] border border-slate-200 shadow-sm">
              <div className="flex items-center justify-between mb-4 sm:mb-8">
                <h3 className="text-base sm:text-lg font-black text-slate-900 tracking-tight flex items-center gap-2">
                  <X className="w-5 h-5 text-slate-500" /> Last Minute Dropouts
                </h3>
              </div>
              <div className="space-y-3 sm:space-y-4">
                {stats.topDropouts.length === 0 ? (
                  <div className="py-10 text-center text-slate-400 italic text-sm">Reliable squad!</div>
                ) : stats.topDropouts.map((player, idx) => (
                  <div key={player.name} className="flex items-center justify-between p-3 sm:p-4 bg-slate-50 rounded-2xl border border-slate-100 group hover:border-slate-300 transition-all">
                    <div className="flex items-center gap-3 sm:gap-4">
                      <div className="relative">
                        <img src={player.avatar} className="w-8 h-8 sm:w-10 sm:h-10 rounded-xl object-cover" alt="" />
                        <div className="absolute -top-1.5 -left-1.5 bg-slate-900 text-white w-4 h-4 sm:w-5 sm:h-5 rounded-md sm:rounded-lg flex items-center justify-center text-[8px] sm:text-[10px] font-black">
                          {idx + 1}
                        </div>
                      </div>
                      <span className="font-black text-slate-900 text-xs sm:text-sm">{player.name}</span>
                    </div>
                    <div className="flex items-center gap-1.5 sm:gap-2">
                      <span className="text-2xl font-black text-slate-600">{player.isLastMinuteDropout}</span>
                      <span className="text-[8px] sm:text-[10px] font-black text-slate-400 uppercase tracking-widest">Times</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-white p-4 xs:p-6 sm:p-8 rounded-2xl sm:rounded-[2.5rem] border border-slate-200 shadow-sm">
              <div className="flex items-center justify-between mb-4 sm:mb-8">
                <h3 className="text-base sm:text-lg font-black text-slate-900 tracking-tight flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-emerald-500" /> Highest Win Rate
                </h3>
              </div>
              <div className="space-y-3 sm:space-y-4">
                {stats.topWinRate.length === 0 ? (
                  <div className="py-10 text-center text-slate-400 italic text-sm">Not enough data</div>
                ) : stats.topWinRate.map((player, idx) => (
                  <div key={player.name} className="flex items-center justify-between p-3 sm:p-4 bg-slate-50 rounded-2xl border border-slate-100 group hover:border-emerald-200 transition-all">
                    <div className="flex items-center gap-3 sm:gap-4">
                      <div className="relative">
                        <img src={player.avatar} className="w-8 h-8 sm:w-10 sm:h-10 rounded-xl object-cover" alt="" />
                        <div className="absolute -top-1.5 -left-1.5 bg-slate-900 text-white w-4 h-4 sm:w-5 sm:h-5 rounded-md sm:rounded-lg flex items-center justify-center text-[8px] sm:text-[10px] font-black">
                          {idx + 1}
                        </div>
                      </div>
                      <span className="font-black text-slate-900 text-xs sm:text-sm">{player.name}</span>
                    </div>
                    <div className="flex items-center gap-1.5 sm:gap-2">
                      <span className="text-2xl font-black text-emerald-600">
                        {Math.round((player.wins / (player.wins + player.losses + player.draws || 1)) * 100)}%
                      </span>
                      <span className="text-[8px] sm:text-[10px] font-black text-slate-400 uppercase tracking-widest">Win Rate</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </>
        )}
      </div>
      {showMemoryBook && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-2 xs:p-4">
          <div className="bg-slate-50 rounded-2xl sm:rounded-[3rem] w-full max-w-5xl max-h-[95vh] sm:max-h-[90vh] overflow-hidden flex flex-col shadow-2xl">
            <div className="p-4 xs:p-6 sm:p-8 border-b border-slate-200 flex items-center justify-between bg-white">
              <div className="flex items-center gap-3 sm:gap-4 min-w-0">
                <div className="p-2 sm:p-3 bg-blue-100 text-blue-600 rounded-xl sm:rounded-2xl shrink-0">
                  <BookOpen className="w-5 h-5 sm:w-6 sm:h-6" />
                </div>
                <div className="min-w-0">
                  <h3 className="text-lg xs:text-xl sm:text-2xl font-black text-slate-900 tracking-tight truncate">Season Memory Book</h3>
                  <p className="text-[10px] xs:text-sm text-slate-500 font-medium mt-0.5 truncate">{club.name} • Capturing the moments</p>
                </div>
              </div>
              <button onClick={() => setShowMemoryBook(false)} className="p-1.5 hover:bg-slate-100 rounded-lg sm:rounded-xl transition-all shrink-0">
                <X className="w-5 h-5 xs:w-6 xs:h-6 text-slate-400" />
              </button>
            </div>
            
            <div className="flex-1 overflow-y-auto p-4 xs:p-6 sm:p-8 space-y-8 sm:space-y-12">
              {stats.memoryBook.length === 0 ? (
                <div className="py-20 text-center">
                  <div className="bg-slate-100 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6">
                    <Camera className="w-8 h-8 text-slate-300" />
                  </div>
                  <h4 className="text-xl font-black text-slate-900">No memories yet</h4>
                  <p className="text-sm text-slate-500 font-medium mt-2">Start uploading photos to match feeds to build your memory book!</p>
                </div>
              ) : (
                stats.memoryBook.map((matchMem, idx) => (
                  <div key={matchMem.matchId} className="space-y-6">
                    <div className="flex items-center gap-4">
                      <div className="h-px flex-1 bg-slate-200"></div>
                      <div className="text-center">
                        <h4 className="text-base sm:text-lg font-black text-slate-900 tracking-tight">{matchMem.title}</h4>
                        <p className="text-[9px] sm:text-[10px] font-black text-slate-400 uppercase tracking-widest">{new Date(matchMem.date).toLocaleDateString(undefined, { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</p>
                      </div>
                      <div className="h-px flex-1 bg-slate-200"></div>
                    </div>
 
                    {matchMem.summary && (
                      <div className="max-w-3xl mx-auto bg-white p-5 sm:p-8 rounded-2xl sm:rounded-[2.5rem] border border-slate-200 shadow-sm relative italic text-slate-600 leading-relaxed text-sm">
                        <div className="absolute -top-3 left-6 bg-blue-600 text-white px-3 py-0.5 rounded-full text-[8px] sm:text-[9px] font-black uppercase tracking-widest">Manager's Note</div>
                        "{matchMem.summary}"
                      </div>
                    )}
 
                    {matchMem.photos.length > 0 && (
                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
                        {matchMem.photos.map((photo, pIdx) => (
                          <div key={pIdx} className="bg-white p-2 sm:p-3 rounded-2xl sm:rounded-[2rem] border border-slate-200 shadow-sm hover:shadow-md transition-all group">
                            <div className="aspect-square rounded-xl sm:rounded-2xl overflow-hidden mb-3 relative">
                              <img 
                                src={photo.url} 
                                alt={photo.caption} 
                                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                                referrerPolicy="no-referrer"
                              />
                              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-4">
                                <p className="text-white text-[10px] font-medium leading-tight">{photo.caption}</p>
                              </div>
                            </div>
                            <div className="flex items-center justify-between px-1 sm:px-2">
                              <p className="text-[8px] sm:text-[9px] font-black text-slate-400 uppercase tracking-widest">By {photo.userName}</p>
                              <p className="text-[8px] sm:text-[9px] font-black text-slate-300 tabular-nums">{new Date(photo.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                ))
              )}
            </div>
 
            <div className="p-4 xs:p-6 sm:p-8 bg-white border-t border-slate-200 flex flex-col sm:flex-row gap-4 justify-between items-center">
              <p className="text-[9px] sm:text-[10px] font-black text-slate-400 uppercase tracking-widest text-center sm:text-left">
                {stats.memoryBook.reduce((acc, m) => acc + m.photos.length, 0)} Photos Captured this season
              </p>
              <button 
                onClick={() => window.print()}
                className="w-full sm:w-auto flex items-center justify-center gap-2 bg-slate-900 text-white px-6 py-3 sm:px-8 sm:py-4 rounded-xl sm:rounded-2xl font-black text-[9px] sm:text-[10px] uppercase tracking-widest hover:bg-slate-800 transition-all shadow-xl shadow-slate-200"
              >
                <Download className="w-4 h-4" />
                Print Memory Book
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default StatsDashboard;

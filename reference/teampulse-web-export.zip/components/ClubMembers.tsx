
import React, { useState, useRef } from 'react';
import { User, UserRole, Club } from '../types';
import { Shield, User as UserIcon, Eye, Trash2, ArrowLeft, Star, ToggleLeft, ToggleRight, Plus, X, Check, Camera, RefreshCw, AlertTriangle, Loader2, Edit } from 'lucide-react';

interface ClubMembersProps {
  club: Club;
  currentUser: User;
  onUpdateRoles: (userId: string, newRoles: UserRole[]) => void;
  onRemoveMember: (userId: string) => void;
  onAddMember: (name: string, roles: UserRole[], avatar: string, age?: string, gender?: string, favPosition?: string, kitSize?: string) => void;
  onUpdateMember?: (updatedMember: User) => Promise<void>;
  onDeleteClub?: (clubId: string) => void;
  onEditClub?: (clubId: string) => void;
  onBack: () => void;
}

const ClubMembers: React.FC<ClubMembersProps> = ({ club, currentUser, onUpdateRoles, onRemoveMember, onAddMember, onUpdateMember, onDeleteClub, onEditClub, onBack }) => {
  const [isAddingMember, setIsAddingMember] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [newName, setNewName] = useState('');
  const [newRole, setNewRole] = useState<'PLAYER' | 'MANAGER' | 'SPECTATOR'>('PLAYER');
  const [newAvatar, setNewAvatar] = useState(`https://picsum.photos/seed/${Math.random()}/200/200`);
  
  // New member extra attributes
  const [newAge, setNewAge] = useState('');
  const [newGender, setNewGender] = useState('');
  const [newFavPosition, setNewFavPosition] = useState('');
  const [newKitSize, setNewKitSize] = useState('');

  // Editing state
  const [editingMember, setEditingMember] = useState<User | null>(null);
  const [editName, setEditName] = useState('');
  const [editAvatar, setEditAvatar] = useState('');
  const [editAge, setEditAge] = useState('');
  const [editGender, setEditGender] = useState('');
  const [editFavPosition, setEditFavPosition] = useState('');
  const [editKitSize, setEditKitSize] = useState('');
  const [isSavingEdit, setIsSavingEdit] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const editFileInputRef = useRef<HTMLInputElement>(null);

  const isCurrentUserAdmin = club.members.find(m => m.id === currentUser.id)?.roles.includes('ADMIN');
  const isOwner = currentUser.id === club.ownerId;
  const isTeam = club.type === 'TEAM';

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim()) return;
    
    // Map local UI role to actual roles
    const roles: UserRole[] = newRole === 'MANAGER' ? ['ADMIN', 'SPECTATOR'] : [newRole as UserRole];
    
    onAddMember(
      newName.trim(), 
      roles, 
      newAvatar, 
      newAge.trim() || undefined, 
      newGender || undefined, 
      newFavPosition.trim() || undefined, 
      newKitSize || undefined
    );
    
    setNewName('');
    setNewAvatar(`https://picsum.photos/seed/${Math.random()}/200/200`);
    setNewAge('');
    setNewGender('');
    setNewFavPosition('');
    setNewKitSize('');
    setIsAddingMember(false);
  };

  const handleStartEditMember = (member: User) => {
    setEditingMember(member);
    setEditName(member.name);
    setEditAvatar(member.avatar);
    setEditAge(member.age || '');
    setEditGender(member.gender || '');
    setEditFavPosition(member.favPosition || '');
    setEditKitSize(member.kitSize || '');
  };

  const handleEditSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingMember || !editName.trim() || isSavingEdit) return;

    setIsSavingEdit(true);
    try {
      if (onUpdateMember) {
        await onUpdateMember({
          ...editingMember,
          name: editName.trim(),
          avatar: editAvatar,
          age: editAge.trim() || undefined,
          gender: editGender || undefined,
          favPosition: editFavPosition.trim() || undefined,
          kitSize: editKitSize || undefined
        });
      }
      setEditingMember(null);
    } catch (err) {
      console.error("Failed to edit member profile:", err);
    } finally {
      setIsSavingEdit(false);
    }
  };

  const handleEditFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setEditAvatar(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const shuffleEditAvatar = () => {
    setEditAvatar(`https://picsum.photos/seed/${Math.random()}/200/200`);
  };

  const handleConfirmDelete = async () => {
    if (!onDeleteClub || isDeleting) return;
    setIsDeleting(true);
    await onDeleteClub(club.id);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setNewAvatar(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const shuffleAvatar = () => {
    setNewAvatar(`https://picsum.photos/seed/${Math.random()}/200/200`);
  };

  const getRoleIcon = (role: UserRole) => {
    switch (role) {
      case 'ADMIN': return <Shield className="w-4 h-4 text-blue-600" />;
      case 'PLAYER': return <UserIcon className="w-4 h-4 text-green-600" />;
      case 'SPECTATOR': return <Eye className="w-4 h-4 text-slate-400" />;
    }
  };

  const getRoleBadgeColor = (role: UserRole) => {
    switch (role) {
      case 'ADMIN': return 'bg-blue-50 text-blue-700 border-blue-100';
      case 'PLAYER': return 'bg-green-50 text-green-700 border-green-100';
      case 'SPECTATOR': return 'bg-slate-50 text-slate-600 border-slate-100';
    }
  };

  const handleToggleAdmin = (member: User) => {
    if (!isCurrentUserAdmin) return;
    const hasAdmin = member.roles.includes('ADMIN');
    const newRoles = hasAdmin 
      ? member.roles.filter(r => r !== 'ADMIN')
      : [...member.roles, 'ADMIN' as UserRole];
    onUpdateRoles(member.id, newRoles);
  };

  const handleSetBaseRole = (member: User, baseRole: 'PLAYER' | 'SPECTATOR') => {
    if (!isCurrentUserAdmin && member.id !== currentUser.id) return;
    const otherRoles = member.roles.filter(r => r !== 'PLAYER' && r !== 'SPECTATOR');
    onUpdateRoles(member.id, [...otherRoles, baseRole]);
  };

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-left-4 duration-500 pb-20">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <button 
            onClick={onBack}
            className="p-2 hover:bg-slate-200 rounded-full transition-colors bg-white border border-slate-200 shadow-sm"
          >
            <ArrowLeft className="w-5 h-5 text-slate-600" />
          </button>
          <div className="flex items-center gap-4">
            <img src={club.logo} className="w-12 h-12 rounded-xl object-cover shadow-sm border border-slate-200" alt="" />
            <div>
              <h2 className="text-2xl font-black text-slate-900 tracking-tight">
                {club.name}
              </h2>
              <div className="flex flex-wrap items-center gap-2 text-sm text-slate-500 font-medium">
                <span>{isTeam ? 'Team Roster' : 'Mates List'} • Invite Code: <span className="font-bold text-blue-600 select-all">{club.inviteCode}</span></span>
                {club.ageGroup && (
                  <span className="bg-slate-100 text-slate-700 px-2 py-0.5 rounded-lg text-[9px] font-black uppercase tracking-wider border border-slate-200">
                    {club.ageGroup}
                  </span>
                )}
                {club.gender && (
                  <span className="bg-slate-100 text-slate-700 px-2 py-0.5 rounded-lg text-[9px] font-black uppercase tracking-wider border border-slate-200">
                    {club.gender}
                  </span>
                )}
              </div>
            </div>
          </div>
        </div>

        <div className="flex flex-wrap gap-2">
          {isCurrentUserAdmin && onEditClub && (
            <button 
              onClick={() => onEditClub(club.id)}
              className="bg-white border border-slate-200 text-slate-700 px-5 py-2.5 rounded-xl font-black text-xs uppercase tracking-widest flex items-center gap-2 hover:bg-slate-50 transition-all shadow-sm"
            >
              <Edit className="w-4 h-4 text-slate-500" />
              Edit Club
            </button>
          )}
          {isOwner && (
            <button 
              onClick={() => setShowDeleteConfirm(true)}
              className="bg-white border border-red-100 text-red-500 px-5 py-2.5 rounded-xl font-black text-xs uppercase tracking-widest flex items-center gap-2 hover:bg-red-50 transition-all shadow-sm"
            >
              <Trash2 className="w-4 h-4" />
              Delete
            </button>
          )}
          {isCurrentUserAdmin && (
            <button 
              onClick={() => setIsAddingMember(true)}
              className="bg-blue-600 text-white px-5 py-2.5 rounded-xl font-black text-xs uppercase tracking-widest flex items-center gap-2 shadow-lg shadow-blue-100 hover:bg-blue-700 transition-all"
            >
              <Plus className="w-4 h-4" />
              Add Member
            </button>
          )}
        </div>
      </div>

      {club.teamPhoto && (
        <div className="bg-white rounded-[2rem] border border-slate-200 shadow-sm overflow-hidden p-4">
          <div className="relative aspect-[21/9] w-full rounded-2xl overflow-hidden group shadow-inner">
            <img 
              src={club.teamPhoto} 
              className="w-full h-full object-cover" 
              alt="Team Banner" 
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 via-slate-900/20 to-transparent flex items-end p-6">
              <div>
                <h4 className="text-white font-black text-lg md:text-xl tracking-tight">Official Team Photo</h4>
                <p className="text-white/90 text-xs font-black uppercase tracking-wider mt-1 flex items-center gap-2">
                  <span>{club.name}</span>
                  {club.ageGroup && (
                    <>
                      <span className="opacity-50">•</span>
                      <span>{club.ageGroup}</span>
                    </>
                  )}
                  {club.gender && (
                    <>
                      <span className="opacity-50">•</span>
                      <span>{club.gender}</span>
                    </>
                  )}
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      <div className="bg-white rounded-[2rem] border border-slate-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-100">
                <th className="px-6 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest">
                  {isTeam ? 'Athlete' : 'Member'}
                </th>
                <th className="px-6 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest">Roles</th>
                <th className="px-6 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest">Access</th>
                <th className="px-6 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {club.members.map((member) => (
                <tr key={member.id} className="hover:bg-slate-50/50 transition-colors">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div className="relative">
                        <img src={member.avatar} className="w-12 h-12 rounded-2xl object-cover border-2 border-white shadow-sm" alt={member.name} />
                        {member.id === club.ownerId && (
                          <div className="absolute -top-1 -right-1 bg-amber-400 text-white p-1 rounded-lg ring-2 ring-white shadow-sm">
                            <Star className="w-3 h-3 fill-current" />
                          </div>
                        )}
                      </div>
                      <div>
                        <p className="font-black text-slate-900 tracking-tight">{member.name}</p>
                        <p className="text-[9px] text-slate-400 font-black uppercase tracking-widest">{member.id === club.ownerId ? (isTeam ? 'Manager' : 'Organizer') : 'Active Member'}</p>
                        
                        {(member.age || member.gender || member.favPosition || member.kitSize) && (
                          <div className="flex flex-wrap gap-1 mt-1.5 max-w-[200px]">
                            {member.age && (
                              <span className="bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded text-[8px] font-bold" title="Age">
                                Age: {member.age}
                              </span>
                            )}
                            {member.gender && (
                              <span className="bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded text-[8px] font-bold" title="Gender">
                                {member.gender}
                              </span>
                            )}
                            {member.favPosition && (
                              <span className="bg-blue-50 text-blue-600 px-1.5 py-0.5 rounded text-[8px] font-bold border border-blue-100" title="Favorite Position">
                                Pos: {member.favPosition}
                              </span>
                            )}
                            {member.kitSize && (
                              <span className="bg-emerald-50 text-emerald-600 px-1.5 py-0.5 rounded text-[8px] font-bold border border-emerald-100" title="Kit Size">
                                Kit: {member.kitSize}
                              </span>
                            )}
                          </div>
                        )}
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex flex-wrap gap-2">
                      {member.roles.map(role => (
                        <span key={role} className={`px-3 py-1 rounded-lg text-[9px] font-black uppercase tracking-widest border ${getRoleBadgeColor(role)} flex items-center gap-1.5`}>
                          {getRoleIcon(role)}
                          {role}
                        </span>
                      ))}
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    {isCurrentUserAdmin && member.id !== club.ownerId ? (
                      <button 
                        onClick={() => handleToggleAdmin(member)}
                        className={`flex items-center gap-2 px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all border ${
                          member.roles.includes('ADMIN') 
                            ? 'bg-blue-600 text-white border-blue-700 shadow-lg shadow-blue-100' 
                            : 'bg-white text-slate-400 border-slate-200 hover:border-blue-200 hover:text-blue-600'
                        }`}
                      >
                        {member.roles.includes('ADMIN') ? <ToggleRight className="w-4 h-4" /> : <ToggleLeft className="w-4 h-4" />}
                        {member.roles.includes('ADMIN') ? 'Full Access' : 'Grant Admin'}
                      </button>
                    ) : (
                      <div className="flex items-center gap-1.5 text-xs font-bold text-slate-400">
                        {member.roles.includes('ADMIN') ? (
                          <span className="text-blue-600 flex items-center gap-2 bg-blue-50 px-4 py-2 rounded-xl border border-blue-100 text-[10px] font-black uppercase tracking-widest">
                            <Shield className="w-3.5 h-3.5" />
                            Hub Admin
                          </span>
                        ) : (
                          <span className="px-4 py-2 text-[10px] font-black uppercase tracking-widest opacity-50">Standard User</span>
                        )}
                      </div>
                    )}
                  </td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex justify-end items-center gap-3">
                      {(isCurrentUserAdmin || member.id === currentUser.id) && (
                        <>
                          <button 
                            onClick={() => handleStartEditMember(member)}
                            className="p-2.5 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-xl transition-all border border-transparent hover:border-blue-100"
                            title="Edit Player Details"
                          >
                            <Edit className="w-4.5 h-4.5" />
                          </button>
                          <div className="relative">
                            <select 
                              className="appearance-none bg-slate-50 border border-slate-200 rounded-xl text-[10px] font-black uppercase tracking-widest pl-4 pr-10 py-2.5 outline-none focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 transition-all cursor-pointer"
                              value={member.roles.includes('PLAYER') ? 'PLAYER' : 'SPECTATOR'}
                              onChange={(e) => handleSetBaseRole(member, e.target.value as 'PLAYER' | 'SPECTATOR')}
                            >
                              <option value="PLAYER">{isTeam ? 'PLAYER' : 'BALLER'}</option>
                              <option value="SPECTATOR">WATCHER</option>
                            </select>
                            <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400">
                              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path></svg>
                            </div>
                          </div>
                          {isCurrentUserAdmin && member.id !== club.ownerId && member.id !== currentUser.id && (
                            <button 
                              onClick={() => onRemoveMember(member.id)}
                              className="p-3 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-xl transition-all border border-transparent hover:border-red-100"
                              title="Remove Member"
                            >
                              <Trash2 className="w-5 h-5" />
                            </button>
                          )}
                        </>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Member Modal */}
      {isAddingMember && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-300">
          <div className="bg-white rounded-[2rem] shadow-2xl w-full max-w-md overflow-hidden animate-in zoom-in-95 duration-300">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between">
              <h3 className="text-xl font-bold text-slate-900">Add New Member</h3>
              <button onClick={() => setIsAddingMember(false)} className="p-2 hover:bg-slate-100 rounded-full transition-colors text-slate-400">
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <form onSubmit={handleAddSubmit} className="p-6 space-y-4 max-h-[85vh] overflow-y-auto">
              <div className="flex flex-col items-center gap-2">
                <div className="relative group cursor-pointer" onClick={() => fileInputRef.current?.click()}>
                  <img 
                    src={newAvatar} 
                    className="w-20 h-20 rounded-full object-cover ring-4 ring-slate-50 shadow-md transition-transform group-hover:scale-105" 
                    alt="Avatar Preview" 
                  />
                  <div className="absolute inset-0 bg-black/40 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <Camera className="w-5 h-5 text-white" />
                  </div>
                  <input 
                    type="file" 
                    ref={fileInputRef} 
                    className="hidden" 
                    accept="image/*" 
                    onChange={handleFileChange} 
                  />
                </div>
                <button 
                  type="button" 
                  onClick={shuffleAvatar}
                  className="flex items-center gap-1.5 text-[10px] font-black text-blue-600 uppercase tracking-widest"
                >
                  <RefreshCw className="w-3 h-3" /> Shuffle Avatar
                </button>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">Full Name</label>
                <input 
                  autoFocus
                  type="text" 
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  placeholder="e.g. John Doe"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 font-semibold text-slate-900 focus:outline-none focus:border-blue-500 transition-all text-sm"
                  required
                />
              </div>

              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">Base Role</label>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => setNewRole('PLAYER')}
                    className={`flex flex-col items-center gap-1.5 p-2.5 rounded-xl border-2 transition-all ${
                      newRole === 'PLAYER' 
                        ? 'border-green-600 bg-green-50 text-green-600' 
                        : 'border-slate-100 bg-white text-slate-400 grayscale hover:grayscale-0 hover:border-slate-200'
                    }`}
                  >
                    <UserIcon className="w-4 h-4" />
                    <span className="text-[8px] font-black uppercase tracking-widest">Player</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setNewRole('MANAGER')}
                    className={`flex flex-col items-center gap-1.5 p-2.5 rounded-xl border-2 transition-all ${
                      newRole === 'MANAGER' 
                        ? 'border-blue-600 bg-blue-50 text-blue-600' 
                        : 'border-slate-100 bg-white text-slate-400 grayscale hover:grayscale-0 hover:border-slate-200'
                    }`}
                  >
                    <Shield className="w-4 h-4" />
                    <span className="text-[8px] font-black uppercase tracking-widest">Manager</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setNewRole('SPECTATOR')}
                    className={`flex flex-col items-center gap-1.5 p-2.5 rounded-xl border-2 transition-all ${
                      newRole === 'SPECTATOR' 
                        ? 'border-amber-600 bg-amber-50 text-amber-600' 
                        : 'border-slate-100 bg-white text-slate-400 grayscale hover:grayscale-0 hover:border-slate-200'
                    }`}
                  >
                    <Eye className="w-4 h-4" />
                    <span className="text-[8px] font-black uppercase tracking-widest">Watcher</span>
                  </button>
                </div>
              </div>

              {/* Player Attributes Grid */}
              <div className="grid grid-cols-2 gap-4 border-t border-slate-100 pt-4">
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Age / Group</label>
                  <input 
                    type="text" 
                    value={newAge}
                    onChange={(e) => setNewAge(e.target.value)}
                    placeholder="e.g. 12 or U13"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 font-semibold text-slate-900 focus:outline-none focus:border-blue-500 transition-all text-sm"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Gender</label>
                  <select
                    value={newGender}
                    onChange={(e) => setNewGender(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 font-semibold text-slate-900 focus:outline-none focus:border-blue-500 transition-all text-sm cursor-pointer"
                  >
                    <option value="">Select Gender...</option>
                    <option value="Boys">Boys</option>
                    <option value="Girls">Girls</option>
                    <option value="Mixed">Mixed</option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Other">Other</option>
                  </select>
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Fav Position</label>
                  <select
                    value={newFavPosition}
                    onChange={(e) => setNewFavPosition(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 font-semibold text-slate-900 focus:outline-none focus:border-blue-500 transition-all text-sm cursor-pointer"
                  >
                    <option value="">Select Position...</option>
                    <optgroup label="Goalkeeper">
                      <option value="GK">GK (Goalkeeper)</option>
                    </optgroup>
                    <optgroup label="Defenders">
                      <option value="CB">CB (Center Back)</option>
                      <option value="LB">LB (Left Back)</option>
                      <option value="RB">RB (Right Back)</option>
                      <option value="LWB">LWB (Left Wing Back)</option>
                      <option value="RWB">RWB (Right Wing Back)</option>
                    </optgroup>
                    <optgroup label="Midfielders">
                      <option value="CDM">CDM (Defensive Mid)</option>
                      <option value="CM">CM (Central Mid)</option>
                      <option value="CAM">CAM (Attacking Mid)</option>
                      <option value="LM">LM (Left Mid)</option>
                      <option value="RM">RM (Right Mid)</option>
                    </optgroup>
                    <optgroup label="Forwards / Wingers">
                      <option value="ST">ST (Striker)</option>
                      <option value="CF">CF (Center Forward)</option>
                      <option value="LW">LW (Left Winger)</option>
                      <option value="RW">RW (Right Winger)</option>
                    </optgroup>
                  </select>
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Kit Size</label>
                  <select
                    value={newKitSize}
                    onChange={(e) => setNewKitSize(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 font-semibold text-slate-900 focus:outline-none focus:border-blue-500 transition-all text-sm cursor-pointer"
                  >
                    <option value="">Select Kit Size...</option>
                    <option value="YS">YS (Youth Small)</option>
                    <option value="YM">YM (Youth Medium)</option>
                    <option value="YL">YL (Youth Large)</option>
                    <option value="YXL">YXL (Youth XL)</option>
                    <option value="XS">XS (Adult XS)</option>
                    <option value="S">S (Adult Small)</option>
                    <option value="M">M (Adult Medium)</option>
                    <option value="L">L (Adult Large)</option>
                    <option value="XL">XL (Adult XL)</option>
                    <option value="XXL">XXL (Adult XXL)</option>
                  </select>
                </div>
              </div>

              <button 
                type="submit"
                className="w-full bg-slate-900 text-white rounded-xl py-3 font-bold shadow-lg hover:bg-slate-800 transition-all flex items-center justify-center gap-2 mt-4"
              >
                <Check className="w-5 h-5" />
                Add to Roster
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Edit Member Modal */}
      {editingMember && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-300">
          <div className="bg-white rounded-[2rem] shadow-2xl w-full max-w-md overflow-hidden animate-in zoom-in-95 duration-300">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between">
              <h3 className="text-xl font-bold text-slate-900">Edit Player Details</h3>
              <button onClick={() => setEditingMember(null)} className="p-2 hover:bg-slate-100 rounded-full transition-colors text-slate-400">
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <form onSubmit={handleEditSubmit} className="p-6 space-y-4 max-h-[85vh] overflow-y-auto">
              <div className="flex flex-col items-center gap-2">
                <div className="relative group cursor-pointer" onClick={() => editFileInputRef.current?.click()}>
                  <img 
                    src={editAvatar} 
                    className="w-20 h-20 rounded-full object-cover ring-4 ring-slate-50 shadow-md transition-transform group-hover:scale-105" 
                    alt="Avatar Preview" 
                  />
                  <div className="absolute inset-0 bg-black/40 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <Camera className="w-5 h-5 text-white" />
                  </div>
                  <input 
                    type="file" 
                    ref={editFileInputRef} 
                    className="hidden" 
                    accept="image/*" 
                    onChange={handleEditFileChange} 
                  />
                </div>
                <button 
                  type="button" 
                  onClick={shuffleEditAvatar}
                  className="flex items-center gap-1.5 text-[10px] font-black text-blue-600 uppercase tracking-widest"
                >
                  <RefreshCw className="w-3 h-3" /> Shuffle Avatar
                </button>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">Full Name</label>
                <input 
                  type="text" 
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  placeholder="e.g. John Doe"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 font-semibold text-slate-900 focus:outline-none focus:border-blue-500 transition-all text-sm"
                  required
                />
              </div>

              {/* Player Attributes Grid */}
              <div className="grid grid-cols-2 gap-4 border-t border-slate-100 pt-4">
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Age / Group</label>
                  <input 
                    type="text" 
                    value={editAge}
                    onChange={(e) => setEditAge(e.target.value)}
                    placeholder="e.g. 12 or U13"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 font-semibold text-slate-900 focus:outline-none focus:border-blue-500 transition-all text-sm"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Gender</label>
                  <select
                    value={editGender}
                    onChange={(e) => setEditGender(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 font-semibold text-slate-900 focus:outline-none focus:border-blue-500 transition-all text-sm cursor-pointer"
                  >
                    <option value="">Select Gender...</option>
                    <option value="Boys">Boys</option>
                    <option value="Girls">Girls</option>
                    <option value="Mixed">Mixed</option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Other">Other</option>
                  </select>
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Fav Position</label>
                  <select
                    value={editFavPosition}
                    onChange={(e) => setEditFavPosition(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 font-semibold text-slate-900 focus:outline-none focus:border-blue-500 transition-all text-sm cursor-pointer"
                  >
                    <option value="">Select Position...</option>
                    <optgroup label="Goalkeeper">
                      <option value="GK">GK (Goalkeeper)</option>
                    </optgroup>
                    <optgroup label="Defenders">
                      <option value="CB">CB (Center Back)</option>
                      <option value="LB">LB (Left Back)</option>
                      <option value="RB">RB (Right Back)</option>
                      <option value="LWB">LWB (Left Wing Back)</option>
                      <option value="RWB">RWB (Right Wing Back)</option>
                    </optgroup>
                    <optgroup label="Midfielders">
                      <option value="CDM">CDM (Defensive Mid)</option>
                      <option value="CM">CM (Central Mid)</option>
                      <option value="CAM">CAM (Attacking Mid)</option>
                      <option value="LM">LM (Left Mid)</option>
                      <option value="RM">RM (Right Mid)</option>
                    </optgroup>
                    <optgroup label="Forwards / Wingers">
                      <option value="ST">ST (Striker)</option>
                      <option value="CF">CF (Center Forward)</option>
                      <option value="LW">LW (Left Winger)</option>
                      <option value="RW">RW (Right Winger)</option>
                    </optgroup>
                  </select>
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Kit Size</label>
                  <select
                    value={editKitSize}
                    onChange={(e) => setEditKitSize(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 font-semibold text-slate-900 focus:outline-none focus:border-blue-500 transition-all text-sm cursor-pointer"
                  >
                    <option value="">Select Kit Size...</option>
                    <option value="YS">YS (Youth Small)</option>
                    <option value="YM">YM (Youth Medium)</option>
                    <option value="YL">YL (Youth Large)</option>
                    <option value="YXL">YXL (Youth XL)</option>
                    <option value="XS">XS (Adult XS)</option>
                    <option value="S">S (Adult Small)</option>
                    <option value="M">M (Adult Medium)</option>
                    <option value="L">L (Adult Large)</option>
                    <option value="XL">XL (Adult XL)</option>
                    <option value="XXL">XXL (Adult XXL)</option>
                  </select>
                </div>
              </div>

              <button 
                type="submit"
                disabled={isSavingEdit}
                className="w-full bg-slate-900 text-white rounded-xl py-3 font-bold shadow-lg hover:bg-slate-800 transition-all flex items-center justify-center gap-2 mt-4 disabled:opacity-50"
              >
                {isSavingEdit ? <Loader2 className="w-5 h-5 animate-spin" /> : <Check className="w-5 h-5" />}
                {isSavingEdit ? 'Saving...' : 'Save Changes'}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Delete Club Confirmation */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 z-[120] flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-300">
          <div className="bg-white rounded-[2.5rem] shadow-2xl w-full max-w-sm overflow-hidden animate-in zoom-in-95 duration-300">
            <div className="p-8 text-center space-y-6">
              <div className="w-20 h-20 bg-red-50 text-red-500 rounded-3xl flex items-center justify-center mx-auto">
                <AlertTriangle className="w-10 h-10" />
              </div>
              <div className="space-y-2">
                <h3 className="text-2xl font-black text-slate-900 tracking-tight">Delete {club.name}?</h3>
                <p className="text-sm text-slate-500 font-medium leading-relaxed">
                  This will permanently remove the club, all matches, and member records. This cannot be undone.
                </p>
              </div>
              <div className="flex flex-col gap-3">
                <button 
                  onClick={handleConfirmDelete}
                  disabled={isDeleting}
                  className="w-full py-4 bg-red-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl shadow-red-100 hover:bg-red-700 transition-all disabled:opacity-50 flex items-center justify-center gap-2"
                >
                  {isDeleting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
                  Yes, Delete Forever
                </button>
                <button 
                  onClick={() => setShowDeleteConfirm(false)}
                  disabled={isDeleting}
                  className="w-full py-4 bg-slate-100 text-slate-500 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-slate-200 transition-all disabled:opacity-50"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ClubMembers;

import React, { useState, useRef } from 'react';
import { Club, User, ClubType, UserRole } from '../types';
import { X, Camera, Shield, Info, Check, Users, MapPin, Eye, User as UserIcon, Loader2, AlertCircle, Upload, Image as ImageIcon, RefreshCw } from 'lucide-react';

interface ClubFormProps {
  club?: Club;
  onSave: (club: Club) => Promise<void>;
  onCancel: () => void;
  currentUser: User;
}

const ClubForm: React.FC<ClubFormProps> = ({ club, onSave, onCancel, currentUser }) => {
  const [name, setName] = useState(club?.name || '');
  const [description, setDescription] = useState(club?.description || '');
  const [type, setType] = useState<ClubType>(club?.type || 'TEAM');
  const [logoUrl, setLogoUrl] = useState(club?.logo || `https://picsum.photos/seed/${Math.random()}/200/200`);
  const [myRole, setMyRole] = useState<'PLAYER' | 'MANAGER' | 'SPECTATOR'>('PLAYER');
  
  // New Fields requested: Age Group, Gender, Team Photo
  const [ageGroup, setAgeGroup] = useState(club?.ageGroup || 'Adult');
  const [gender, setGender] = useState<'Boys' | 'Girls' | 'Mixed'>(club?.gender || 'Mixed');
  const [teamPhoto, setTeamPhoto] = useState<string>(club?.teamPhoto || '');

  const [isSaving, setIsSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const logoInputRef = useRef<HTMLInputElement>(null);
  const teamPhotoInputRef = useRef<HTMLInputElement>(null);

  const isEditing = !!club;

  const ageGroups = [
    { value: 'U7s', label: 'Under 7s (U7)' },
    { value: 'U8s', label: 'Under 8s (U8)' },
    { value: 'U9s', label: 'Under 9s (U9)' },
    { value: 'U10s', label: 'Under 10s (U10)' },
    { value: 'U11s', label: 'Under 11s (U11)' },
    { value: 'U12s', label: 'Under 12s (U12)' },
    { value: 'U13s', label: 'Under 13s (U13)' },
    { value: 'U14s', label: 'Under 14s (U14)' },
    { value: 'U15s', label: 'Under 15s (U15)' },
    { value: 'U16s', label: 'Under 16s (U16)' },
    { value: 'U17s', label: 'Under 17s (U17)' },
    { value: 'U18s', label: 'Under 18s (U18)' },
    { value: 'Adult', label: 'Adult' }
  ];

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setLogoUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleTeamPhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setTeamPhoto(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const randomizeTeamPhoto = () => {
    // Generate a nice high-quality sport/soccer team photo URL from picsum
    setTeamPhoto(`https://picsum.photos/seed/team-${Math.random()}/600/400`);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || isSaving) return;

    setIsSaving(true);
    setError(null);
    
    try {
      if (isEditing && club) {
        const updatedClub: Club = {
          ...club,
          name: name.trim(),
          description: description.trim(),
          logo: logoUrl,
          type,
          ageGroup,
          gender,
          teamPhoto: teamPhoto || undefined
        };
        await onSave(updatedClub);
      } else {
        // Map local role to UserRole. Managers are Spectators (non-players) but always Admins.
        const baseRole: UserRole = myRole === 'MANAGER' ? 'SPECTATOR' : myRole;
        const roles: UserRole[] = ['ADMIN', baseRole];
        const newClub: Club = {
          id: crypto.randomUUID(),
          name: name.trim(),
          description: description.trim(),
          logo: logoUrl,
          type,
          ownerId: currentUser.id,
          members: [{ ...currentUser, roles }],
          inviteCode: Math.random().toString(36).substring(2, 8).toUpperCase(),
          ageGroup,
          gender,
          teamPhoto: teamPhoto || undefined
        };
        await onSave(newClub);
      }
    } catch (err: any) {
      console.error("Club action failed:", err);
      setError(err.message || `Something went wrong while ${isEditing ? 'updating' : 'creating'} your club. Please try again.`);
      setIsSaving(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto animate-in fade-in slide-in-from-bottom-8 duration-500 pb-20 px-2 xs:px-4">
      <div className="bg-white rounded-2xl sm:rounded-[2.5rem] shadow-2xl border border-slate-200 overflow-hidden">
        <div className="px-4 py-6 sm:px-8 sm:py-8 md:p-10 border-b border-slate-100 flex items-center justify-between bg-slate-50/30">
          <div className="min-w-0">
            <h2 className="text-xl sm:text-2xl md:text-3xl font-black text-slate-900 tracking-tight truncate">
              {isEditing ? 'Edit Hub' : 'Create Hub'}
            </h2>
            <p className="text-slate-500 font-medium mt-1 text-xs sm:text-sm truncate">
              {isEditing ? 'Update your team settings and details.' : 'Setup your team or social group.'}
            </p>
          </div>
          <button 
            type="button"
            onClick={onCancel}
            disabled={isSaving}
            className="p-1.5 sm:p-2.5 text-slate-400 hover:text-slate-600 hover:bg-white rounded-full transition-all border border-transparent hover:border-slate-100 disabled:opacity-50 shrink-0"
          >
            <X className="w-5 h-5 sm:w-6 sm:h-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="px-4 py-6 sm:px-8 sm:py-8 md:p-10 space-y-8 sm:space-y-10">
          {error && (
            <div className="bg-red-50 border border-red-100 p-4 rounded-2xl flex items-center gap-3 text-red-600 animate-in slide-in-from-top-2">
              <AlertCircle className="w-5 h-5 shrink-0" />
              <p className="text-sm font-bold">{error}</p>
            </div>
          )}

          {/* Setup Style - Hidden or Read-only on edit */}
          {!isEditing && (
            <div className="space-y-4">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2 ml-1">
                Select Setup Style
              </label>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <button
                  type="button"
                  disabled={isSaving}
                  onClick={() => setType('TEAM')}
                  className={`flex items-start gap-4 p-5 rounded-2xl border-2 transition-all text-left ${
                    type === 'TEAM' 
                      ? 'border-blue-600 bg-blue-50/50 ring-4 ring-blue-50' 
                      : 'border-slate-100 hover:border-slate-200 bg-white'
                  } disabled:opacity-50`}
                >
                  <div className={`p-3 rounded-xl shrink-0 ${type === 'TEAM' ? 'bg-blue-600 text-white shadow-lg shadow-blue-200' : 'bg-slate-100 text-slate-400'}`}>
                    <Shield className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className={`font-black text-sm uppercase tracking-tight ${type === 'TEAM' ? 'text-blue-900' : 'text-slate-900'}`}>Competitive Club</h4>
                    <p className="text-[11px] text-slate-500 mt-1 font-medium leading-relaxed">Playing matches against other clubs, fixed rosters, and season stats.</p>
                  </div>
                </button>

                <button
                  type="button"
                  disabled={isSaving}
                  onClick={() => setType('SOCIAL')}
                  className={`flex items-start gap-4 p-5 rounded-2xl border-2 transition-all text-left ${
                    type === 'SOCIAL' 
                      ? 'border-indigo-600 bg-indigo-50/50 ring-4 ring-indigo-50' 
                      : 'border-slate-100 hover:border-slate-200 bg-white'
                  } disabled:opacity-50`}
                >
                  <div className={`p-3 rounded-xl shrink-0 ${type === 'SOCIAL' ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-200' : 'bg-slate-100 text-slate-400'}`}>
                    <Users className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className={`font-black text-sm uppercase tracking-tight ${type === 'SOCIAL' ? 'text-indigo-900' : 'text-slate-900'}`}>Social Group</h4>
                    <p className="text-[11px] text-slate-500 mt-1 font-medium leading-relaxed">Organizing internal 5-a-sides, games with mates, and mixed lineups.</p>
                  </div>
                </button>
              </div>
            </div>
          )}

          {/* Creator Role - Only on creation */}
          {!isEditing && (
            <div className="space-y-4">
              <div className="flex items-center justify-between ml-1">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
                  Your Role in this Hub
                </label>
                <span className="text-[9px] font-bold text-blue-600 bg-blue-50 px-2 py-0.5 rounded-full uppercase tracking-tighter">
                  Creator = Admin
                </span>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <button
                  type="button"
                  disabled={isSaving}
                  onClick={() => setMyRole('PLAYER')}
                  className={`flex items-center justify-center gap-3 p-4 rounded-2xl border-2 transition-all ${
                    myRole === 'PLAYER' 
                      ? 'border-green-600 bg-green-50 text-green-700' 
                      : 'border-slate-100 bg-white text-slate-400'
                  } disabled:opacity-50`}
                >
                  <UserIcon className="w-5 h-5" />
                  <span className="font-black text-[10px] uppercase tracking-widest">Player</span>
                </button>
                <button
                  type="button"
                  disabled={isSaving}
                  onClick={() => setMyRole('MANAGER')}
                  className={`flex items-center justify-center gap-3 p-4 rounded-2xl border-2 transition-all ${
                    myRole === 'MANAGER' 
                      ? 'border-blue-600 bg-blue-50 text-blue-700' 
                      : 'border-slate-100 bg-white text-slate-400'
                  } disabled:opacity-50`}
                >
                  <Shield className="w-5 h-5" />
                  <span className="font-black text-[10px] uppercase tracking-widest">Manager</span>
                </button>
                <button
                  type="button"
                  disabled={isSaving}
                  onClick={() => setMyRole('SPECTATOR')}
                  className={`flex items-center justify-center gap-3 p-4 rounded-2xl border-2 transition-all ${
                    myRole === 'SPECTATOR' 
                      ? 'border-amber-600 bg-amber-50 text-amber-700' 
                      : 'border-slate-100 bg-white text-slate-400'
                  } disabled:opacity-50`}
                >
                  <Eye className="w-5 h-5" />
                  <span className="font-black text-[10px] uppercase tracking-widest">Spectator</span>
                </button>
              </div>
              <p className="text-[10px] text-slate-400 font-medium ml-1">
                {myRole === 'MANAGER' ? 'You will manage the club but won\'t appear in match lineups.' : 
                 myRole === 'PLAYER' ? 'You will manage the club and can be added to match lineups.' :
                 'You are following the club as a supporter/admin.'}
              </p>
            </div>
          )}

          {/* Logo Upload & Custom Image Selection */}
          <div className="flex flex-col items-center gap-4 py-4">
            <div className="relative group cursor-pointer" onClick={() => logoInputRef.current?.click()}>
              <img 
                src={logoUrl} 
                className="w-32 h-32 md:w-40 md:h-40 rounded-[2.5rem] object-cover ring-8 ring-slate-50 shadow-2xl transition-transform group-hover:scale-105 duration-500" 
                alt="Logo Preview" 
              />
              <div className="absolute inset-0 bg-slate-900/40 rounded-[2.5rem] flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                <div className="bg-white/20 backdrop-blur-md p-3 md:p-4 rounded-2xl flex flex-col items-center gap-1">
                  <Camera className="w-6 h-6 text-white" />
                  <span className="text-white text-[9px] font-bold uppercase tracking-widest">Upload logo</span>
                </div>
              </div>
            </div>
            <input 
              type="file" 
              ref={logoInputRef} 
              className="hidden" 
              accept="image/*" 
              onChange={handleLogoUpload} 
              disabled={isSaving}
            />
            <div className="flex gap-4">
              <button 
                type="button"
                disabled={isSaving}
                onClick={() => setLogoUrl(`https://picsum.photos/seed/${Date.now()}/200/200`)}
                className="text-[10px] font-black text-slate-400 uppercase tracking-widest hover:text-blue-600 transition-colors flex items-center gap-1.5"
              >
                <RefreshCw className="w-3.5 h-3.5" /> Randomize Logo
              </button>
              <span className="text-slate-300">|</span>
              <button 
                type="button"
                disabled={isSaving}
                onClick={() => logoInputRef.current?.click()}
                className="text-[10px] font-black text-blue-600 uppercase tracking-widest hover:text-blue-700 transition-colors flex items-center gap-1.5"
              >
                <Upload className="w-3.5 h-3.5" /> Upload File
              </button>
            </div>
          </div>

          {/* Name & Description fields */}
          <div className="space-y-8">
            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2 ml-1">
                {type === 'TEAM' ? 'Club Name' : 'Group Name'}
              </label>
              <input 
                autoFocus={!isEditing}
                type="text" 
                required
                disabled={isSaving}
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder={type === 'TEAM' ? 'e.g. North London Titans' : 'e.g. Tuesday Night Ballers'}
                className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-5 py-4 text-slate-900 placeholder:text-slate-300 focus:outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 transition-all font-bold text-base md:text-lg disabled:opacity-50"
              />
            </div>

            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2 ml-1">
                About Us
              </label>
              <textarea 
                rows={3}
                disabled={isSaving}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder={type === 'TEAM' ? 'Team mission and goals...' : 'Group rules and venue details...'}
                className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-5 py-4 text-slate-900 placeholder:text-slate-300 focus:outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 transition-all font-semibold resize-none text-sm disabled:opacity-50"
              />
            </div>
          </div>

          {/* Age Group & Gender Options */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Age Group */}
            <div className="space-y-3">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2 ml-1">
                Age Group
              </label>
              <div className="relative">
                <select
                  disabled={isSaving}
                  value={ageGroup}
                  onChange={(e) => setAgeGroup(e.target.value)}
                  className="w-full appearance-none bg-slate-50 border border-slate-200 rounded-2xl px-5 py-4 font-bold text-slate-900 outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 transition-all cursor-pointer text-sm"
                >
                  {ageGroups.map(group => (
                    <option key={group.value} value={group.value}>
                      {group.label}
                    </option>
                  ))}
                </select>
                <div className="absolute right-5 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M19 9l-7 7-7-7"></path>
                  </svg>
                </div>
              </div>
            </div>

            {/* Gender */}
            <div className="space-y-3">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2 ml-1">
                Gender Classification
              </label>
              <div className="grid grid-cols-3 gap-2">
                {(['Boys', 'Girls', 'Mixed'] as const).map(g => (
                  <button
                    key={g}
                    type="button"
                    disabled={isSaving}
                    onClick={() => setGender(g)}
                    className={`p-3.5 rounded-2xl border-2 transition-all font-black text-[10px] uppercase tracking-widest text-center ${
                      gender === g 
                        ? 'border-blue-600 bg-blue-50 text-blue-700' 
                        : 'border-slate-100 bg-white text-slate-400 hover:border-slate-200'
                    }`}
                  >
                    {g}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Team Photo Section */}
          <div className="space-y-4 border-t border-slate-100 pt-8">
            <div className="flex items-center justify-between ml-1">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
                Team Photo
              </label>
              <span className="text-[9px] font-bold text-slate-400 uppercase">
                Optional
              </span>
            </div>

            <div className="relative group rounded-3xl overflow-hidden border-2 border-dashed border-slate-200 bg-slate-50 min-h-[200px] flex flex-col items-center justify-center p-6 text-center transition-all hover:border-blue-400">
              {teamPhoto ? (
                <div className="absolute inset-0 w-full h-full">
                  <img 
                    src={teamPhoto} 
                    className="w-full h-full object-cover" 
                    alt="Team Preview" 
                  />
                  <div className="absolute inset-0 bg-slate-900/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center gap-3">
                    <button
                      type="button"
                      disabled={isSaving}
                      onClick={() => teamPhotoInputRef.current?.click()}
                      className="px-4 py-2 bg-white rounded-xl text-[10px] font-black uppercase tracking-widest text-slate-900 shadow-md hover:bg-slate-50 transition-all"
                    >
                      Change Photo
                    </button>
                    <button
                      type="button"
                      disabled={isSaving}
                      onClick={() => setTeamPhoto('')}
                      className="px-4 py-2 bg-red-600 rounded-xl text-[10px] font-black uppercase tracking-widest text-white shadow-md hover:bg-red-700 transition-all"
                    >
                      Remove
                    </button>
                  </div>
                </div>
              ) : (
                <div className="space-y-4 flex flex-col items-center" onClick={() => teamPhotoInputRef.current?.click()}>
                  <div className="p-4 bg-white rounded-2xl shadow-md text-slate-400 group-hover:text-blue-500 group-hover:scale-110 transition-all cursor-pointer">
                    <Upload className="w-8 h-8" />
                  </div>
                  <div>
                    <p className="font-bold text-slate-700 text-sm">Upload a team photo</p>
                    <p className="text-[11px] text-slate-400 font-medium mt-1">PNG, JPG, or GIF (max 1MB suggested)</p>
                  </div>
                </div>
              )}
            </div>

            <input 
              type="file" 
              ref={teamPhotoInputRef} 
              className="hidden" 
              accept="image/*" 
              onChange={handleTeamPhotoUpload} 
              disabled={isSaving}
            />

            <div className="flex flex-col sm:flex-row items-center justify-center gap-2 xs:gap-4">
              <button 
                type="button"
                disabled={isSaving}
                onClick={randomizeTeamPhoto}
                className="text-[9px] sm:text-[10px] font-black text-slate-400 uppercase tracking-widest hover:text-blue-600 transition-colors flex items-center gap-1.5"
              >
                <RefreshCw className="w-3.5 h-3.5" /> Use Random Sport Team Photo
              </button>
              {!teamPhoto && (
                <>
                  <span className="text-slate-300 hidden sm:inline">|</span>
                  <button 
                    type="button"
                    disabled={isSaving}
                    onClick={() => teamPhotoInputRef.current?.click()}
                    className="text-[9px] sm:text-[10px] font-black text-blue-600 uppercase tracking-widest hover:text-blue-700 transition-colors flex items-center gap-1.5"
                  >
                    <Upload className="w-3.5 h-3.5" /> Choose local photo
                  </button>
                </>
              )}
            </div>
          </div>

          {/* Submit buttons */}
          <div className="flex flex-col-reverse md:flex-row gap-4 pt-4 border-t border-slate-100">
            <button 
              type="button"
              disabled={isSaving}
              onClick={onCancel}
              className="flex-1 px-8 py-4 md:py-5 rounded-2xl font-black text-slate-500 bg-slate-100 hover:bg-slate-200 transition-all uppercase tracking-widest text-[10px] md:text-xs disabled:opacity-50"
            >
              Cancel
            </button>
            <button 
              type="submit"
              disabled={isSaving}
              className={`flex-[2] px-8 py-4 md:py-5 rounded-2xl font-black text-white shadow-xl hover:translate-y-[-2px] active:translate-y-[0px] transition-all flex items-center justify-center gap-3 uppercase tracking-widest text-[10px] md:text-xs ${
                type === 'TEAM' ? 'bg-blue-600 shadow-blue-100 hover:bg-blue-700' : 'bg-indigo-600 shadow-indigo-100 hover:bg-indigo-700'
              } disabled:opacity-50 disabled:translate-y-0`}
            >
              {isSaving ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  <span>Saving...</span>
                </>
              ) : (
                <>
                  <Check className="w-5 h-5" />
                  <span>{isEditing ? 'Save Changes' : (type === 'TEAM' ? 'Form Club' : 'Create Group')}</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default ClubForm;

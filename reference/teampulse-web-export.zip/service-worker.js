
// service-worker.js - PWA Background Handler
self.addEventListener('install', (event) => {
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(clients.claim());
});

// This is the CRITICAL part for background/lock-screen alerts
self.addEventListener('push', (event) => {
  let data = { 
    title: 'TeamPulse Update', 
    body: 'New match activity!', 
    url: '/' 
  };

  if (event.data) {
    try {
      data = event.data.json();
    } catch (e) {
      data.body = event.data.text();
    }
  }

  const options = {
    body: data.body,
    icon: 'https://picsum.photos/seed/teampulse/192/192',
    badge: 'https://picsum.photos/seed/teampulse/96/96',
    vibrate: [200, 100, 200, 100, 200], // Stronger pattern for iOS
    tag: data.id || 'teampulse-push-group',
    renotify: true,
    data: {
      url: data.url || '/'
    },
    // Required for lock-screen banners on iOS
    requireInteraction: true,
    actions: [
      { action: 'open', title: 'View Match' }
    ]
  };

  event.waitUntil(
    self.registration.showNotification(data.title, options)
  );
});

// Handle locally triggered notifications from the app (Foreground/Background transition)
self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'TRIGGER_NOTIF') {
    const { title, body, id, url } = event.data;
    
    const options = {
      body: body,
      icon: 'https://picsum.photos/seed/teampulse/192/192',
      badge: 'https://picsum.photos/seed/teampulse/96/96',
      vibrate: [500, 110, 500, 110, 450, 110, 200, 110, 170, 40, 450, 110, 200, 110, 170, 40],
      tag: id || 'teampulse-alert',
      renotify: true,
      data: { url: url || '/' },
      requireInteraction: true
    };

    event.waitUntil(
      self.registration.showNotification(title, options)
    );
  }
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  event.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clientList) => {
      for (const client of clientList) {
        if (client.url === '/' && 'focus' in client) return client.focus();
      }
      if (clients.openWindow) return clients.openWindow(event.notification.data.url || '/');
    })
  );
});

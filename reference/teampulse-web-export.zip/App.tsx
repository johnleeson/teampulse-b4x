
import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import Layout from './components/Layout';
import Dashboard from './components/Dashboard';
import { MatchFeed } from './components/MatchFeed'; 
import ClubForm from './components/ClubForm';
import MatchForm from './components/MatchForm';
import ClubMembers from './components/ClubMembers';
import StatsDashboard from './components/StatsDashboard';
import Login from './components/Login';
import JoinClubModal from './components/JoinClubModal';
import NotificationCenter from './components/NotificationCenter';
import ApiKeySelectionModal from './components/ApiKeySelectionModal'; 
import { Club, Match, FeedEvent, User, UserRole, AppNotification } from './types';
import { ChevronRight, Hash, Plus, ArrowLeft, RefreshCcw, Share, PlusSquare, Smartphone, Settings as SettingsIcon, BellRing, Shield, ChevronLeft, Calendar, MapPin, Zap } from 'lucide-react';
import { AppState, loadData, saveData } from './store';
import { dbService, handleFirestoreError, OperationType } from './services/dbService';
import { auth, db } from './firebase';
import { onAuthStateChanged, signOut } from 'firebase/auth';
import { collection, onSnapshot, query, orderBy, doc, getDoc } from 'firebase/firestore';

class ErrorBoundary extends React.Component<{ children: React.ReactNode }, { hasError: boolean, error: any }> {
  constructor(props: { children: React.ReactNode }) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: any) {
    return { hasError: true, error };
  }

  componentDidCatch(error: any, errorInfo: any) {
    console.error("ErrorBoundary caught an error", error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      let message = "Something went wrong.";
      try {
        const errObj = JSON.parse(this.state.error.message);
        if (errObj.error) message = `Firebase Error: ${errObj.error}`;
      } catch (e) {}

      return (
        <div className="flex flex-col items-center justify-center h-screen bg-slate-50 p-6 text-center">
          <div className="bg-white p-8 rounded-[2rem] shadow-xl max-w-md w-full space-y-4">
            <div className="bg-red-100 text-red-600 w-16 h-16 rounded-full flex items-center justify-center mx-auto">
              <RefreshCcw className="w-8 h-8" />
            </div>
            <h2 className="text-2xl font-black text-slate-900">Application Error</h2>
            <p className="text-slate-500 font-medium">{message}</p>
            <button 
              onClick={() => window.location.reload()}
              className="w-full py-4 bg-blue-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-lg shadow-blue-200"
            >
              Reload App
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

const App: React.FC = () => {
  const [appData, setAppData] = useState<AppState | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSyncing, setIsSyncing] = useState(false);
  const [activeTab, setActiveTab] = useState('dashboard');
  const [selectedMatchId, setSelectedMatchId] = useState<string | null>(null);
  const [managingClubId, setManagingClubId] = useState<string | null>(null);
  const [isCreatingClub, setIsCreatingClub] = useState(false);
  const [editingClubId, setEditingClubId] = useState<string | null>(null);
  const [isCreatingMatchForClubId, setIsCreatingMatchForClubId] = useState<string | null>(null);
  const [isSelectingClubForMatch, setIsSelectingClubForMatch] = useState(false);
  const [isEditingMatch, setIsEditingMatch] = useState<Match | null>(null);
  const [isNotificationCenterOpen, setIsNotificationCenterOpen] = useState(false);
  const [showApiKeySelectionModal, setShowApiKeySelectionModal] = useState(false); 
  const [realtimeStatus, setRealtimeStatus] = useState<'SUBSCRIBED' | 'TIMED_OUT' | 'CLOSED' | 'CHANNEL_ERROR' | 'INITIAL' | 'CONNECTING'>('INITIAL');
  const [isPulsing, setIsPulsing] = useState(false);
  const [notifPermission, setNotifPermission] = useState<NotificationPermission>('default');
  const [showInstallGuide, setShowInstallGuide] = useState(false);
  const [isPushSubscribed, setIsPushSubscribed] = useState(false);

  const syncRef = useRef(false);
  const currentUserIdRef = useRef<string | null>(null);

  // iPhone PWA Check
  useEffect(() => {
    const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent);
    const isStandalone = (window.navigator as any).standalone === true;
    if (isIOS && !isStandalone) {
      const lastShown = localStorage.getItem('install_guide_shown');
      if (!lastShown || Date.now() - parseInt(lastShown) > 86400000) {
        setShowInstallGuide(true);
      }
    }
  }, []);

  // Check current subscription status
  useEffect(() => {
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.ready.then(reg => {
        if (reg.pushManager) {
          reg.pushManager.getSubscription().then(sub => {
            setIsPushSubscribed(!!sub);
          }).catch(err => console.error("Error getting subscription:", err));
        }
      });
    }
    if (typeof Notification !== 'undefined') {
      setNotifPermission(Notification.permission);
    }
  }, []);

  const handleSubscribeToPush = async () => {
    if (!('serviceWorker' in navigator)) return;
    if (typeof Notification === 'undefined') {
      alert("Notifications are not supported on this device/browser.");
      return;
    }
    
    try {
      const permission = await Notification.requestPermission();
      setNotifPermission(permission);
      
      if (permission === 'granted') {
        const reg = await navigator.serviceWorker.ready;
        if (reg.pushManager) {
          const sub = await reg.pushManager.subscribe({
            userVisibleOnly: true,
            applicationServerKey: null 
          });
          setIsPushSubscribed(true);
          triggerNativeNotification("System Push Active! 🚀", "Lock-screen alerts and vibration are now enabled.", "push-init");
        } else {
          console.warn("PushManager not available on this registration");
        }
      }
    } catch (err) {
      console.error("Push subscription failed:", err);
      alert("To enable lock-screen alerts, please ensure 'Notifications' are enabled for TeamPulse in your iPhone Settings.");
    }
  };

  // System Badge Update
  useEffect(() => {
    if (appData && 'setAppBadge' in navigator) {
      const unread = appData.notifications.filter(n => !n.isRead).length;
      if (unread > 0) {
        (navigator as any).setAppBadge(unread).catch(() => {});
      } else {
        (navigator as any).clearAppBadge().catch(() => {});
      }
    }
  }, [appData]);

  useEffect(() => {
    if (appData) saveData(appData);
  }, [appData]);

  const refreshData = useCallback(async () => {
    if (syncRef.current) return;
    syncRef.current = true;
    setIsSyncing(true);
    try {
      const remoteData = await dbService.fetchInitialData();
      setAppData(prev => prev ? ({ ...prev, ...remoteData }) : null);
    } catch (err) {
      console.error("❌ Sync failed:", err);
    } finally {
      setIsSyncing(false);
      syncRef.current = false;
    }
  }, []);

  const triggerPulse = () => {
    setIsPulsing(true);
    setTimeout(() => setIsPulsing(false), 800);
  };

  const triggerNativeNotification = useCallback((title: string, body: string, id: string) => {
    if (typeof Notification === 'undefined' || Notification.permission !== 'granted') return;

    if ('serviceWorker' in navigator && navigator.serviceWorker.controller) {
      navigator.serviceWorker.controller.postMessage({
        type: 'TRIGGER_NOTIF',
        title,
        body,
        id,
        url: window.location.origin
      });
    } else {
      try {
        new Notification(title, { body, icon: 'https://picsum.photos/seed/teampulse/192/192' });
      } catch(e) {
        console.warn("Failed to trigger native notification:", e);
      }
    }
  }, []);

  // Real-time Engine (Firebase)
  useEffect(() => {
    if (!appData?.currentUser) {
      setRealtimeStatus('INITIAL');
      return;
    }

    setRealtimeStatus('CONNECTING');
    
    const unsubMatches = onSnapshot(collection(db, 'matches'), (snapshot) => {
      snapshot.docChanges().forEach((change) => {
        if (change.type === 'added' || change.type === 'modified') {
          const updatedMatch = dbService.mapMatch(change.doc.data(), change.doc.id);
          triggerPulse();
          setAppData(prev => prev ? ({
            ...prev,
            matches: prev.matches.some(m => m.id === updatedMatch.id)
              ? prev.matches.map(m => m.id === updatedMatch.id ? { ...m, ...updatedMatch } : m)
              : [updatedMatch, ...prev.matches]
          }) : null);
        }
      });
      setRealtimeStatus('SUBSCRIBED');
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, 'matches');
    });

    const unsubEvents = onSnapshot(query(collection(db, 'feed_events'), orderBy('timestamp', 'desc')), (snapshot) => {
      snapshot.docChanges().forEach((change) => {
        if (change.type === 'added') {
          const mappedEvent = dbService.mapEvent(change.doc.data(), change.doc.id);
          triggerPulse();

          const isImportant = ['GOAL', 'START', 'END', 'RED_CARD', 'CANCELLED'].includes(mappedEvent.type);
          
          setAppData(prev => {
            if (!prev) return null;
            
            const isDup = prev.feedEvents.some(e => e.id === mappedEvent.id);
            if (isDup) return prev;

            const newEvents = [mappedEvent, ...prev.feedEvents].sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
            
            let updatedNotifications = [...prev.notifications];
            let newNotif: AppNotification | null = null;

            if (isImportant) {
              newNotif = {
                id: crypto.randomUUID(),
                title: mappedEvent.type === 'GOAL' ? 'GOOOAAALLL! ⚽' : 'Live Match Update',
                body: mappedEvent.content,
                timestamp: new Date(),
                isRead: false,
                type: mappedEvent.type === 'GOAL' ? 'GOAL' : 'SYSTEM',
                linkId: mappedEvent.matchId
              };

              const isNotifDup = prev.notifications.some(n => n.body === newNotif!.body && Math.abs(n.timestamp.getTime() - newNotif!.timestamp.getTime()) < 3000);
              if (!isNotifDup) {
                updatedNotifications = [newNotif, ...prev.notifications].slice(0, 50);
                
                const isNotMe = currentUserIdRef.current !== mappedEvent.userId;
                const isForceAlert = ['GOAL', 'START', 'END'].includes(mappedEvent.type);
                if (isNotMe || isForceAlert) {
                  triggerNativeNotification(newNotif.title, newNotif.body, newNotif.id);
                }
              }
            }

            return {
              ...prev,
              feedEvents: newEvents,
              notifications: updatedNotifications
            };
          });
        }
      });
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, 'feed_events');
    });

    const unsubClubs = onSnapshot(collection(db, 'clubs'), () => refreshData(), (error) => {
      handleFirestoreError(error, OperationType.GET, 'clubs');
    });
    const unsubMembers = onSnapshot(collection(db, 'club_members'), () => refreshData(), (error) => {
      handleFirestoreError(error, OperationType.GET, 'club_members');
    });

    return () => {
      unsubMatches();
      unsubEvents();
      unsubClubs();
      unsubMembers();
    };
  }, [appData?.currentUser?.id, refreshData, triggerNativeNotification]);

  useEffect(() => {
    const unsubAuth = onAuthStateChanged(auth, async (user) => {
      setIsLoading(true);
      try {
        let data = loadData();
        if (user) {
          const profileSnap = await getDoc(doc(db, 'profiles', user.uid));
          if (profileSnap.exists()) {
            const profile = profileSnap.data();
            const u: User = { 
              id: user.uid, 
              name: profile.name, 
              avatar: profile.avatar || `https://i.pravatar.cc/150?u=${user.uid}`, 
              roles: profile.roles || ['PLAYER'] 
            };
            data.currentUser = u;
            currentUserIdRef.current = u.id;
          } else {
            // Fallback for new users
            const u: User = {
              id: user.uid,
              name: user.displayName || 'User',
              avatar: user.photoURL || `https://i.pravatar.cc/150?u=${user.uid}`,
              roles: ['PLAYER']
            };
            data.currentUser = u;
            currentUserIdRef.current = u.id;
          }
          const remoteData = await dbService.fetchInitialData();
          data = { ...data, ...remoteData };
        } else {
          data.currentUser = null;
          currentUserIdRef.current = null;
        }
        setAppData(data);
      } catch (err) {
        console.error("Init error:", err);
      } finally {
        setIsLoading(false);
      }
    });

    return () => unsubAuth();
  }, [refreshData]);

  const handleLogin = async (user: User) => {
    currentUserIdRef.current = user.id;
    setAppData(prev => ({ ...prev!, currentUser: user }));
    await refreshData();
  };

  const handleLogout = async () => {
    currentUserIdRef.current = null;
    await signOut(auth);
    setAppData(prev => prev ? ({ ...prev, currentUser: null }) : null);
  };

  const handleUpdateMatchData = async (matchId: string, data: Partial<Match>) => {
    setAppData(prev => prev ? ({ ...prev, matches: prev.matches.map(m => m.id === matchId ? { ...m, ...data } : m) }) : null);
    const match = appData?.matches.find(m => m.id === matchId);
    if (match) {
      await dbService.saveMatch({ ...match, ...data });
    }
  };

  const handleDeleteMatch = async (matchId: string) => {
    setAppData(prev => prev ? ({ 
      ...prev, 
      matches: prev.matches.filter(m => m.id !== matchId),
      feedEvents: prev.feedEvents.filter(e => e.matchId !== matchId)
    }) : null);
    await dbService.deleteMatch(matchId);
    if (selectedMatchId === matchId) {
      setSelectedMatchId(null);
    }
  };

  const handleUpdateClubMemberRating = async (clubId: string, userId: string, rating: number) => {
    setAppData(prev => {
      if (!prev) return null;
      return {
        ...prev,
        clubs: prev.clubs.map(c => {
          if (c.id !== clubId) return c;
          return {
            ...c,
            members: c.members.map(m => {
              if (m.id !== userId) return m;
              return { ...m, abilityRating: rating };
            })
          };
        })
      };
    });
    await dbService.updateMemberRating(clubId, userId, rating);
  };

  const handleAddEvent = async (matchId: string, eventData: Partial<FeedEvent>) => {
    if (!appData?.currentUser) return;
    const newEvent: FeedEvent = {
      id: crypto.randomUUID(),
      matchId,
      userId: appData.currentUser.id,
      userName: appData.currentUser.name,
      timestamp: new Date(),
      type: 'COMMENT',
      content: '',
      ...eventData
    };
    setAppData(prev => prev ? ({ ...prev, feedEvents: [newEvent, ...prev.feedEvents] }) : null);
    await dbService.saveEvent(newEvent);
  };

  const resetFlow = () => {
    setIsSelectingClubForMatch(false);
    setIsCreatingMatchForClubId(null);
    setIsCreatingClub(false);
    setManagingClubId(null);
  };

  const handleCreateMatchStart = () => {
    if (!appData) return;
    const adminClubs = appData.clubs.filter(c => 
      c.ownerId === appData.currentUser?.id || 
      c.members.some(m => m.id === appData.currentUser?.id && m.roles.includes('ADMIN'))
    );

    if (adminClubs.length === 1) {
      setIsCreatingMatchForClubId(adminClubs[0].id);
    } else if (adminClubs.length > 1) {
      setIsSelectingClubForMatch(true);
    } else {
      alert("You need to be an Admin of a club to create a match. Create a club first!");
      setIsCreatingClub(true);
    }
  };

  const renderContent = () => {
    if (isLoading || !appData) {
      return <div className="flex items-center justify-center h-full"><RefreshCcw className="animate-spin text-blue-600" /></div>;
    }

    if (selectedMatchId) {
      const match = appData.matches.find(m => m.id === selectedMatchId);
      if (!match) {
        return <div className="flex items-center justify-center h-full"><RefreshCcw className="animate-spin text-blue-600" /></div>;
      }
      const club = appData.clubs.find(c => c.id === match.clubId);
      return (
        <MatchFeed 
          match={match} 
          club={club} 
          events={appData.feedEvents.filter(e => e.matchId === selectedMatchId)} 
          allMatches={appData.matches}
          onAddEvent={(d) => handleAddEvent(selectedMatchId, d)} 
          onDeleteEvent={async (id) => { setAppData(prev => prev ? ({ ...prev, feedEvents: prev.feedEvents.filter(e => e.id !== id) }) : null); await dbService.deleteEvent(id); }} 
          onUpdateEvent={async (id, content) => { setAppData(prev => prev ? ({ ...prev, feedEvents: prev.feedEvents.map(e => e.id === id ? { ...e, content } : e) }) : null); const ev = appData.feedEvents.find(e => e.id === id); if (ev) await dbService.saveEvent({ ...ev, content }); }} 
          onUpdateStatus={(s) => handleUpdateMatchData(selectedMatchId, { status: s })} 
          onUpdateLineup={() => {}} 
          onUpdateMatchData={handleUpdateMatchData} 
          onJoinMatch={() => {}} 
          onEditMatch={setIsEditingMatch} 
          onVoteForPotm={(pid) => handleUpdateMatchData(selectedMatchId, { potmVotes: { ...(match.potmVotes || {}), [appData.currentUser!.id]: pid } })} 
          onSaveAiSummary={(id, summary) => handleUpdateMatchData(id, { aiSummary: summary })} 
          currentUser={appData.currentUser!} 
          onApiKeyTrouble={() => setShowApiKeySelectionModal(true)} 
          onUpdateClubMemberRating={handleUpdateClubMemberRating}
          onBack={() => setSelectedMatchId(null)}
          onDeleteMatch={handleDeleteMatch}
        />
      );
    }

    if (isCreatingClub) {
      return (
        <ClubForm 
          currentUser={appData.currentUser!} 
          onSave={async (c) => { 
            setAppData(prev => prev ? ({ ...prev, clubs: [...prev.clubs, c] }) : null); 
            await dbService.saveClub(c, appData.currentUser!); 
            setIsCreatingClub(false); 
            setActiveTab('clubs'); 
          }} 
          onCancel={() => setIsCreatingClub(false)} 
        />
      );
    }

    if (isSelectingClubForMatch) {
      return (
        <div className="max-w-2xl mx-auto space-y-8 animate-in slide-in-from-bottom-4 duration-500">
          <button onClick={() => setIsSelectingClubForMatch(false)} className="flex items-center gap-2 text-blue-600 font-bold text-sm"><ChevronLeft className="w-4 h-4" /> Back</button>
          <div className="text-center">
            <h2 className="text-3xl font-black text-slate-900 tracking-tight">Select a Club</h2>
            <p className="text-slate-500 font-medium">Which club are you planning for?</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {adminClubs.map(club => (
              <button 
                key={club.id} 
                onClick={() => { setIsCreatingMatchForClubId(club.id); setIsSelectingClubForMatch(false); }}
                className="bg-white p-6 rounded-[2rem] border-2 border-slate-100 hover:border-blue-600 transition-all flex flex-col items-center gap-4 text-center group"
              >
                <img src={club.logo} className="w-20 h-20 rounded-3xl object-cover shadow-lg group-hover:scale-105 transition-transform" />
                <div>
                  <h4 className="font-black text-slate-900 text-lg">{club.name}</h4>
                  <p className="text-[10px] font-black uppercase text-slate-400 tracking-widest">{club.type}</p>
                </div>
              </button>
            ))}
          </div>
        </div>
      );
    }

    if (isCreatingMatchForClubId) {
      return (
        <MatchForm 
          club={appData.clubs.find(c => c.id === isCreatingMatchForClubId)!} 
          currentUserId={appData.currentUser!.id}
          onCancel={() => setIsCreatingMatchForClubId(null)} 
          onSave={async (match) => {
            setAppData(prev => prev ? ({ ...prev, matches: [match, ...prev.matches] }) : null);
            await dbService.saveMatch(match);
            setIsCreatingMatchForClubId(null);
            setSelectedMatchId(match.id);
          }} 
        />
      );
    }

    if (editingClubId) {
      const clubToEdit = appData.clubs.find(c => c.id === editingClubId);
      if (clubToEdit) {
        return (
          <ClubForm 
            currentUser={appData.currentUser!} 
            club={clubToEdit}
            onSave={async (updatedClub) => { 
              setAppData(prev => prev ? ({
                ...prev,
                clubs: prev.clubs.map(c => c.id === updatedClub.id ? { ...c, ...updatedClub } : c)
              }) : null); 
              await dbService.saveClub(updatedClub, appData.currentUser!); 
              setEditingClubId(null); 
            }} 
            onCancel={() => setEditingClubId(null)} 
          />
        );
      }
    }

    if (activeTab === 'clubs' && managingClubId) {
      return (
        <ClubMembers 
          club={appData.clubs.find(c => c.id === managingClubId)!} 
          currentUser={appData.currentUser!} 
          onEditClub={(id) => setEditingClubId(id)} 
          onUpdateRoles={async (uid, roles) => {
            setAppData(prev => prev ? ({
              ...prev,
              clubs: prev.clubs.map(c => c.id === managingClubId ? {
                ...c,
                members: c.members.map(m => m.id === uid ? { ...m, roles } : m)
              } : c)
            }) : null);
            await dbService.updateMemberRoles(managingClubId, uid, roles);
          }}
          onRemoveMember={async (uid) => {
            setAppData(prev => prev ? ({
              ...prev,
              clubs: prev.clubs.map(c => c.id === managingClubId ? {
                ...c,
                members: c.members.filter(m => m.id !== uid)
              } : c)
            }) : null);
            await dbService.removeMember(managingClubId, uid);
          }}
          onAddMember={async (name, roles, avatar, age, gender, favPosition, kitSize) => {
             const newMember = { id: crypto.randomUUID(), name, roles, avatar, age, gender, favPosition, kitSize };
             setAppData(prev => prev ? ({
               ...prev,
               clubs: prev.clubs.map(c => c.id === managingClubId ? {
                 ...c,
                 members: [...c.members, newMember]
               } : c)
             }) : null);
             await dbService.addMember(managingClubId, newMember);
          }}
          onUpdateMember={async (updatedMember) => {
            setAppData(prev => prev ? ({
              ...prev,
              clubs: prev.clubs.map(c => c.id === managingClubId ? {
                ...c,
                members: c.members.map(m => m.id === updatedMember.id ? updatedMember : m)
              } : c)
            }) : null);
            await dbService.saveProfile(updatedMember);
          }}
          onDeleteClub={async (id) => {
            setAppData(prev => prev ? ({ ...prev, clubs: prev.clubs.filter(c => c.id !== id) }) : null);
            await dbService.deleteClub(id);
            setManagingClubId(null);
          }}
          onBack={() => setManagingClubId(null)}
        />
      );
    }

    switch (activeTab) {
      case 'dashboard':
        return (
          <Dashboard 
            clubs={appData.clubs.filter(club => club.members.some(m => m.id === appData.currentUser?.id))} 
            matches={appData.matches.filter(m => appData.clubs.some(c => c.id === m.clubId && c.members.some(mem => mem.id === appData.currentUser?.id)))} 
            currentUser={appData.currentUser!} 
            onViewMatch={setSelectedMatchId} 
            onJoinMatch={(id) => handleUpdateMatchData(id, { signedUpPlayerIds: [...(appData.matches.find(m => m.id === id)?.signedUpPlayerIds || []), appData.currentUser!.id] })} 
            onViewClub={(id) => { setManagingClubId(id); setActiveTab('clubs'); }} 
            onCreateClub={() => setIsCreatingClub(true)} 
            onCreateMatch={handleCreateMatchStart} 
            onCancelMatch={(id) => handleUpdateMatchData(id, { status: 'CANCELLED' })} 
            onDeleteMatch={handleDeleteMatch}
            onTestNotify={() => triggerNativeNotification("Test Alert ⚡", "Foreground alerts working. Vibration check.", "test-manual")} 
          />
        );
      case 'clubs':
        return (
          <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <div className="flex items-center justify-between">
              <h2 className="text-3xl font-black text-slate-900 tracking-tight">My Clubs</h2>
              <button onClick={() => setIsCreatingClub(true)} className="bg-blue-600 text-white px-6 py-3 rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl shadow-blue-100 hover:bg-blue-700 transition-all flex items-center gap-2">
                <Plus className="w-4 h-4" /> New Club
              </button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {appData.clubs.filter(club => club.members.some(m => m.id === appData.currentUser?.id)).map(club => (
                <div 
                  key={club.id} 
                  onClick={() => setManagingClubId(club.id)} 
                  className="bg-white rounded-[2.5rem] border border-slate-200 overflow-hidden hover:shadow-xl hover:-translate-y-1 transition-all cursor-pointer group flex flex-col"
                >
                  {club.teamPhoto && (
                    <div className="h-32 w-full relative overflow-hidden shrink-0">
                      <img src={club.teamPhoto} className="w-full h-full object-cover group-hover:scale-105 duration-500 transition-transform" alt={`${club.name} Team`} />
                      <div className="absolute inset-0 bg-gradient-to-t from-slate-900/60 via-slate-900/10 to-transparent" />
                    </div>
                  )}
                  <div className={`p-6 flex-1 flex flex-col ${club.teamPhoto ? 'pt-4' : ''}`}>
                    <div className={`${club.teamPhoto ? '-mt-16 mb-3 relative z-10' : 'mb-4'}`}>
                      <img 
                        src={club.logo} 
                        className={`w-20 h-20 rounded-3xl object-cover shadow-lg border border-slate-100 ${
                          club.teamPhoto ? 'border-4 border-white' : ''
                        }`} 
                        alt={club.name}
                      />
                    </div>
                    <h3 className="text-xl font-black text-slate-900 group-hover:text-blue-600 transition-colors tracking-tight">{club.name}</h3>
                    <p className="text-sm text-slate-500 font-medium mt-1 mb-4 flex-1">{club.description}</p>
                    
                    <div className="flex flex-wrap items-center gap-2 mb-4">
                      <span className={`text-[8px] font-black uppercase px-2 py-0.5 rounded-full border ${
                        club.type === 'TEAM' ? 'bg-blue-50 text-blue-600 border-blue-100' : 'bg-indigo-50 text-indigo-600 border-indigo-100'
                      }`}>
                        {club.type}
                      </span>
                      {club.ageGroup && (
                        <span className="bg-slate-50 text-slate-500 px-1.5 py-0.5 rounded-md text-[8px] font-black uppercase tracking-wider border border-slate-100">
                          {club.ageGroup}
                        </span>
                      )}
                      {club.gender && (
                        <span className="bg-slate-50 text-slate-500 px-1.5 py-0.5 rounded-md text-[8px] font-black uppercase tracking-wider border border-slate-100">
                          {club.gender}
                        </span>
                      )}
                    </div>

                    <div className="flex items-center justify-between pt-4 border-t border-slate-50 shrink-0">
                      <span className="text-[10px] font-black uppercase text-slate-400 tracking-widest">{club.members.length} Members</span>
                      <ChevronRight className="w-5 h-5 text-slate-300 group-hover:text-blue-600 transition-colors" />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        );
      case 'matches':
        return (
          <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
             <div className="flex items-center justify-between">
              <h2 className="text-3xl font-black text-slate-900 tracking-tight">Match Schedule</h2>
              <button onClick={handleCreateMatchStart} className="bg-blue-600 text-white px-6 py-3 rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl shadow-blue-100 hover:bg-blue-700 transition-all flex items-center gap-2">
                <Calendar className="w-4 h-4" /> Plan Game
              </button>
            </div>
            <div className="space-y-4">
              {appData.matches.filter(m => appData.clubs.some(c => c.id === m.clubId && c.members.some(mem => mem.id === appData.currentUser?.id))).map(match => (
                <div key={match.id} onClick={() => setSelectedMatchId(match.id)} className="bg-white p-6 rounded-[2rem] border border-slate-200 shadow-sm hover:shadow-xl transition-all cursor-pointer flex items-center justify-between group">
                  <div className="flex items-center gap-6">
                    <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100 text-center min-w-[80px] group-hover:bg-blue-600 group-hover:text-white transition-colors">
                      <p className="text-[10px] font-black uppercase opacity-70">{new Date(match.date).toLocaleDateString('en-US', { month: 'short' })}</p>
                      <p className="text-2xl font-black">{new Date(match.date).getDate()}</p>
                    </div>
                    <div>
                      <h4 className="font-black text-slate-900 text-lg group-hover:text-blue-600 transition-colors">{match.title}</h4>
                      <p className="text-sm text-slate-500 font-medium flex items-center gap-1.5"><MapPin className="w-4 h-4 text-red-400" /> {match.location}</p>
                    </div>
                  </div>
                  <ChevronRight className="w-6 h-6 text-slate-300 group-hover:text-blue-600 transition-colors" />
                </div>
              ))}
            </div>
          </div>
        );
      case 'stats':
        const userClubsForStats = appData.clubs.filter(club => club.members.some(m => m.id === appData.currentUser?.id));
        if (userClubsForStats.length === 0) {
          return (
            <div className="flex flex-col items-center justify-center h-[60vh] text-center space-y-4">
              <div className="bg-slate-100 p-8 rounded-full">
                <Shield className="w-12 h-12 text-slate-300" />
              </div>
              <h2 className="text-2xl font-black text-slate-900">No Clubs Found</h2>
              <p className="text-slate-500 font-medium max-w-xs">Join or create a club to see performance statistics.</p>
              <button onClick={() => setIsCreatingClub(true)} className="bg-blue-600 text-white px-8 py-4 rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl shadow-blue-100">Create a Club</button>
            </div>
          );
        }
        const statsClub = appData.clubs.find(c => c.id === managingClubId) || userClubsForStats[0];
        return (
          <div className="space-y-6">
            {userClubsForStats.length > 1 && (
              <div className="flex gap-2 overflow-x-auto pb-2 no-scrollbar">
                {userClubsForStats.map(c => (
                  <button 
                    key={c.id}
                    onClick={() => setManagingClubId(c.id)}
                    className={`px-4 py-2 rounded-full text-[10px] font-black uppercase tracking-widest transition-all whitespace-nowrap border ${
                      (managingClubId === c.id || (managingClubId === null && userClubsForStats[0].id === c.id))
                        ? 'bg-slate-900 text-white border-slate-900' 
                        : 'bg-white text-slate-500 border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    {c.name}
                  </button>
                ))}
              </div>
            )}
            <StatsDashboard 
              club={statsClub}
              matches={appData.matches}
              events={appData.feedEvents}
            />
          </div>
        );
      default:
        return (
          <div className="flex flex-col items-center justify-center h-full text-center space-y-4">
            <div className="bg-slate-100 p-8 rounded-full">
              <Zap className="w-12 h-12 text-slate-300" />
            </div>
            <h2 className="text-2xl font-black text-slate-900">Coming Soon</h2>
            <p className="text-slate-500 font-medium max-w-xs">We're working hard to bring this feature to your pulse. Stay tuned!</p>
            <button onClick={() => setActiveTab('dashboard')} className="text-blue-600 font-black text-xs uppercase tracking-widest">Back to Dashboard</button>
          </div>
        );
    }
  };

  if (!appData?.currentUser && !isLoading) return <Login onLogin={handleLogin} />;

  const adminClubs = appData?.clubs.filter(c => 
    c.ownerId === appData.currentUser?.id || 
    c.members.some(m => m.id === appData.currentUser?.id && m.roles.includes('ADMIN'))
  ) || [];

  return (
    <ErrorBoundary>
      <Layout 
        activeTab={activeTab} 
      onTabChange={(t) => { setActiveTab(t); setSelectedMatchId(null); resetFlow(); }} 
      currentUser={appData?.currentUser || null} 
      onLogout={handleLogout} 
      isSyncing={isSyncing} 
      realtimeStatus={realtimeStatus} 
      notificationCount={appData?.notifications.filter(n => !n.isRead).length || 0} 
      onOpenNotifications={() => setIsNotificationCenterOpen(true)} 
      isPulsing={isPulsing}
      notifPermission={notifPermission}
      isPushSubscribed={isPushSubscribed}
      onRequestNotifPermission={handleSubscribeToPush}
    >
      {renderContent()}
      
      {isNotificationCenterOpen && <NotificationCenter notifications={appData?.notifications || []} onClose={() => setIsNotificationCenterOpen(false)} onMarkRead={(id) => setAppData(prev => prev ? ({ ...prev, notifications: prev.notifications.map(n => n.id === id ? { ...n, isRead: true } : n) }) : null)} onMarkAllRead={() => setAppData(prev => prev ? ({ ...prev, notifications: prev.notifications.map(n => ({ ...n, isRead: true })) }) : null)} />}
      {showApiKeySelectionModal && <ApiKeySelectionModal onSelectKey={async () => { if ((window as any).aistudio?.openSelectKey) await (window as any).aistudio.openSelectKey(); setShowApiKeySelectionModal(false); }} />}

      {/* iPhone Install Guide */}
      {showInstallGuide && (
        <div className="fixed inset-0 z-[200] flex items-end md:items-center justify-center p-4 bg-slate-900/80 backdrop-blur-md">
          <div className="bg-white rounded-[2.5rem] shadow-2xl w-full max-w-sm overflow-hidden p-8 text-center space-y-6">
            <Smartphone className="w-12 h-12 text-blue-600 mx-auto" />
            <div className="space-y-2">
              <h3 className="text-2xl font-black text-slate-900">Get Lock-Screen Alerts</h3>
              <p className="text-sm text-slate-500 font-medium leading-relaxed">
                To receive match alerts while your phone is locked, you must add TeamPulse to your Home Screen.
              </p>
            </div>
            <div className="space-y-3 text-left bg-slate-50 p-6 rounded-3xl border border-slate-100">
              <p className="text-xs font-bold text-slate-700 flex items-center gap-2"><Share className="w-4 h-4 text-blue-500" /> 1. Tap the Share button</p>
              <p className="text-xs font-bold text-slate-700 flex items-center gap-2"><PlusSquare className="w-4 h-4 text-blue-500" /> 2. Add to Home Screen</p>
              <p className="text-xs font-bold text-slate-700 flex items-center gap-2"><BellRing className="w-4 h-4 text-blue-500" /> 3. Tap "Enable Push" inside the app</p>
            </div>
            <button 
              onClick={() => setShowInstallGuide(false)}
              className="w-full py-4 bg-slate-900 text-white rounded-2xl font-black text-xs uppercase tracking-widest"
            >
              Got it
            </button>
          </div>
        </div>
      )}
    </Layout>
    </ErrorBoundary>
  );
};

export default App;
